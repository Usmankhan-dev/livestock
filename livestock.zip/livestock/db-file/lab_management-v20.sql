-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 12, 2020 at 03:11 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lab_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `antibiotics`
--

CREATE TABLE `antibiotics` (
  `antibiotics_id` int(11) NOT NULL,
  `antibiotics_name` varchar(50) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_trash` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `antibiotics`
--

INSERT INTO `antibiotics` (`antibiotics_id`, `antibiotics_name`, `created_by`, `created_date`, `is_trash`) VALUES
(1, 'Antibiotics', 2, '2020-07-09 14:36:31', 0),
(2, 'Ampiclox', 2, '2020-07-09 14:38:36', 0),
(3, 'Cloxacillin', 2, '2020-07-09 14:39:29', 0),
(4, 'Claforan', 2, '2020-07-09 14:40:45', 0);

-- --------------------------------------------------------

--
-- Table structure for table `breeds`
--

CREATE TABLE `breeds` (
  `breed_id` int(11) NOT NULL,
  `cattle_id` int(11) NOT NULL,
  `breed_name` varchar(50) DEFAULT NULL,
  `is_trash` int(11) NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `breeds`
--

INSERT INTO `breeds` (`breed_id`, `cattle_id`, `breed_name`, `is_trash`, `created_by`, `created_date`) VALUES
(1, 2, 'Austrillian', 0, 2, '2020-07-24 14:29:08'),
(2, 1, 'Austrillian', 0, 2, '2020-07-24 14:30:22'),
(3, 3, 'Germans Shepherd  ', 0, 2, '2020-07-24 14:30:51'),
(4, 1, 'Indian', 0, 2, '2020-07-30 10:12:06');

-- --------------------------------------------------------

--
-- Table structure for table `brucella_animal_combine`
--

CREATE TABLE `brucella_animal_combine` (
  `brucella_animal_com_id` int(11) NOT NULL,
  `testDetails_id` int(11) NOT NULL,
  `tag_no` varchar(20) DEFAULT NULL,
  `history` varchar(25) DEFAULT NULL,
  `vac_against_brucellosis` varchar(25) DEFAULT NULL,
  `sample` varchar(20) DEFAULT NULL,
  `species` varchar(20) DEFAULT NULL,
  `result` varchar(50) DEFAULT NULL,
  `remarks` varchar(50) DEFAULT NULL,
  `technician` varchar(25) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `brucella_animal_ind`
--

CREATE TABLE `brucella_animal_ind` (
  `brucella_animal_ind_id` int(11) NOT NULL,
  `testDetails_id` int(11) NOT NULL,
  `tag_no` varchar(20) DEFAULT NULL,
  `history` varchar(25) DEFAULT NULL,
  `vac_against_brucellosis` varchar(25) DEFAULT NULL,
  `sample` varchar(20) DEFAULT NULL,
  `result` varchar(50) DEFAULT NULL,
  `parity` varchar(20) DEFAULT NULL,
  `technician` varchar(25) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `brucella_human`
--

CREATE TABLE `brucella_human` (
  `brucella_human_id` int(11) NOT NULL,
  `testDetails_id` int(11) NOT NULL,
  `result_status` varchar(20) DEFAULT NULL,
  `brucella_abortus_20` varchar(10) DEFAULT NULL,
  `brucella_abortus_40` varchar(10) DEFAULT NULL,
  `brucella_abortus_80` varchar(10) DEFAULT NULL,
  `brucella_abortus_160` varchar(10) DEFAULT NULL,
  `brucella_abortus_320` varchar(10) DEFAULT NULL,
  `brucella_meletensis_20` varchar(10) DEFAULT NULL,
  `brucella_meletensis_40` varchar(10) DEFAULT NULL,
  `brucella_meletensis_80` varchar(10) DEFAULT NULL,
  `brucella_meletensis_160` varchar(10) DEFAULT NULL,
  `brucella_meletensis_320` varchar(10) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cattles`
--

CREATE TABLE `cattles` (
  `cattle_id` int(11) NOT NULL,
  `cattle_name` varchar(50) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_trash` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cattles`
--

INSERT INTO `cattles` (`cattle_id`, `cattle_name`, `created_by`, `created_date`, `is_trash`) VALUES
(1, 'Cow', 2, '2020-07-24 14:24:12', 0),
(2, 'Buffalo', 2, '2020-07-24 14:25:09', 0),
(3, 'Dog', 2, '2020-07-24 14:25:16', 0),
(4, 'Goat', 2, '2020-07-24 14:25:23', 0);

-- --------------------------------------------------------

--
-- Table structure for table `center_station`
--

CREATE TABLE `center_station` (
  `center_station_id` int(11) NOT NULL,
  `district_id` int(11) NOT NULL,
  `directorate_id` int(11) NOT NULL,
  `center_station_name` varchar(255) NOT NULL,
  `center_station_address` varchar(255) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_trash` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `center_station`
--

INSERT INTO `center_station` (`center_station_id`, `district_id`, `directorate_id`, `center_station_name`, `center_station_address`, `created_by`, `created_date`, `is_trash`) VALUES
(1, 5, 1, 'Center of Pathology', NULL, 2, '2020-07-21 08:54:24', 0),
(2, 3, 2, 'Center of VRI', NULL, 2, '2020-07-21 08:58:49', 0),
(3, 3, 1, 'Institute of Microbiology', '  this is testing Address', 2, '2020-07-23 16:41:54', 0),
(4, 3, 2, 'CMB, Peshawar', NULL, 2, '2020-08-06 15:54:59', 0);

-- --------------------------------------------------------

--
-- Table structure for table `client_info`
--

CREATE TABLE `client_info` (
  `client_id` int(11) NOT NULL,
  `client_name` varchar(25) DEFAULT NULL,
  `client_contact` varchar(20) DEFAULT NULL,
  `client_address` varchar(100) DEFAULT NULL,
  `client_cnic` varchar(20) DEFAULT NULL,
  `referred_by` varchar(25) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `type` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client_info`
--

INSERT INTO `client_info` (`client_id`, `client_name`, `client_contact`, `client_address`, `client_cnic`, `referred_by`, `date`, `created_date`, `created_by`, `type`) VALUES
(1, 'Mr. James', '2333', 'New York', '222', 'Dr. Yorkey', '2020-07-13 15:39:30', '2020-07-13 15:39:30', 2, NULL),
(2, 'KHan', '233', 'ksajdflkj', '3223', 'kkhana', '2020-07-15 10:52:37', '2020-07-15 10:52:37', 2, NULL),
(3, 'asdf', '34', 'asdf', '234', '33', '2020-07-28 04:42:13', '2020-07-28 04:42:13', 2, 'farmer'),
(4, 'Farmer - 1', '03113455583', 'jamie@gmail.com', '33332343', '', '2020-08-04 09:21:57', '2020-08-04 09:21:57', 2, 'farmer'),
(5, 'Nazim', '0346', 'nothia peshawar', '17301', '', '2020-08-06 11:33:49', '2020-08-06 11:33:49', 2, 'farmer'),
(6, 'asd', 'sadf', 'sdaf', 'sdf', '', '2020-08-06 18:40:01', '2020-08-06 18:40:01', 2, 'farmer'),
(7, 'asdf', 'sadf', 'sdf', 'sadf', '', '2020-08-06 18:41:09', '2020-08-06 18:41:09', 2, 'farmer');

-- --------------------------------------------------------

--
-- Table structure for table `culture_sensitivity`
--

CREATE TABLE `culture_sensitivity` (
  `culture_sensitivity_id` int(11) NOT NULL,
  `testDetails_id` int(11) NOT NULL,
  `antibiotics_id` int(11) DEFAULT NULL,
  `sensitivity` varchar(100) DEFAULT NULL,
  `reports` varchar(100) DEFAULT NULL,
  `tested_by` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `directorates`
--

CREATE TABLE `directorates` (
  `directorate_id` int(11) NOT NULL,
  `directorate_name` varchar(255) DEFAULT NULL,
  `directorate_head` varchar(100) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_trash` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `directorates`
--

INSERT INTO `directorates` (`directorate_id`, `directorate_name`, `directorate_head`, `created_by`, `created_date`, `is_trash`) VALUES
(1, 'Directorate of Livestock & Dairy Development Research', 'Dr. Mirza Ali Khan', 2, '2020-07-20 21:56:41', 0),
(2, 'VRI', 'Dr. Ijaz Ikram', 2, '2020-07-23 14:46:21', 0);

-- --------------------------------------------------------

--
-- Table structure for table `districts`
--

CREATE TABLE `districts` (
  `district_id` int(11) NOT NULL,
  `district_name` varchar(50) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_trash` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `districts`
--

INSERT INTO `districts` (`district_id`, `district_name`, `created_by`, `created_date`, `is_trash`) VALUES
(1, 'Kohat', 2, '2020-07-03 18:35:13', 0),
(2, 'Swabi', 2, '2020-07-03 18:35:52', 0),
(3, 'Peshaawar', 2, '2020-07-03 19:34:29', 0),
(4, 'Swat', 2, '2020-07-04 11:29:17', 0),
(5, 'Dera Ismail Khan', 2, '2020-07-04 11:31:44', 0),
(6, 'Mardan', 2, '2020-07-10 07:04:31', 0),
(7, 'Abbottabad ', 2, '2020-07-21 06:55:25', 0);

-- --------------------------------------------------------

--
-- Table structure for table `haematology`
--

CREATE TABLE `haematology` (
  `haematology_id` int(11) NOT NULL,
  `testDetails_id` int(11) NOT NULL,
  `haemoglobin` varchar(25) NOT NULL,
  `ESR` varchar(25) NOT NULL,
  `TRBC` varchar(15) NOT NULL,
  `TLC` varchar(11) NOT NULL,
  `PCV` varchar(11) NOT NULL,
  `neutrophils` varchar(10) NOT NULL,
  `lymphocytes` varchar(5) NOT NULL,
  `eosinophils` varchar(20) NOT NULL,
  `monocytes` varchar(10) NOT NULL,
  `basophils` varchar(25) NOT NULL,
  `protozoa` varchar(255) NOT NULL,
  `iodine_flocculation_test` varchar(255) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `impression_smear`
--

CREATE TABLE `impression_smear` (
  `impression_smear_id` int(11) NOT NULL,
  `testDetails_id` int(11) NOT NULL,
  `type_specimen` varchar(30) DEFAULT NULL,
  `animals_specimen` varchar(30) DEFAULT NULL,
  `examined_for` varchar(30) DEFAULT NULL,
  `result` varchar(30) DEFAULT NULL,
  `remarks` varchar(30) DEFAULT NULL,
  `examined_by` varchar(30) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `impression_smear`
--

INSERT INTO `impression_smear` (`impression_smear_id`, `testDetails_id`, `type_specimen`, `animals_specimen`, `examined_for`, `result`, `remarks`, `examined_by`, `created_by`, `created_date`) VALUES
(1, 1, 'Type of Specime', 'Animals Spe222', 'ddddd', 'result', 'remark', 'ddddaa', 2, '2020-07-13 15:39:30'),
(2, 2, 'sadf', 'asdf', 'asd', 'asdf', 'adf', 'asd', 2, '2020-07-15 10:52:37'),
(3, 4, 'test Specimen', 'Animals Specimen', 'Examined for', 'Result', 'Remarks', 'Examined by', 2, '2020-08-04 09:21:58'),
(4, 6, '', '', '', '', '', '', 2, '2020-08-06 18:40:01');

-- --------------------------------------------------------

--
-- Table structure for table `labs`
--

CREATE TABLE `labs` (
  `lab_id` int(11) NOT NULL,
  `directorate_id` int(11) NOT NULL,
  `center_station_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `lab_name` varchar(100) NOT NULL,
  `lab_address` varchar(50) NOT NULL,
  `lab_description` varchar(255) DEFAULT NULL,
  `is_trash` int(11) NOT NULL DEFAULT '0',
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `labs`
--

INSERT INTO `labs` (`lab_id`, `directorate_id`, `center_station_id`, `section_id`, `lab_name`, `lab_address`, `lab_description`, `is_trash`, `created_by`, `created_date`) VALUES
(2, 1, 3, 2, 'Live stock & Dairy Development Peshawar', '  Peshawar', 'this is Peshawar lab', 0, 1, '2020-07-03 19:46:51'),
(3, 2, 4, 3, 'Pathology Lab', 'lab', 'dsfa', 0, 2, '2020-08-06 11:00:10');

-- --------------------------------------------------------

--
-- Table structure for table `mastitis`
--

CREATE TABLE `mastitis` (
  `mastitis_id` int(11) NOT NULL,
  `testDetails_id` int(11) NOT NULL,
  `cal_kid_lambing_date` varchar(50) DEFAULT NULL,
  `daily_milk_production` varchar(50) DEFAULT NULL,
  `lactation_no` varchar(50) DEFAULT NULL,
  `total_animals_at_farm` varchar(50) DEFAULT NULL,
  `in_milk` varchar(10) DEFAULT NULL,
  `dry_period_given` varchar(50) DEFAULT NULL,
  `prev_mastatis_rec_of_anim` varchar(50) DEFAULT NULL,
  `prev_mastatis_rec_of_farm` varchar(50) DEFAULT NULL,
  `prac_mastatis_test_at_farm` varchar(50) DEFAULT NULL,
  `sample_received` varchar(50) DEFAULT NULL,
  `test_required` varchar(100) DEFAULT NULL,
  `refer_to_bacteriology_sec_for` varchar(100) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mastitis`
--

INSERT INTO `mastitis` (`mastitis_id`, `testDetails_id`, `cal_kid_lambing_date`, `daily_milk_production`, `lactation_no`, `total_animals_at_farm`, `in_milk`, `dry_period_given`, `prev_mastatis_rec_of_anim`, `prev_mastatis_rec_of_farm`, `prac_mastatis_test_at_farm`, `sample_received`, `test_required`, `refer_to_bacteriology_sec_for`, `created_by`, `created_date`) VALUES
(1, 3, '08/08/2020', 'asfdu', 'asddfu', 'asdu', 'f', 'asdfu', 'sadf', 'asdf', 'sdf', 'asfd', 'asdf', 'asdf', 2, '2020-07-28 04:42:14'),
(2, 7, '', '', '', '', '', '', '', '', '', '', '', '', 2, '2020-08-06 18:41:09');

-- --------------------------------------------------------

--
-- Table structure for table `modules`
--

CREATE TABLE `modules` (
  `module_id` int(11) NOT NULL,
  `module` varchar(50) DEFAULT NULL,
  `is_trash` int(11) NOT NULL DEFAULT '0',
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `modules`
--

INSERT INTO `modules` (`module_id`, `module`, `is_trash`, `created_date`) VALUES
(1, 'Dashboard', 0, '2020-07-28 12:43:18'),
(2, 'Admin Panel', 0, '2020-07-28 12:43:18'),
(3, 'Test Panel', 0, '2020-07-28 12:43:18'),
(4, 'User Panel', 0, '2020-07-28 12:43:18');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `role_id` int(11) NOT NULL,
  `role_name` varchar(25) NOT NULL,
  `is_trash` int(11) NOT NULL DEFAULT '0',
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`role_id`, `role_name`, `is_trash`, `created_by`, `created_date`) VALUES
(1, 'Admin', 0, 1, '2020-07-03 20:29:41'),
(2, 'Data Entry Operator', 0, 1, '2020-07-03 21:24:05'),
(3, 'Lab InchargeU', 0, 2, '2020-07-06 09:32:50'),
(4, 'Test Role', 0, 2, '2020-07-30 05:34:40'),
(5, 'Visiter', 0, 2, '2020-08-10 05:24:51');

-- --------------------------------------------------------

--
-- Table structure for table `role_permissions`
--

CREATE TABLE `role_permissions` (
  `role_perm_id` int(11) NOT NULL,
  `module_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `show_created_by` int(11) NOT NULL,
  `show_lab_by` int(11) NOT NULL,
  `show_all` int(11) NOT NULL,
  `show_none` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role_permissions`
--

INSERT INTO `role_permissions` (`role_perm_id`, `module_id`, `role_id`, `show_created_by`, `show_lab_by`, `show_all`, `show_none`) VALUES
(1, 1, 1, 2, 0, 1, 0),
(2, 2, 1, 2, 0, 1, 0),
(3, 3, 1, 0, 0, 1, 0),
(4, 4, 1, 2, 0, 1, 0),
(5, 1, 2, 2, 1, 0, 0),
(6, 2, 2, 2, 0, 0, 1),
(7, 3, 2, 1, 0, 0, 0),
(8, 4, 2, 2, 0, 0, 1),
(9, 1, 3, 2, 1, 1, 0),
(10, 2, 3, 2, 0, 0, 0),
(11, 3, 3, 0, 0, 1, 0),
(12, 4, 3, 2, 0, 0, 1),
(13, 1, 4, 2, 0, 0, 1),
(14, 2, 4, 2, 0, 1, 0),
(15, 3, 4, 0, 0, 1, 0),
(16, 4, 4, 2, 0, 0, 1),
(17, 1, 5, 2, 1, 0, 0),
(18, 2, 5, 2, 1, 0, 0),
(19, 3, 5, 0, 1, 0, 0),
(20, 4, 5, 2, 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `samples`
--

CREATE TABLE `samples` (
  `sample_id` int(11) NOT NULL,
  `sample_name` varchar(100) NOT NULL,
  `sample_color` varchar(25) DEFAULT NULL,
  `sample_size` varchar(25) DEFAULT NULL,
  `sample_time` varchar(25) DEFAULT NULL,
  `sample_weight` varchar(25) DEFAULT NULL,
  `is_trash` int(11) NOT NULL DEFAULT '0',
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `samples`
--

INSERT INTO `samples` (`sample_id`, `sample_name`, `sample_color`, `sample_size`, `sample_time`, `sample_weight`, `is_trash`, `created_by`, `created_date`) VALUES
(1, 'Milk', NULL, NULL, NULL, NULL, 0, 2, '2020-07-06 18:31:54'),
(2, 'Liver', NULL, NULL, NULL, NULL, 0, 2, '2020-07-07 21:18:41'),
(3, 'Lungs', NULL, NULL, NULL, NULL, 0, 2, '2020-07-07 21:18:50'),
(4, 'Blood', NULL, NULL, NULL, NULL, 0, 2, '2020-07-07 21:18:56'),
(5, 'Urine', NULL, NULL, NULL, NULL, 0, 2, '2020-07-22 08:09:59');

-- --------------------------------------------------------

--
-- Table structure for table `sectionhelp`
--

CREATE TABLE `sectionhelp` (
  `sectionHelp_id` int(11) NOT NULL,
  `sectionHelp_name` varchar(100) DEFAULT NULL,
  `is_trash` int(11) NOT NULL DEFAULT '0',
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sectionhelp`
--

INSERT INTO `sectionhelp` (`sectionHelp_id`, `sectionHelp_name`, `is_trash`, `created_by`, `created_date`) VALUES
(1, 'Pathology & Bacteriology Section', 0, 1, '2020-08-08 20:24:29'),
(2, 'Mastitis Section', 0, 1, '2020-08-08 20:24:29'),
(3, 'TB & VPH Section', 0, 1, '2020-08-08 20:24:29'),
(4, 'Brucellosis Section', 0, 1, '2020-08-08 20:24:29'),
(5, 'Animal Biotecnology Section', 0, 1, '2020-08-08 20:24:29'),
(6, 'Virology Section', 0, 1, '2020-08-08 20:24:29');

-- --------------------------------------------------------

--
-- Table structure for table `sections`
--

CREATE TABLE `sections` (
  `section_id` int(11) NOT NULL,
  `directorate_id` int(11) NOT NULL,
  `center_station_id` int(11) NOT NULL,
  `sectionHelp_id` int(11) DEFAULT NULL,
  `is_trash` int(11) NOT NULL DEFAULT '0',
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sections`
--

INSERT INTO `sections` (`section_id`, `directorate_id`, `center_station_id`, `sectionHelp_id`, `is_trash`, `created_by`, `created_date`) VALUES
(1, 1, 3, 2, 0, 2, '2020-07-07 19:13:16'),
(2, 1, 3, 1, 0, 2, '2020-07-08 09:16:44'),
(3, 2, 4, 3, 0, 2, '2020-08-06 10:58:34');

-- --------------------------------------------------------

--
-- Table structure for table `tb_and_vph`
--

CREATE TABLE `tb_and_vph` (
  `tb_and_vph_id` int(11) NOT NULL,
  `testDetails_id` int(11) NOT NULL,
  `symptoms` varchar(255) DEFAULT NULL,
  `specimen` varchar(100) DEFAULT NULL,
  `referred_by` varchar(25) DEFAULT NULL,
  `lab_findings` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `examined_by` varchar(25) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `testdetails`
--

CREATE TABLE `testdetails` (
  `testDetails_id` int(11) NOT NULL,
  `test_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `sample_id` int(11) NOT NULL,
  `cattle_name` varchar(24) DEFAULT NULL,
  `cattle_tag_no` varchar(20) DEFAULT NULL,
  `cattle_sex` varchar(10) DEFAULT NULL,
  `cattle_age` varchar(20) DEFAULT NULL,
  `cattle_breed` varchar(20) DEFAULT NULL,
  `cattle_total_no` varchar(10) NOT NULL DEFAULT '1',
  `referred_by` varchar(25) DEFAULT NULL,
  `received_date` date DEFAULT NULL,
  `result_date` date DEFAULT NULL,
  `post_status` int(11) NOT NULL DEFAULT '0',
  `posted_date` date DEFAULT NULL,
  `recommendations` varchar(255) DEFAULT NULL,
  `test_total_fee` varchar(50) DEFAULT NULL,
  `additional_info` text,
  `is_cancel` int(11) NOT NULL DEFAULT '0',
  `cancel_reason` varchar(100) NOT NULL,
  `cancel_by` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `testdetails`
--

INSERT INTO `testdetails` (`testDetails_id`, `test_id`, `client_id`, `sample_id`, `cattle_name`, `cattle_tag_no`, `cattle_sex`, `cattle_age`, `cattle_breed`, `cattle_total_no`, `referred_by`, `received_date`, `result_date`, `post_status`, `posted_date`, `recommendations`, `test_total_fee`, `additional_info`, `is_cancel`, `cancel_reason`, `cancel_by`, `created_by`, `created_date`, `modified_date`) VALUES
(1, 1, 1, 2, '2', '33', 'Male', '2 yea', '1', '1', NULL, '2020-09-07', '2020-08-08', 0, NULL, 'this is recommendation', '223.00', 'this is testing entryU', 1, 'this is testing cancel', 2, 2, '2020-07-13 15:39:30', NULL),
(2, 1, 2, 4, '2', '3', 'kjsdlk', '33', '1', '2', NULL, '2020-07-29', '2020-08-03', 1, '2020-07-17', NULL, '222.00', 'asfsadf', 0, '', NULL, 2, '2020-07-15 10:52:37', NULL),
(3, 3, 3, 1, '2', '3', 'asdf', 'sdaf', '1', '234', NULL, '2020-05-08', '2020-08-08', 1, '2020-07-28', NULL, '23423.00', 'asdf', 0, '', NULL, 2, '2020-07-28 04:42:13', NULL),
(4, 1, 4, 2, '1', '3', 'Male', '3', '2', '1', NULL, '2020-08-25', '2020-08-06', 0, NULL, 'this is testing recommendation', '22.00', 'testing', 0, '', NULL, 2, '2020-08-04 09:21:58', '2020-08-06 08:46:14'),
(5, 10, 5, 4, '1', '0', 'M', '10months', '2', '1', NULL, '2020-08-06', '2020-08-12', 0, NULL, NULL, '145.00', 'this is info', 0, '', NULL, 2, '2020-08-06 11:33:49', NULL),
(6, 1, 6, 2, '2', '3', '2', '3', '1', '3', NULL, '2020-08-27', '2020-08-26', 0, NULL, NULL, '2.00', 'sdaf', 0, '', NULL, 2, '2020-08-06 18:40:01', NULL),
(7, 3, 7, 1, '1', '3', 'sdfa', '3', '4', '3', NULL, '2020-09-02', '2020-09-05', 0, NULL, NULL, '2.00', 'sdf', 0, '', NULL, 2, '2020-08-06 18:41:09', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `testhelp`
--

CREATE TABLE `testhelp` (
  `testHelp_id` int(11) NOT NULL,
  `testHelp_name` varchar(255) DEFAULT NULL,
  `is_trash` int(11) NOT NULL DEFAULT '0',
  `created_by` int(11) DEFAULT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `testhelp`
--

INSERT INTO `testhelp` (`testHelp_id`, `testHelp_name`, `is_trash`, `created_by`, `created_date`) VALUES
(1, 'Impression Smear', 0, 1, '2020-08-12 03:23:54'),
(2, 'Hematology', 0, 1, '2020-08-12 03:23:54'),
(3, 'Mastitis', 0, 1, '2020-08-12 03:23:54'),
(4, 'Culture Sensitivity	', 0, 1, '2020-08-12 03:23:54'),
(5, 'Urine Examination', 0, 1, '2020-08-12 03:23:54'),
(6, 'Brucella Animal Combine	', 0, 1, '2020-08-12 03:23:54'),
(7, 'Brucella Animal Individual', 0, 1, '2020-08-12 03:23:54'),
(8, 'Brucella Human', 0, 1, '2020-08-12 03:23:54'),
(9, 'Tb and vph', 0, 1, '2020-08-12 03:23:54');

-- --------------------------------------------------------

--
-- Table structure for table `tests`
--

CREATE TABLE `tests` (
  `test_id` int(11) NOT NULL,
  `directorate_id` int(11) NOT NULL,
  `center_station_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `lab_id` int(11) NOT NULL,
  `testHelp_id` int(11) DEFAULT NULL,
  `test_fee` double DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `is_trash` int(11) DEFAULT '0',
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tests`
--

INSERT INTO `tests` (`test_id`, `directorate_id`, `center_station_id`, `section_id`, `lab_id`, `testHelp_id`, `test_fee`, `description`, `is_trash`, `created_by`, `created_date`) VALUES
(1, 1, 3, 2, 2, 1, 222, '  this is testing record', 0, 2, '2020-07-08 07:19:18'),
(2, 1, 1, 1, 2, 2, 500, 'This result is issued provisionally', 0, 2, '2020-07-21 05:05:27'),
(3, 1, 1, 1, 2, 3, 400, ' kjadsjhgadsyg', 0, 2, '2020-07-21 05:38:59'),
(4, 0, 1, 1, 2, 4, 440, 'kjhascyguasuig', 0, 2, '2020-07-21 05:57:28'),
(5, 1, 1, 1, 2, 5, 562, ' jkjasdyggasd7d', 0, 2, '2020-07-21 07:18:11'),
(6, 1, 3, 2, 2, 6, 3, ' klkjuhhusa', 0, 2, '2020-07-24 10:58:01'),
(7, 1, 3, 2, 2, 7, 2, 'hdkfhjfjhfh', 0, 2, '2020-07-24 10:59:09'),
(8, 1, 3, 2, 2, 8, 3, 'jjghjlhygui', 0, 2, '2020-07-24 11:00:20'),
(9, 1, 3, 2, 2, 9, 3, 'gfgfhhht', 0, 2, '2020-07-24 11:01:11'),
(10, 2, 4, 3, 3, 1, 500, ' this ', 0, 2, '2020-08-06 11:05:07');

-- --------------------------------------------------------

--
-- Table structure for table `test_samples`
--

CREATE TABLE `test_samples` (
  `test_sample_id` int(11) NOT NULL,
  `test_id` int(11) NOT NULL,
  `sample_id` int(11) DEFAULT NULL,
  `is_trash` int(11) NOT NULL DEFAULT '0',
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test_samples`
--

INSERT INTO `test_samples` (`test_sample_id`, `test_id`, `sample_id`, `is_trash`, `created_by`, `created_date`) VALUES
(12, 5, 5, 0, NULL, '2020-07-22 08:10:27'),
(13, 3, 1, 0, NULL, '2020-07-23 07:00:39'),
(14, 1, 2, 0, NULL, '2020-07-23 12:49:45'),
(16, 6, 4, 0, NULL, '2020-07-24 10:58:26'),
(17, 7, 3, 0, 2, '2020-07-24 10:59:09'),
(18, 8, 4, 0, 2, '2020-07-24 11:00:20'),
(19, 9, 5, 0, 2, '2020-07-24 11:01:11'),
(22, 10, 4, 0, NULL, '2020-08-06 11:06:06'),
(23, 10, 5, 0, NULL, '2020-08-06 11:06:06');

-- --------------------------------------------------------

--
-- Table structure for table `urine_examination`
--

CREATE TABLE `urine_examination` (
  `urine_id` int(11) NOT NULL,
  `testDetails_id` int(11) NOT NULL,
  `colour` varchar(30) DEFAULT NULL,
  `appearance` varchar(30) DEFAULT NULL,
  `reaction` varchar(30) DEFAULT NULL,
  `specific_gravity` varchar(30) DEFAULT NULL,
  `glucose` varchar(30) DEFAULT NULL,
  `protein` varchar(30) DEFAULT NULL,
  `bile_salts` varchar(30) DEFAULT NULL,
  `bile_pigments` varchar(30) DEFAULT NULL,
  `ketone_bodies` varchar(30) DEFAULT NULL,
  `haemoglobin` varchar(30) DEFAULT NULL,
  `pus_cell` varchar(30) DEFAULT NULL,
  `epithelial_cell` varchar(30) DEFAULT NULL,
  `rb_cs` varchar(30) DEFAULT NULL,
  `casts` varchar(30) DEFAULT NULL,
  `crystals` varchar(30) DEFAULT NULL,
  `amorphous` varchar(30) DEFAULT NULL,
  `parasites` varchar(30) DEFAULT NULL,
  `bacteria` varchar(30) DEFAULT NULL,
  `remarks` varchar(30) DEFAULT NULL,
  `examined_by` varchar(30) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `directorate_id` int(11) NOT NULL,
  `center_station_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `lab_id` int(11) DEFAULT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_contact` varchar(20) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_role` int(11) NOT NULL,
  `designation` varchar(50) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `user_img` varchar(100) DEFAULT NULL,
  `is_block` int(11) NOT NULL DEFAULT '0',
  `is_active` int(11) NOT NULL DEFAULT '1',
  `is_trash` int(11) NOT NULL DEFAULT '0',
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `directorate_id`, `center_station_id`, `section_id`, `lab_id`, `user_name`, `user_email`, `user_contact`, `user_password`, `user_role`, `designation`, `gender`, `user_img`, `is_block`, `is_active`, `is_trash`, `created_date`, `created_by`) VALUES
(1, 1, 3, 2, 2, 'Arshad Ali', 'arshad.ali@gmail.com', '12345', '$2y$10$k0JniyM3CaDf7cQYnd.u6.QjGnACjhhEWAiUS.EUBwjJgDP4sQJmK', 2, 'Computer Operator', 'Male', '40images(2).jpg', 0, 1, 0, '2020-07-03 21:18:24', 1),
(2, 0, 0, 0, 2, 'Mr JameU', 'admin@gmail.com', '123455', '$2y$10$k0JniyM3CaDf7cQYnd.u6.QjGnACjhhEWAiUS.EUBwjJgDP4sQJmK', 1, 'Administrator', 'Male', '441236avatar5.png', 0, 1, 0, '2020-07-04 12:01:21', 1),
(3, 1, 3, 2, 2, 'Nazim', 'nazim@gmail.com', '12355', '$2y$10$RmOA/ykShHkh9YrZWs8XXOO2TCQ4WBJKGrxuo1JFrvlUlADEQr6ZS', 4, 'CO', 'Male', '03Join-our-Network-of-Coders.jpg', 0, 1, 0, '2020-07-30 12:04:03', 2),
(4, 2, 4, 3, 3, 'nazim12', 'nazim12@gmail.com', '0300', '$2y$10$YSMHXLmJnla/oA8EzRw3rO87LQJFvXd4RXn3PjyzMHBf8sltCV6Nq', 2, 'CO', 'Male', '', 0, 1, 0, '2020-08-06 11:40:00', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `antibiotics`
--
ALTER TABLE `antibiotics`
  ADD PRIMARY KEY (`antibiotics_id`);

--
-- Indexes for table `breeds`
--
ALTER TABLE `breeds`
  ADD PRIMARY KEY (`breed_id`);

--
-- Indexes for table `brucella_animal_combine`
--
ALTER TABLE `brucella_animal_combine`
  ADD PRIMARY KEY (`brucella_animal_com_id`),
  ADD KEY `testDetails_id` (`testDetails_id`);

--
-- Indexes for table `brucella_animal_ind`
--
ALTER TABLE `brucella_animal_ind`
  ADD PRIMARY KEY (`brucella_animal_ind_id`),
  ADD KEY `testDetails_id` (`testDetails_id`);

--
-- Indexes for table `brucella_human`
--
ALTER TABLE `brucella_human`
  ADD PRIMARY KEY (`brucella_human_id`),
  ADD KEY `testDetails_id` (`testDetails_id`);

--
-- Indexes for table `cattles`
--
ALTER TABLE `cattles`
  ADD PRIMARY KEY (`cattle_id`);

--
-- Indexes for table `center_station`
--
ALTER TABLE `center_station`
  ADD PRIMARY KEY (`center_station_id`);

--
-- Indexes for table `client_info`
--
ALTER TABLE `client_info`
  ADD PRIMARY KEY (`client_id`);

--
-- Indexes for table `culture_sensitivity`
--
ALTER TABLE `culture_sensitivity`
  ADD PRIMARY KEY (`culture_sensitivity_id`),
  ADD KEY `testDetails_id` (`testDetails_id`),
  ADD KEY `antibiotics_id` (`antibiotics_id`);

--
-- Indexes for table `directorates`
--
ALTER TABLE `directorates`
  ADD PRIMARY KEY (`directorate_id`);

--
-- Indexes for table `districts`
--
ALTER TABLE `districts`
  ADD PRIMARY KEY (`district_id`);

--
-- Indexes for table `haematology`
--
ALTER TABLE `haematology`
  ADD PRIMARY KEY (`haematology_id`),
  ADD KEY `testDetails_id` (`testDetails_id`);

--
-- Indexes for table `impression_smear`
--
ALTER TABLE `impression_smear`
  ADD PRIMARY KEY (`impression_smear_id`),
  ADD KEY `testDetails_id` (`testDetails_id`);

--
-- Indexes for table `labs`
--
ALTER TABLE `labs`
  ADD PRIMARY KEY (`lab_id`);

--
-- Indexes for table `mastitis`
--
ALTER TABLE `mastitis`
  ADD PRIMARY KEY (`mastitis_id`),
  ADD KEY `testDetails_id` (`testDetails_id`);

--
-- Indexes for table `modules`
--
ALTER TABLE `modules`
  ADD PRIMARY KEY (`module_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`role_id`);

--
-- Indexes for table `role_permissions`
--
ALTER TABLE `role_permissions`
  ADD PRIMARY KEY (`role_perm_id`);

--
-- Indexes for table `samples`
--
ALTER TABLE `samples`
  ADD PRIMARY KEY (`sample_id`);

--
-- Indexes for table `sectionhelp`
--
ALTER TABLE `sectionhelp`
  ADD PRIMARY KEY (`sectionHelp_id`);

--
-- Indexes for table `sections`
--
ALTER TABLE `sections`
  ADD PRIMARY KEY (`section_id`);

--
-- Indexes for table `tb_and_vph`
--
ALTER TABLE `tb_and_vph`
  ADD PRIMARY KEY (`tb_and_vph_id`),
  ADD KEY `testDetails_id` (`testDetails_id`);

--
-- Indexes for table `testdetails`
--
ALTER TABLE `testdetails`
  ADD PRIMARY KEY (`testDetails_id`),
  ADD KEY `test_id` (`test_id`),
  ADD KEY `client_id` (`client_id`);

--
-- Indexes for table `testhelp`
--
ALTER TABLE `testhelp`
  ADD PRIMARY KEY (`testHelp_id`);

--
-- Indexes for table `tests`
--
ALTER TABLE `tests`
  ADD PRIMARY KEY (`test_id`);

--
-- Indexes for table `test_samples`
--
ALTER TABLE `test_samples`
  ADD PRIMARY KEY (`test_sample_id`),
  ADD KEY `test_id` (`test_id`),
  ADD KEY `sample_id` (`sample_id`);

--
-- Indexes for table `urine_examination`
--
ALTER TABLE `urine_examination`
  ADD PRIMARY KEY (`urine_id`),
  ADD KEY `testDetails_id` (`testDetails_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `user_role` (`user_role`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `antibiotics`
--
ALTER TABLE `antibiotics`
  MODIFY `antibiotics_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `breeds`
--
ALTER TABLE `breeds`
  MODIFY `breed_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `brucella_animal_combine`
--
ALTER TABLE `brucella_animal_combine`
  MODIFY `brucella_animal_com_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `brucella_animal_ind`
--
ALTER TABLE `brucella_animal_ind`
  MODIFY `brucella_animal_ind_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `brucella_human`
--
ALTER TABLE `brucella_human`
  MODIFY `brucella_human_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cattles`
--
ALTER TABLE `cattles`
  MODIFY `cattle_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `center_station`
--
ALTER TABLE `center_station`
  MODIFY `center_station_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `client_info`
--
ALTER TABLE `client_info`
  MODIFY `client_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `culture_sensitivity`
--
ALTER TABLE `culture_sensitivity`
  MODIFY `culture_sensitivity_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `directorates`
--
ALTER TABLE `directorates`
  MODIFY `directorate_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `districts`
--
ALTER TABLE `districts`
  MODIFY `district_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `haematology`
--
ALTER TABLE `haematology`
  MODIFY `haematology_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `impression_smear`
--
ALTER TABLE `impression_smear`
  MODIFY `impression_smear_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `labs`
--
ALTER TABLE `labs`
  MODIFY `lab_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `mastitis`
--
ALTER TABLE `mastitis`
  MODIFY `mastitis_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `modules`
--
ALTER TABLE `modules`
  MODIFY `module_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `role_permissions`
--
ALTER TABLE `role_permissions`
  MODIFY `role_perm_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `samples`
--
ALTER TABLE `samples`
  MODIFY `sample_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `sectionhelp`
--
ALTER TABLE `sectionhelp`
  MODIFY `sectionHelp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `sections`
--
ALTER TABLE `sections`
  MODIFY `section_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_and_vph`
--
ALTER TABLE `tb_and_vph`
  MODIFY `tb_and_vph_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `testdetails`
--
ALTER TABLE `testdetails`
  MODIFY `testDetails_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `testhelp`
--
ALTER TABLE `testhelp`
  MODIFY `testHelp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tests`
--
ALTER TABLE `tests`
  MODIFY `test_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `test_samples`
--
ALTER TABLE `test_samples`
  MODIFY `test_sample_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `urine_examination`
--
ALTER TABLE `urine_examination`
  MODIFY `urine_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `brucella_animal_combine`
--
ALTER TABLE `brucella_animal_combine`
  ADD CONSTRAINT `brucella_animal_combine_ibfk_1` FOREIGN KEY (`testDetails_id`) REFERENCES `testdetails` (`testDetails_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `brucella_animal_ind`
--
ALTER TABLE `brucella_animal_ind`
  ADD CONSTRAINT `brucella_animal_ind_ibfk_1` FOREIGN KEY (`testDetails_id`) REFERENCES `testdetails` (`testDetails_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `brucella_human`
--
ALTER TABLE `brucella_human`
  ADD CONSTRAINT `brucella_human_ibfk_1` FOREIGN KEY (`testDetails_id`) REFERENCES `testdetails` (`testDetails_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `culture_sensitivity`
--
ALTER TABLE `culture_sensitivity`
  ADD CONSTRAINT `culture_sensitivity_ibfk_1` FOREIGN KEY (`testDetails_id`) REFERENCES `testdetails` (`testDetails_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `culture_sensitivity_ibfk_2` FOREIGN KEY (`antibiotics_id`) REFERENCES `antibiotics` (`antibiotics_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `haematology`
--
ALTER TABLE `haematology`
  ADD CONSTRAINT `haematology_ibfk_1` FOREIGN KEY (`testDetails_id`) REFERENCES `testdetails` (`testDetails_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `impression_smear`
--
ALTER TABLE `impression_smear`
  ADD CONSTRAINT `impression_smear_ibfk_1` FOREIGN KEY (`testDetails_id`) REFERENCES `testdetails` (`testDetails_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `mastitis`
--
ALTER TABLE `mastitis`
  ADD CONSTRAINT `mastitis_ibfk_1` FOREIGN KEY (`testDetails_id`) REFERENCES `testdetails` (`testDetails_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `tb_and_vph`
--
ALTER TABLE `tb_and_vph`
  ADD CONSTRAINT `tb_and_vph_ibfk_1` FOREIGN KEY (`testDetails_id`) REFERENCES `testdetails` (`testDetails_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `testdetails`
--
ALTER TABLE `testdetails`
  ADD CONSTRAINT `testdetails_ibfk_1` FOREIGN KEY (`test_id`) REFERENCES `tests` (`test_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `testdetails_ibfk_4` FOREIGN KEY (`client_id`) REFERENCES `client_info` (`client_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `test_samples`
--
ALTER TABLE `test_samples`
  ADD CONSTRAINT `test_samples_ibfk_1` FOREIGN KEY (`test_id`) REFERENCES `tests` (`test_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `test_samples_ibfk_2` FOREIGN KEY (`sample_id`) REFERENCES `samples` (`sample_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `urine_examination`
--
ALTER TABLE `urine_examination`
  ADD CONSTRAINT `urine_examination_ibfk_1` FOREIGN KEY (`testDetails_id`) REFERENCES `testdetails` (`testDetails_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_2` FOREIGN KEY (`user_role`) REFERENCES `roles` (`role_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
