// all custom js code 

$(function () {
$('#DataTable2').DataTable({
"paging": true,
"lengthChange": true,
"searching": true,
"ordering": true,
"info": true,
"autoWidth": true,
 "order": [[ 0, "desc" ]]
});
});

$(function () {
//Initialize Select2 Elements
$('.select2').select2();
// $('.datepicker').datepicker();

});



$(document).ready(function(){


	$('.testPrice').on('blur',function(){

	    var tPrice = parseFloat($(this).val());

	        var vl = tPrice.toFixed(2);
	        $(this).val(vl);
	    // alert(tPrice.toFixed(2));
	})


});
