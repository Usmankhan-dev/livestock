
<!-- jQuery -->
<script src="<?php echo base_url() ?>/public/plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url() ?>public/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- select2 -->
<script src="<?php echo base_url() ?>public/plugins/select2/select2.min.js"></script>
<script src="<?php echo base_url() ?>public/plugins/select2/select2.full.min.js"></script>
<!-- DataTables -->
<script src="<?php echo base_url() ?>public/plugins/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url() ?>public/plugins/datatables/dataTables.bootstrap4.js"></script>
<!-- Morris.js charts -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
<script src="<?php echo base_url() ?>public/plugins/morris/morris.min.js"></script>
<!-- Sparkline -->
<script src="<?php echo base_url() ?>public/plugins/sparkline/jquery.sparkline.min.js"></script>
<!-- jvectormap -->
<script src="<?php echo base_url() ?>public/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="<?php echo base_url() ?>public/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<!-- jQuery Knob Chart -->
<script src="<?php echo base_url() ?>public/plugins/knob/jquery.knob.js"></script>
<!-- daterangepicker -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.2/moment.min.js"></script>
<script src="<?php echo base_url() ?>public/plugins/daterangepicker/daterangepicker.js"></script>
<!-- datepicker -->
<script src="<?php echo base_url() ?>public/plugins/datepicker/bootstrap-datepicker.js"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="<?php echo base_url() ?>/public/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<!-- Slimscroll -->
<script src="<?php echo base_url() ?>/public/plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="<?php echo base_url() ?>/public/plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url() ?>/public/dist/js/adminlte.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="<?php echo base_url() ?>/public/dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url() ?>/public/dist/js/demo.js"></script>
<script src="<?php echo base_url() ?>/public/custom_files/custom.js"></script>
<script type="text/javascript">
    function base_url() {
        return "<?php echo base_url(); ?>";
    }
</script>

<?php
 $uri = $this->uri->segment(2);
  if($uri=='updateTestDetailsRecord')
  {
?>
<?php
  }
?>
<script>

    function checkUnCheckData(obj, one, two, three) {
      // alert(obj);
        if ($(obj).prop('checked') == true) {
            $(obj).closest('tr').find('.'+one).prop('checked',false);
            $(obj).closest('tr').find('.'+two).prop('checked',false);
            $(obj).closest('tr').find('.'+three).prop('checked',false);
        }
    }


</script>
<script>
    $(document).ready(function(){
      $("#Updatedirectorate_id").trigger('change');
$('#fimpression_smear').hide();
$('#fmastitis').hide();
$('#fhaematology').hide();
$('#fculture_sensitivity').hide();
$('#furine_examination').hide();
$('#fbrucella_animal_combine').hide();
$('#fBrucell_Animal_ind').hide();
$('#fbrucella_human').hide();
$('#ftb_and_vph').hide();
      // alert($(this).val());
      // getStations();
});
function GetClient_cnic()
{
  var cnic = $('.clientCnic').val();
  // alert(cnic);
    if(cnic!='') {
    $.ajax({
        dataType:"json",
        type:"POST",
        data:{cnic:cnic},
        url:"<?= base_url('Login/GetClient_cnic/'); ?>",
        success:function(data)
        {
            if(data!='')
            {
              $('.client_name').val(data.client_name);
              $('.client_contact').val(data.client_contact);
              $('.referred_by').val(data.referred_by);
              $('.client_address').val(data.client_address);
            }else
            {
              $('.client_name').val();
              $('.client_contact').val();
              $('.referred_by').val();
              $('.client_address').val();
            }
             
              
        }

      });
    }else{
                 
            }
}
function GetBreeds(vl)
{
  var cattle_id = vl;
  // alert(center_station_id);
    if(cattle_id!='') {
    $.ajax({
        dataType:"json",
        type:"POST",
        data:{cattle_id:cattle_id},
        url:"<?= base_url('Login/GetBreeds/'); ?>",
        success:function(data)
        {
                   // alert(data);
              $('.breed_id').empty();
              $('.breed_id').append('<option value="">-select-</option>');
              $.each(data, function(key, value) {
              $('.breed_id').append('<option value="'+ value.breed_id +'">'+value.breed_name+'</option>');
              });
              
        }

      });
    }else{
                 $('.breed_id').empty();
            }
}
function GetStations(vl)
{
  var directorate_id = vl;
    if(directorate_id!='') {
    $.ajax({
        dataType:"json",
        type:"POST",
        data:{directorate_id:directorate_id},
        url:"<?= base_url('Login/getStations/'); ?>",
        success:function(data)
        {
                   // alert(data);
                   $('.center_station_id').empty();
                    $('.center_station_id').append('<option value="">-select-</option>');
              $.each(data, function(key, value) {
              $('.center_station_id').append('<option  value="'+ value.center_station_id +'">'+value.center_station_name+'</option>');
              });
              
        }

      });
    }else{
            $('.center_station_id').empty();
        }
}

function GetSections(vl)
{
  var center_station_id = vl;
  // alert(center_station_id);
    if(center_station_id!='') {
    $.ajax({
        dataType:"json",
        type:"POST",
        data:{center_station_id:center_station_id},
        url:"<?= base_url('Login/GetSections/'); ?>",
        success:function(data)
        {
                   // alert(data);
              $('.section_id').empty();
              $('.section_id').append('<option value="">-select-</option>');
              $.each(data, function(key, value) {
              $('.section_id').append('<option value="'+ value.section_id +'">'+value.sectionHelp_name+'</option>');
              });
              
        }

      });
    }else{
                 $('.section_id').empty();
            }
}
function GetLabs(vl)
{
  var section_id = vl;
  // alert(testid);
    if(section_id!='') {
    $.ajax({
        dataType:"json",
        type:"POST",
        data:{section_id:section_id},
        url:"<?= base_url('Login/getLabs/'); ?>",
        success:function(data)
        {
              $('.lab_id').empty();
              $('.lab_id').append('<option value="">-select-</option>');
              $.each(data, function(key, value) {
              $('.lab_id').append('<option value="'+ value.lab_id +'">'+value.lab_name+'</option>');
              });
              
        }

      });
    }else{
                $('.lab_id').empty();
            }
}

</script>
<script>
  $(document).ready(function(){
      $('.datepicker').datepicker();
// $('input[id$=tbDate]').datepicker({
//     dateFormat: 'dd/mm/yy'
// });

      var type = $('#client_type').val();
      if(type=='')
      {
        $('#source_row').hide();
        $('#source_info').hide();
      }
      else if(type=='farmer')
      { 
          $('#source_row').show();
          $('#source_info').show();
          $('#source_info').html('Source Info');  
          $('.div_source_cnic').show();
          $('.div_source_Name').show();
          $('.div_source_contact').show();
          $('.div_source_address').show();
          $('.div_deptName').hide();
          $('.div_dept_phone').hide();
      }else if(type=='own_dept')
      {
          $('#source_row').show();
          $('#source_info').show();
          $('#source_info').html('Own Department Info');
          $('.div_deptName').show();
          $('.div_dept_phone').show();
          $('.div_source_cnic').hide();
          $('.div_source_Name').hide();
          $('.div_source_contact').hide();
          $('.div_source_address').hide();
      }else if(type=='other_dept')
      {
          $('#source_row').show();
          $('#source_info').show();
          $('#source_info').html('Other Department Info');
          $('.div_source_cnic').show();
          $('.div_source_Name').show();
          $('.div_deptName').show();
          $('.div_source_contact').show();
          $('.div_dept_phone').show();
          $('.div_source_address').show();
      }
  });

</script>


      
  
<script>
function GetClientType(vl)
{
  // var type = $('#client_type').val();
  var type = vl;
  if(type=='')
  {
      $('#source_row').hide();
      $('#source_info').hide();
  }
  else if(type=='farmer')
  { 
      $('#source_row').show();
      $('#source_info').show();
      $('#source_info').html('Source Info');  
      $('.div_source_cnic').show();
      $('.div_source_Name').show();
      $('.div_source_contact').show();
      $('.div_source_address').show();
      $('.div_deptName').hide();
      $('.div_dept_phone').hide();
  }else if(type=='own_dept')
  {
      $('#source_row').show();
      $('#source_info').show();
      $('#source_info').html('Own Department Info');
      $('.div_deptName').show();
      $('.div_dept_phone').show();
      $('.div_source_cnic').hide();
      $('.div_source_Name').hide();
      $('.div_source_contact').hide();
      $('.div_source_address').hide();
  }else if(type=='other_dept')
  {
      $('#source_row').show();
      $('#source_info').show();
      $('#source_info').html('Other Department Info');
      $('.div_source_cnic').show();
      $('.div_source_Name').show();
      $('.div_deptName').show();
      $('.div_source_contact').show();
      $('.div_dept_phone').show();
      $('.div_source_address').show();
  }
  // alert(type);
}
function GetSample()
{
  var testid = $('#test_id').val();
  // alert(testid);
    if(testid!='') {
    $.ajax({
        dataType:"json",
        type:"POST",
        data:{test_id:testid},
        url:"<?= base_url('Login/getTestSamples/'); ?>",
        success:function(data)
        {
                   // alert(data);
              $('#test_sample_id').html('<option value="">-select-</option>');
              $.each(data, function(key, value) {
              $('#test_sample_id').append('<option value="'+ value.sample_id +'">'+value.sample_name+'</option>');
              });
              
        }

      });
    }else{
                $('#test_sample_id').empty();
                $("#impression_smear").hide();
                $('#test_sample_id').empty();
                $("#mastitis").hide();
                $('#test_sample_id').empty();
                $("#haematology").hide();
                $('#test_sample_id').empty();
                $("#culture_sensitivity").hide();
                $('#test_sample_id').empty();
                $("#urine_examination").hide();
                $('#test_sample_id').empty();
                $("#brucella_animal_combine").hide();
                $('#test_sample_id').empty();
                $("#Brucell_Animal_ind").hide();
                $('#test_sample_id').empty();
                $("#brucella_human").hide();
                $('#test_sample_id').empty();
                $("#tb_and_vph").hide();
              $("#impression_smear,#mastitis,#haematology,#culture_sensitivity,#urine_examination,#brucella_animal_combine,#Brucell_Animal_ind,#brucella_human,#tb_and_vph").find(":text, select").each(function () {
                 $(this).prop('required',false);
              });
            }

    if(testid==1)
    {
      $("#impression_smear").show(1000);
      $("#impression_smear").find(":text, select").each(function () {
                 $(this).prop('required',true);
              });
     
    }
    else
    {
      $("#impression_smear").hide();
      $('#test_sample_id').empty();
      $("#impression_smear").find(":text, select").each(function () {
                 $(this).prop('required',false);
              });
     
    }
    if(testid==2)
    {
       
      $("#haematology").show(1000);
      $("#haematology").find(":text, select").each(function () {
                 $(this).prop('required',true);
              });
     
    }
    else
    {
     
      $("#haematology").hide();
      $('#test_sample_id').empty();
      $("#haematology").find(":text, select").each(function () {
                 $(this).prop('required',false);
              });
      
    }
    if(testid==3)
    {
      $("#mastitis").show(1000);
      $("#mastitis").find(":text, select").each(function () {
                 $(this).prop('required',true);
              });
     
    }
    else
    {
     
      $("#mastitis").hide();
      $('#test_sample_id').empty();
      $("#mastitis").find(":text, select").each(function () {
                 $(this).prop('required',false);
              });
      
    }
    if(testid==4)
    {
      
      
      $("#culture_sensitivity").show(1000);
      $("#culture_sensitivity").find(":text, select").each(function () {
                 $(this).prop('required',true);
              });
     
    }
    else
    {
     
      $("#culture_sensitivity").hide();
      $('#test_sample_id').empty();
      $("#culture_sensitivity").find(":text, select").each(function () {
                 $(this).prop('required',false);
              });
      
    }
    if(testid==5)
    {
      
      
      $("#urine_examination").show(1000);
      $("#urine_examination").find(":text, select").each(function () {
                 $(this).prop('required',true);
              });
     
    }
    else
    {
     
      $("#urine_examination").hide();
      $('#test_sample_id').empty();
      $("#urine_examination").find(":text, select").each(function () {
                 $(this).prop('required',false);
              });
      
    }

    if(testid==6)
    {
      
      
      $("#brucella_animal_combine").show(1000);
      $("#brucella_animal_combine").find(":text, select").each(function () {
                 $(this).prop('required',true);
              });
     
    }
    else
    {
     
      $("#brucella_animal_combine").hide();
      $('#test_sample_id').empty();
      $("#brucella_animal_combine").find(":text, select").each(function () {
                 $(this).prop('required',false);
              });
      
    }
    if(testid==7)
    {
      
      
      $("#Brucell_Animal_ind").show(1000);
      $("#Brucell_Animal_ind").find(":text, select").each(function () {
                 $(this).prop('required',true);
              });
     
    }
    else
    {
     
      $("#Brucell_Animal_ind").hide();
      $('#test_sample_id').empty();
      $("#Brucell_Animal_ind").find(":text, select").each(function () {
                 $(this).prop('required',false);
              });
      
    }
    if(testid==8)
    {
      
      
      $("#brucella_human").show(1000);
      $("#brucella_human").find(":text, select").each(function () {
                 $(this).prop('required',true);
              });
     
    }
    else
    {
     
      $("#brucella_human").hide();
      $('#test_sample_id').empty();
      $("#brucella_human").find(":text, select").each(function () {
                 $(this).prop('required',false);
              });
      
    }
    if(testid==9)
    {
      
      
      $("#tb_and_vph").show(1000);
      $("#tb_and_vph").find(":text, select").each(function () {
                 $(this).prop('required',true);
              });
     
    }
    else
    {
     
      $("#tb_and_vph").hide();
      $('#test_sample_id').empty();
      $("#tb_and_vph").find(":text, select").each(function () {
                 $(this).prop('required',false);
              });
      
    }
}

$(document).ready(function(){
  // $(".HideForms").hide();
  GetSample();
  $('#test_id').change();
  
  
});

</script>

</body>
</html>