<?php 
// echo"<pre>";
// print_r($logUser);
// exit();
 $status      = '';
 $status_date = '';
 $color       = '';
  if($rec['testDetails']->post_status==0 && $rec['testDetails']->is_cancel==0)
  {
    $status      = 'IN PROGRESS';
    $color       = 'warning';
    $status_date = '';
  }else if($rec['testDetails']->post_status==0 && $rec['testDetails']->is_cancel==1)
  {
    $status      = 'CANCELLED';
    $color       = 'danger';
    $status_date = '';
  }else if($rec['testDetails']->post_status==1 && $rec['testDetails']->is_cancel==0)
  {
    $status      = 'POSTED';
    $color       = 'success';
    $status_date = date('M d Y',strtotime($rec['testDetails']->posted_date));
  }
 ?>
<style type="text/css">
#bg-text
{
    position:relative;
    z-index:0;
    font-size:70px;
    margin-top: -120px !important;
    margin-left: 100px !important;
    transform:rotate(300deg );
    -webkit-transform:rotate(300deg);
    opacity: 0.3;
}
</style>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper" >
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Invoice</h1>
          </div>
          <!-- <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Invoice</li>
            </ol>
          </div> -->
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- <div class="callout callout-info"> -->
              <!-- <h5><i class="fa fa-info"></i> Note:</h5>
              This page has been enhanced for printing. Click the print button at the bottom of the invoice to test.
            </div> -->


            <!-- Main content -->
            <div class="invoice p-3 mb-3">
              <!-- title row -->
               <div class="row">
                <div class="col-3">
                  <small class="float-left">Date: <?= date('M d Y'); ?></small>
                </div>
                 <div class="col-6" style="text-align: center;">
                    <strong>
                      <?= $logLab->directorate_name; ?>
                    </strong><br>
                     <strong>
                      <?= $logLab->center_station_name; ?>
                    </strong><br>
                     <strong>
                      <?= $logLab->sectionHelp_name; ?>
                    </strong><br>
                     <strong>
                      (<?= $logLab->lab_name; ?>)
                    </strong>
                </div>
                 <div class="col-3">
                   <small class="float-right">Lab #: <?= $logLab->lab_id; ?></small>
                </div>
                <!-- /.col -->
              </div>
              <hr>
              <!-- <div class="row">
                <div class="col-12">
                  <h4>
                    <i class="fa fa-globe"></i> AdminLTE, Inc.
                    <small class="float-right">Date: <?= date('M d Y'); ?></small>
                  </h4>
                </div>
              </div> -->
              <!-- info row -->
              <div class="row invoice-info">
                <div class="col-sm-4 invoice-col">
                  <b class="text-primary">Client Info</b>
                   <table class=" table-responsive">
                    <tbody>
                    <tr>
                      <th>Name:   </th>
                      <td><?=  $rec['testDetails']->client_name; ?></td>
                      </tr><tr>
                      <th>Contact:  </th>
                      <td><?=  $rec['testDetails']->client_contact; ?></td>
                      </tr><tr>
                      <th>Cnic:   </th>
                      <td><?=  $rec['testDetails']->client_cnic; ?></td>
                      </tr><tr>
                      <th>Address:  </th>
                      <td><?=  $rec['testDetails']->client_address; ?></td>
                      </tr><tr>
                      <th>Referred by:  </th>
                      <td><?=  $rec['testDetails']->referred_by; ?></td>
                      </tr><tr>
                      <th>Examined for:   </th>
                      <td><?=  $rec['testDetails']->test_fee; ?></td>
                    </tr>
                    </tbody>
                  </table>
                </div>
                <!-- /.col -->

                <div class="col-sm-4 invoice-col">
                  <b class="text-primary">Cattle Info</b>
                  <table class=" table-responsive">
                    <tbody>
                    <tr>
                      <th>Name:   </th>
                      <td><?=  $rec['testDetails']->cattle_name; ?></td>
                    </tr>
                    <tr>
                      <th>Tag #:  </th>
                      <td><?=  $rec['testDetails']->cattle_tag_no; ?></td>
                    </tr>
                    <tr>
                      <th>Sex:   </th>
                      <td><?=  $rec['testDetails']->cattle_sex; ?></td>
                    </tr>
                    <tr>
                      <th>Age:  </th>
                      <td><?=  $rec['testDetails']->cattle_age; ?></td>
                    </tr>
                    <tr>
                      <th>Breed:  </th>
                      <td><?=  $rec['testDetails']->breed_name; ?></td>
                    </tr>
                    <tr>
                      <th>Total #:   </th>
                      <td><?=  $rec['testDetails']->cattle_total_no; ?></td>
                    </tr>
                    </tbody>
                  </table>
                </div>
                <!-- /.col -->
                <div class="col-sm-4 invoice-col">
                  <b class="text-primary">Invoice Info</b>
                  <table class=" table-responsive">
                    <tbody>
                    <tr>
                      <th>Invoice #:  </th>
                      <td><?=  $rec['testDetails']->testDetails_id; ?></td>
                    </tr>
                    <tr>
                      <th>Status:   </th>
                      <td><span class="badge bg-<?= $color; ?>" style="font-color: white;"><?= $status; ?></span></td>
                    </tr>
                    <tr>
                      <th>Post Date:   </th>
                      <td><span  style=""><?= $status_date; ?></span></td>
                    </tr>
                    <tr>
                      <th>Received Date:   </th>
                      <td> <?= date('M d Y',strtotime($rec['testDetails']->received_date)); ?></td>
                    </tr>
                    <tr>
                      <th>Result Date:  </th>
                      <td><?= date('M d Y',strtotime($rec['testDetails']->result_date)); ?></td>
                    </tr>
                    </tbody>
                  </table>
                 
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->
              <p id="bg-text" class="text-<?= $color; ?>"><?= $status; ?></p>
<br>
              <!-- Table row -->
              <b class="text-primary">Test Info</b><br><br>
            <b style="text-decoration: underline;"><?=  strtoupper($rec['testDetails']->testHelp_name); ?></b><br><br>
              <div class="row">
                <div class="col-12">
              <?php
                if($rec['testDetails']->testHelp_id==1)
                {
              ?>
                  <table class="table">
                    <thead>
                    <tr>
                      <th>Test Conduct</th>
                      <th>Sample</th>
                      <th>Type of Specimen</th>
                      <th>Animals Specimen</th>
                      <th>Examined for</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                      <td><?=  $rec['testDetails']->testHelp_name; ?></td>
                      <td><?=  $rec['testDetails']->sample_name; ?></td>
                      <td><?=  $rec['testType']->type_specimen; ?></td>
                      <td><?=  $rec['testType']->animals_specimen; ?></td>
                      <td><?=  $rec['testType']->examined_for; ?></td>
                    </tr>
                    </tbody>
                  </table>
              <?php
              } else if ($rec['testDetails']->testHelp_id==2) {
            ?>
            <table class="table table-hover table-condenced table-responsive">
              <tbody>
                <tr >
                  <th># </th>
                      <td><?= $rec['testType']->haemoglobin; ?></td>     
                  <th>haemoglobin</th>     
                      <td><?= $rec['testType']->haemoglobin; ?></td>     
                  <th>ESR</th>             
                      <td><?= $rec['testType']->ESR; ?></td>
                   <tr>
                  </tr>             
                  <th>TRBC</th>            
                      <td><?= $rec['testType']->TRBC; ?></td>            
                  <th>TLC</th>             
                      <td><?= $rec['testType']->TLC; ?></td>             
                  <th>PCV</th>             
                      <td><?= $rec['testType']->PCV; ?></td> 
                  <tr>
                  </tr>            
                  <th>neutrophils</th>     
                      <td><?= $rec['testType']->neutrophils; ?></td>     
                  <th>lymphocytes</th>     
                      <td><?= $rec['testType']->lymphocytes; ?></td>     
                  <th>eosinophils</th>     
                      <td><?= $rec['testType']->eosinophils; ?></td> 
                   <tr>
                  </tr>    
                  <th>monocytes</th>       
                      <td><?= $rec['testType']->monocytes; ?></td>       
                  <th>basophils</th>       
                      <td><?= $rec['testType']->basophils; ?></td>       
                  <th>protozoa</th>        
                      <td><?= $rec['testType']->protozoa; ?></td>        
                  <th>iodine flocculation test</th> 
                      <td><?= $rec['testType']->iodine_flocculation_test; ?></td> 
                </tr>
               
                 
                </tbody>
            </table>
            <?php
              }else if ($rec['testDetails']->testHelp_id==3) {
            ?>
            <table class="table table-hover table-condenced">
               <tbody>
                <tr>
                  <th># </th>
                  <td><?= $rec['testType']->mastitis_id;    ?></td>
                  <th>daily_milk_production</th>        
                    <td><?= $rec['testType']->daily_milk_production; ?></td>        
                </tr>
                <tr>               
                  <th>lactation_no</th>                 
                    <td><?= $rec['testType']->lactation_no; ?></td>  
                  <th>total_animals_at_farm</th>        
                    <td><?= $rec['testType']->total_animals_at_farm; ?></td>     
                     </tr>
                <tr>    
                  <th>in_milk</th>                      
                    <td><?= $rec['testType']->in_milk; ?></td>                      
                  <th>dry_period_given</th>             
                    <td><?= $rec['testType']->dry_period_given; ?></td>    
                  </tr>
                <tr>         
                  <th>cal_kid_lambing_date</th>         
                    <td><?= $rec['testType']->cal_kid_lambing_date; ?></td>         
                  <th>prev_mastatis_rec_of_anim</th>    
                    <td><?= $rec['testType']->prev_mastatis_rec_of_anim; ?></td>    
                  </tr>
                <tr> 
                  <th>prev_mastatis_rec_of_farm</th>    
                    <td><?= $rec['testType']->prev_mastatis_rec_of_farm; ?></td>   
                  <th>prac_mastatis_test_at_farm</th>   
                    <td><?= $rec['testType']->prac_mastatis_test_at_farm; ?></td>   
                    </tr>
                <tr>           
                  <th>sample_received</th>              
                    <td><?= $rec['testType']->sample_received; ?></td>   
                  <th>test_required</th>                
                    <td><?= $rec['testType']->test_required; ?></td>       
                     </tr>
                <tr>           
                  <th>refer_to_bacteriology_sec_for</th>
                    <td><?= $rec['testType']->refer_to_bacteriology_sec_for; ?></td>
                </tr>
              
                
                </tbody>
            </table>
            <?php
              }else if ($rec['testDetails']->testHelp_id==4) {
            ?>
            <table class="table table-hover table-condenced">
              <thead>
                <tr class="bg-success">
                  <th># </th>
                  <th>antibiotics_id</th> 
                  <th>sensitivity</th>    
                  <th>tested_by</th>      
                  <th>reports</th>  
                </tr>
                <tbody>
                  <tr>
                    <td><?= $rec['testType']->antibiotics_id; ?> </td> 
                    <td><?= $rec['testType']->antibiotics_id; ?> </td> 
                    <td><?= $rec['testType']->sensitivity; ?> </td>    
                    <td><?= $rec['testType']->tested_by; ?> </td>      
                    <td><?= $rec['testType']->reports; ?> </td> 
                  </tr>
                </tbody>
              </thead>
            </table>
            <?php
              }else if ($rec['testDetails']->testHelp_id==5) {
            ?>
            <table class="table table-hover table-condenced">
              <tbody>
                <tr >
                  <th># </th>
                      <td><?= $rec['testType']->colour;  ?></td>
                  <th>colour</th>          
                      <td><?= $rec['testType']->colour;  ?></td>
                   </tr>
                  <tr>
                  <th>appearance</th>      
                      <td><?= $rec['testType']->appearance;  ?></td>
                  <th>reaction</th>        
                      <td><?= $rec['testType']->reaction;  ?></td>
                       </tr>
                  <tr>
                  <th>specific_gravity</th>
                      <td><?= $rec['testType']->specific_gravity;  ?></td>
                  <th>glucose</th>         
                      <td><?= $rec['testType']->glucose;  ?></td>
                       </tr>
                  <tr>
                  <th>protein</th>         
                      <td><?= $rec['testType']->protein;  ?></td>
                  <th>bile_salts</th>      
                      <td><?= $rec['testType']->bile_salts;  ?></td>
                       </tr>
                  <tr>
                  <th>bile_pigments</th>   
                      <td><?= $rec['testType']->bile_pigments;  ?></td>
                  <th>ketone_bodies</th>   
                      <td><?= $rec['testType']->ketone_bodies;  ?></td>
                       </tr>
                  <tr>
                  <th>haemoglobin</th>     
                      <td><?= $rec['testType']->haemoglobin;  ?></td>
                  <th>pus_cell</th>        
                      <td><?= $rec['testType']->pus_cell;  ?></td>
                       </tr>
                  <tr>
                  <th>epithelial_cell</th> 
                      <td><?= $rec['testType']->epithelial_cell;  ?></td>
                  <th>rb_cs</th>           
                      <td><?= $rec['testType']->rb_cs;  ?></td>
                       </tr>
                  <tr>
                  <th>casts</th>           
                      <td><?= $rec['testType']->casts;  ?></td>
                  <th>crystals</th>        
                      <td><?= $rec['testType']->crystals;  ?></td>
                       </tr>
                  <tr>
                  <th>amorphous</th>       
                      <td><?= $rec['testType']->amorphous;  ?></td>
                  <th>parasites</th>       
                      <td><?= $rec['testType']->parasites;  ?></td>
                       </tr>
                  <tr>
                  <th>bacteria</th>        
                      <td><?= $rec['testType']->bacteria;  ?></td>
                  <th>remarks</th>        
                      <td><?= $rec['testType']->remarks;  ?></td>
                       </tr>
                  <tr>
                  <th>examined_by</th>  
                      <td><?= $rec['testType']->examined_by;  ?></td>
               
                  </tr>
                </tbody>
             
            </table>
            <?php
              }else if ($rec['testDetails']->testHelp_id==6) {
            ?>
            <table class="table table-hover table-condenced">
             <tbody>
                <tr>
                  <th># </th>
                    <td><?= $rec['testType']->tag_no;  ?></td>
                  <th>tag_no</th>
                    <td><?= $rec['testType']->tag_no;  ?></td>
                  <th>vac_against_brucellosis</th>
                    <td><?= $rec['testType']->vac_against_brucellosis;  ?></td>
                      </tr>
                    <tr>
                  <th>sample</th>
                    <td><?= $rec['testType']->sample;  ?></td>
                  <th>species</th>
                    <td><?= $rec['testType']->species;  ?></td>
                  <th>technician</th>
                    <td><?= $rec['testType']->technician;  ?></td>
                    </tr>
                     <tr>
                  <th>remarks</th>
                    <td><?= $rec['testType']->remarks;  ?></td>
                  <th>result</th>
                    <td><?= $rec['testType']->result;  ?></td>
                  <th>history</th>
                    <td><?= $rec['testType']->history;  ?></td>
                </tr>
                </tbody>
              
            </table>
            <?php
              }else if ($rec['testDetails']->testHelp_id==7) {
            ?>
            <table class="table table-hover table-condenced">
              <thead>
                <tr class="bg-success">
                  <th># </th>
                  <th>tag_no</th>                  
                  <th>vac_against_brucellosis</th> 
                  <th>sample</th>                  
                  <th>parity</th>                  
                  <th>technician</th>              
                  <th>result</th>                  
                  <th>history</th>  
                </tr>
                <tbody>
                  <tr>
                      <td><?= $rec['testType']->tag_no; ?></td>
                      <td><?= $rec['testType']->tag_no; ?></td>
                      <td><?= $rec['testType']->vac_against_brucellosis; ?></td>
                      <td><?= $rec['testType']->sample; ?></td>
                      <td><?= $rec['testType']->parity; ?></td>
                      <td><?= $rec['testType']->technician; ?></td>
                      <td><?= $rec['testType']->result; ?></td>
                      <td><?= $rec['testType']->history; ?></td> 
                  </tr>
                </tbody>
              </thead>
            </table>
            <?php
              }else if ($rec['testDetails']->testHelp_id==8) {
            ?>
            <table class="table table-hover table-condenced">
              <thead>
                <tr >
                  <th># </th>
                    <td><?= $rec['testType']->brucella_abortus_20; ?></td>    
                  <th>brucella_abortus_20</th>
                    <td><?= $rec['testType']->brucella_abortus_20; ?></td>    
                  <th>brucella_abortus_40</th>
                    <td><?= $rec['testType']->brucella_abortus_40; ?></td>    
                  <th>brucella_abortus_80</th>
                    <td><?= $rec['testType']->brucella_abortus_80; ?></td>    
                  <th>brucella_abortus_160</th>
                    <td><?= $rec['testType']->brucella_abortus_160; ?></td>   
                  <th>brucella_abortus_320</th>
                    <td><?= $rec['testType']->brucella_abortus_320; ?></td>   
                  <th>brucella_meletensis_20</th>
                    <td><?= $rec['testType']->brucella_meletensis_20; ?></td> 
                  <th>brucella_meletensis_40</th>
                    <td><?= $rec['testType']->brucella_meletensis_40; ?></td> 
                  <th>brucella_meletensis_80</th>
                    <td><?= $rec['testType']->brucella_meletensis_80; ?></td> 
                  <th>brucella_meletensis_160</th>
                    <td><?= $rec['testType']->brucella_meletensis_160; ?></td>
                  <th>brucella_meletensis_320</th>
                    <td><?= $rec['testType']->brucella_meletensis_320; ?></td>
                  <th>result_status</th>
                    <td><?= $rec['testType']->result_status; ?></td>          
                </tr>
                <tbody>
                  <tr>
                  </tr>
                </tbody>
              </thead>
            </table>
            <?php
              }else if ($rec['testDetails']->testHelp_id==9) {
            ?>
            <table class="table table-hover table-condenced">
              <thead>
                <tr class="bg-success">
                  <th># </th>
                  <th>symptoms</th>     
                  <th>specimen</th>     
                  <th>lab_findings</th> 
                  <th>referred_by</th>  
                  <th>examined_by</th>  
                  <th>remarks</th> 
                </tr>
                <tbody>
                  <tr>
                      <td><?= $rec['testType']->symptoms; ?></td>     
                      <td><?= $rec['testType']->symptoms; ?></td>     
                      <td><?= $rec['testType']->specimen; ?></td>     
                      <td><?= $rec['testType']->lab_findings; ?></td> 
                      <td><?= $rec['testType']->referred_by; ?></td>  
                      <td><?= $rec['testType']->examined_by; ?></td>  
                      <td><?= $rec['testType']->remarks; ?></td>  
                  </tr>
                </tbody>
              </thead>
            </table>
            <?php
              }
            ?>
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->

              <div class="row">
                <!-- accepted payments column -->
                <div class="col-6">
                  <b class="text-primary" style="font-size: 18px;">Recommendations</b>
                  <p class="text-muted well well-sm no-shadow" style="margin-top: 10px;">
                    <?=  $rec['testDetails']->recommendations; ?>
                  </p>
                  <b class="text-primary" style="font-size: 18px;">Additional Info</b>
                  <p class="text-muted well well-sm no-shadow" style="margin-top: 10px;">
                    <?=  $rec['testDetails']->additional_info; ?>
                  </p>
                </div>
                <!-- /.col -->
                <div class="col-6">
                  <!-- <p class="lead">Amount Due 2/22/2014</p> -->

                  <div class="table-responsive">
                    <table class="table">
                      <tr>
                        <th>Total Charges:</th>
                        <td><?=  number_format($rec['testDetails']->test_total_fee,2); ?></td>
                      </tr>
                    </table>
                  </div>
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->

              <!-- this row will not appear when printing -->
                <hr>  
              <div class="row no-print">
                <div class="col-12">
                  <a href="javascript:void(0);" onclick="printPage();"   class="btn btn-default"><i class="fa fa-print"></i> Print</a>
                  <?php
                    if($rec['testDetails']->post_status==0 && $rec['testDetails']->is_cancel==0)
                    {
                  ?>
                    <button type="button" class="btn btn-danger float-right" data-backdrop="static" data-keyboard="false" data-toggle="modal" href="#cancelModal" ><i class="fa fa-remove"></i> Cancel Invoice
                    </button>
                      <button type="button" onclick="SubmitPost();" class="btn btn-success float-right" style="margin-right: 5px;">
                      <i class="fa fa-send"></i> Post Invoice
                    </button>
                  <?php
                    }
                  ?>
                </div>
              </div>
            </div>
            <!-- /.invoice -->
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
<div class="modal" id="cancelModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Cancel Reason</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form action="<?=  base_url('Tests/TestRecordCancel') ?>" method="post">
          <input type="hidden" name="testDetails_id" value="<?= $rec['testDetails']->testDetails_id;?>"> 
          <input type="hidden" name="uri" value="<?= $this->uri->segment(2);?>"> 
         <div class="box-body">
            <div class="col-sm-12 form-group">
              <!-- <label></label> -->
              <textarea name="cancel_reason" placeholder="Write in short words" class="form-control" required="required"></textarea>
            </div>
            <div class="form-group">
              <button type="submit"  onclick="return confirm('Are you sure to Cancel the Record?');"  class="btn btn-info pull-right">Submit</button>
            </div>
         </div>
        </form>
      </div>

      <!-- Modal footer -->
     <!--  <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div> -->

    </div>
  </div>
</div>

<form id="postForm" action="<?php echo base_url('Tests/TestRecordPost') ?>" method="post">
  <input type="hidden" name="testDetails_id" value="<?= $rec['testDetails']->testDetails_id;?>"> 
   <input type="hidden" name="uri" value="<?= $this->uri->segment(2);?>">
</form>

<script type="text/javascript">
  function SubmitPost()
  {
    if(confirm('Warning! Your will not be able to update it, Once you posted')==true)
    {
       $('#postForm').submit();
    }
  }

  function printPage()
  {
    window.print();

  }
</script>