
<div class="content-wrapper">
    <section class="content-header">
      <h1>
    <!-- Register New Test  -->
        
      </h1>
     
    </section>

    <!-- Main content -->
<section class="content">
    <div class="row">
      <div class="col-3">
        <small class="float-left">Date: <?= date('M d Y'); ?></small>
      </div>
       <div class="col-6" style="text-align: center;">
        
      </div>
       <div class="col-3">
         <small class="float-right">Lab #: <?= $logLab->lab_id; ?></small>
      </div>
      <!-- /.col -->
    </div>
    <hr>
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="card">
             


            <div class="card-header with-border">
              <b> Register New Test</b>
               <?php include'MessageAlert.php'; ?>

            </div>
                 <form action="<?= base_url('Tests/AddNewTestRec'); ?>" method="post"  enctype="multipart/form-data" >
        <div class="card-body">
          <div class="row"> 
            <div class="col-md-12">
              <div class="row">
                 <div class="col-sm-12 form-group">
                    <label>Source Type</label>
                     <select class="form-control" id="client_type" onchange="GetClientType(this.value)" style="width: 100% !important"  name="client_type" required>
                        <option value="">-Select-</option>
                        <option value="farmer">Farmer</option>
                        <option value="own_dept">Own Departmentt</option>
                        <option value="other_dept">Other Department</option>
                      </select>
                 </div>
              </div>
              <b class="text-success" id="source_info">Source Info</b>
                <hr>
               <div class="row" id="source_row">
                     <div class="col-sm-3 form-group div_deptName">
                    <label id="label_deptName">Department Name</label>
                    <input type="text" name="dept_name" placeholder="Enter  Department Name" class="form-control dept_name" >
                    </div>
                    <div class="col-sm-3 form-group div_source_cnic">
                    <label>Source CNIC#</label>
                    <input type="text" name="client_cnic" id="client_cnic" onblur="GetClient_cnic()"  placeholder="Enter  CNIC#" class="form-control clientCnic" maxlength="13">
                    </div>
                   <div class="col-sm-3 form-group div_source_Name">
                    <label id="label_name">Source Name</label>
                    <input type="text" name="client_name" id="client_name" placeholder="Enter  Name" class="form-control client_name" >
                    </div>
                    <div class="col-sm-3 form-group div_source_contact">
                    <label id="label_contact">Source Contact#</label>
                    <input type="text" name="client_contact" id="client_contact"  placeholder="Enter  Contact" class="form-control client_contact" maxlength="11" >
                    </div>
                    <div class="col-sm-3 form-group div_dept_phone">
                    <label id="deptPhone">Department Phone#</label>
                    <input type="text" name="dept_phone" id="deptPhone"  placeholder="Enter  Phone#" class="form-control" maxlength="11" >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Referred by</label>
                    <input type="text" name="referred_by"  placeholder="Enter Referred by" class="form-control referred_by">
                    </div>
                    <div class="col-sm-3 form-group div_source_address">
                    <label id="client_address">Source Address</label>
                    <input type="text" name="client_address"  placeholder="Enter Address" class="form-control client_address">
                    </div>
                </div>
              <div class="row">
                
                    <div class="col-sm-4 form-group">
                    <label>Test Name</label>
                     <select class="form-control" id="test_id" style="width: 100% !important" onchange="GetSample()" name="test_id" required>
                        <option value="">-Select-</option>
                        <?php 
                          if(!empty($tests))
                          {

                          foreach ($tests as $test) {
                        ?>
                            <option value="<?php echo $test->test_id; ?>"><?php echo $test->testHelp_name; ?></option>
                        <?php 
                           }
                          }

                        ?>
                      </select>
                    </div>
                     <div class="col-sm-4 form-group">
                        <label>Sample</label>
                        <select class="form-control " id="test_sample_id" style="width: 100% !important" name="sample_id" required>
                          <option value="">-select-</option>
                        </select>
                    </div>
                     <div class="col-sm-4 form-group">
                          <label>Sample Desc/Details</label>
                        <textarea name="sample_desc" rows="2" cols="10" class="form-control"></textarea>
                    </div>
                     <div class="col-sm-4 form-group">
                    <label>Test Total Fee</label>
                    <input type="number" name="test_total_fee"  onBlur="if (this.value < 1) { this.value = '0.00';}" value="0.00"  placeholder="Enter Test Fee" class="form-control testPrice" required>
                    </div>
                    <div class="col-sm-4 form-group">
                    <label>Received Date</label>
                    <input type="text" name="received_date"   placeholder="Enter Date" value="<?= date('d/m/Y') ?>" id="tbDate" class="form-control  datepicker" required>
                    </div>
                     <div class="col-sm-6 form-group">
                    <label>Additional Info</label>
                    <textarea name="additional_info" class="form-control"></textarea>
                    </div>
                </div>
              
                <b class="text-success">Animal Info</b>
                <hr>
                <div class="row">
                    <div class="col-sm-4 form-group">
                      <label>Animal </label>
                        <select class="form-control cattle_id" onchange="GetBreeds(this.value);"  name="cattle_name"  style="width: 100%" >
                          <option value="">-select-</option>
                        <?php 
                        foreach ($cattles as $cattle) {
                          # code...
                          ?>
                          <option  value="<?php echo $cattle->cattle_id; ?>"><?php echo $cattle->cattle_name; ?></option>
                          <?php 
                        }

                         ?>
                      </select>
                    </div>  
                    <div class="col-sm-4 form-group">
                      <label> Breed</label>
                       <select class="form-control breed_id"  name="cattle_breed"  style="width: 100%" >
                        <option  value="">-select-</option>
                      </select>
                    </div> 
                    <div class="col-sm-4 form-group">
                      <label> Tag#</label>
                      <input type="text" name="cattle_tag_no"  placeholder="Enter Cattle Tag No" class="form-control " >
                    </div>   
                    <div class="col-sm-4 form-group">
                      <label> Sex</label>
                      <select class="form-control"  name="cattle_sex"  style="width: 100%" required>
                          <option value="">-select-</option>
                          <option value="Male">Male</option>
                          <option value="Female">Female</option>
                      </select>

                    </div>   
                    <div class="col-sm-4 form-group">
                      <label> Age</label>
                      <input type="text" name="cattle_age"  placeholder="Enter Cattle Age" class="form-control " >
                    </div>   

                     <div class="col-sm-4 form-group">
                      <label> Total #</label>
                      <input type="text" name="cattle_total_no" placeholder="Enter Cattle Total No" class="form-control " >
                    </div>
                </div>
                 <b class="text-success">Test Info</b>
                <hr>
                

                <div class="row" id="fimpression_smear">
                   <b class="text-success">impression smear Info</b>
                <hr>

                    <div class="row">
                    <div class="col-sm-4 form-group">

                      
                      <label>Type of Specimen </label>
                      <input type="text" name="type_specimen"  placeholder="Enter Type of Specimen" class="form-control " >
                    </div>   
                    <div class="col-sm-4 form-group">
                      <label>Animals Specimen</label>
                      <input type="text" name="animals_specimen"  placeholder="Enter Animals Specimen" class="form-control " >
                    </div>   
                    <div class="col-sm-4 form-group">
                      <label>Examined for</label>
                      <input type="text" name="examined_for"  placeholder="Enter Examined for" class="form-control " >
                    </div>   
                    <div class="col-sm-4 form-group">
                      <label>Result</label>
                      <input type="text" name="result"  placeholder="Enter Result" class="form-control " >
                    </div>   
                     <div class="col-sm-4 form-group">
                      <label>Remarks</label>
                      <input type="text" name="remarks"  placeholder="Enter Remarks" class="form-control " >
                    </div>
                     <div class="col-sm-4 form-group">
                      <label>Examined by</label>
                      <input type="text" name="examined_by" placeholder="Enter Examined by" class="form-control " >
                    </div>
                   

                     
                
          </div>
        </div>

               <div class="row" id="fmastitis" class="none">
                <hr>
                   <div class="col-sm-3 form-group">
                    <label>Daily Milk Production</label>
                    <input type="text" name="daily_milk_production" placeholder="Daily Milk Production" class="form-control" >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Lactation No#</label>
                    <input type="text" name="lactation_no"  placeholder="Enter Lactation No" class="form-control " >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Total Animals Farm</label>
                    <input type="text" name="total_animals_at_farm"  placeholder="Enter Total Animals Farm" class="form-control " >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>In Milk</label>
                    <input type="text" name="in_milk"  placeholder="Enter In Milk" class="form-control " >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Dry Period Given</label>
                    <input type="text" name="dry_period_given"  placeholder=" Enter Dry Period Given" class="form-control " >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Calving Kidding Lambing date</label>
                    <input type="text" name="cal_kid_lambing_date"   placeholder="Enter Date" class="form-control datepicker" >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Record of Previous Animal</label>
                    <input type="text" name="prev_mastatis_rec_of_anim"  placeholder=" Enter Record of Previous Animal" class="form-control " >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Record of Previous farm</label>
                    <input type="text" name="prev_mastatis_rec_of_farm"  placeholder=" Enter Record of Previous farm" class="form-control " >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Previous Mastatis Test Farm</label>
                    <input type="text" name="prac_mastatis_test_at_farm"  placeholder=" Enter Previous Mastatis Test Farm" class="form-control " >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Sample Received</label>
                    <input type="text" name="sample_received"  placeholder=" Enter Sample Received" class="form-control " >
                    </div> 
                    <div class="col-sm-3 form-group">
                    <label>Test Required</label>
                    <input type="text" name="test_required"  placeholder=" Enter Test Required" class="form-control " >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Refer Bacteriology Section</label>
                    <input type="text" name="refer_to_bacteriology_sec_for"  placeholder=" Enter Test Required" class="form-control " >
                    </div>
                </div>
                 <div class="row"> 
            <div class="col-md-12">
              
               <div class="row" id="fhaematology" class="hnone">
                   <div class="col-sm-3 form-group">
                    <label>Haemoglobin</label>
                    <input type="text" name="haemoglobin" placeholder="Enter Haemoglobin" class="form-control" >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>ESR</label>
                    <input type="text" name="ESR"  placeholder="Enter ESR" class="form-control " >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>TRBC</label>
                    <input type="text" name="TRBC"  placeholder="Enter TRBC" class="form-control " >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>TLC</label>
                    <input type="text" name="TLC"  placeholder="Enter TLC" class="form-control " >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>PCV</label>
                    <input type="text" name="PCV"  placeholder=" Enter PCV" class="form-control " >
                    </div>
                    
                    <div class="col-sm-3 form-group">
                    <label>Neutrophils</label>
                    <input type="text" name="neutrophils"  placeholder=" Enter neutrophils" class="form-control " >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>lymphocytes</label>
                    <input type="text" name="lymphocytes"  placeholder=" Enter lymphocytes" class="form-control " >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Eosinophils</label>
                    <input type="text" name="eosinophils"  placeholder=" Enter eosinophils" class="form-control " >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Monocytes</label>
                    <input type="text" name="monocytes"  placeholder=" Enter monocytes" class="form-control " >
                    </div> 
                    <div class="col-sm-3 form-group">
                    <label>basophils</label>
                    <input type="text" name="basophils"  placeholder=" Enter basophils" class="form-control " >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>protozoa</label>
                    <input type="text" name="protozoa"  placeholder=" Enter protozoa" class="form-control " >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Iodine flocculation Test</label>
                    <input type="text" name="iodine_flocculation_test"  placeholder=" Enter Iodine Flocculation Test" class="form-control " >
                    </div>
                </div>
               
                
                
            </div>
          </div>
             <div class="row" id="fculture_sensitivity">
              <div class="col-sm-3 form-group">
                <label>Intibiotics</label>
                <input type="text" name="intibiotics" placeholder="Enter Intibiotics" class="form-control" >
                </div>
               <div class="col-sm-3 form-group">
                <label>Sensitivity</label>
                <input type="text" name="sensitivity" placeholder="Enter Sensitivity" class="form-control" >
                </div>
                <div class="col-sm-3 form-group">
                <label>Tested by</label>
                <input type="text" name="tested_by"  placeholder="Enter Tested by" class="form-control " >
                </div>
                
                <div class="col-sm-3 form-group">
                <label>Reports</label>
                <input type="text" name="reports"  placeholder="Enter Reports" class="form-control " >
                </div>
            </div>
             <div class="row"> 
            <div class="col-md-12">
              
               <div class="row" id="furine_examination">
                   <div class="col-sm-3 form-group">
                    <label>Appearance</label>
                    <input type="text" name="appearance" placeholder=" Enter Appearance" class="form-control" >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>colour</label>
                    <input type="text" name="colour"  placeholder="Enter Colour" class="form-control " >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Reaction</label>
                    <input type="text" name="reaction"  placeholder="Enter Reaction" class="form-control " >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Specific Gravity</label>
                    <input type="text" name="specific_gravity"  placeholder="Enter Specific Gravity" class="form-control " >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Glucose</label>
                    <input type="text" name="glucose"  placeholder=" Enter Glucose" class="form-control " >
                    </div>
                    
                    <div class="col-sm-3 form-group">
                    <label>protein</label>
                    <input type="text" name="protein"  placeholder=" Enter Protein" class="form-control " >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Bile Salts</label>
                    <input type="text" name="bile_salts"  placeholder=" Enter Bile Salts" class="form-control " >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Bile Pigments</label>
                    <input type="text" name="bile_pigments"  placeholder=" Enter Bile Pigments" class="form-control " >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>ketone_bodies</label>
                    <input type="text" name="ketone_bodies"  placeholder=" Enter Ketone Bodies" class="form-control " >
                    </div> 
                    <div class="col-sm-3 form-group">
                    <label>Haemoglobin</label>
                    <input type="text" name="haemoglobin"  placeholder=" Enter Haemoglobin" class="form-control " >
                    </div>  
                    <div class="col-sm-3 form-group">
                    <label>Pus Cell</label>
                    <input type="text" name="pus_cell"  placeholder=" Enter Pus Cell" class="form-control " >
                    </div> 
                    <div class="col-sm-3 form-group">
                    <label>Epithelial Cell</label>
                    <input type="text" name="epithelial_cell"  placeholder=" Enter Epithelial Cell" class="form-control " >
                    </div> 
                    <div class="col-sm-3 form-group">
                    <label>rb_cs</label>
                    <input type="text" name="rb_cs"  placeholder=" Enter rb_cs" class="form-control " >
                    </div> 
                    <div class="col-sm-3 form-group">
                    <label>casts</label>
                    <input type="text" name="casts"  placeholder=" Enter Casts" class="form-control " >
                    </div> 
                    <div class="col-sm-3 form-group">
                    <label>Crystals</label>
                    <input type="text" name="crystals"  placeholder=" Enter Crystals" class="form-control " >
                    </div> 
                    <div class="col-sm-3 form-group">
                    <label>Amorphous</label>
                    <input type="text" name="amorphous"  placeholder=" Enter Amorphous" class="form-control " >
                    </div>  
                    <div class="col-sm-3 form-group">
                    <label>Parasites</label>
                    <input type="text" name="parasites"  placeholder=" Enter Parasites" class="form-control " >
                    </div> 
                    <div class="col-sm-3 form-group">
                    <label>Bacteria</label>
                    <input type="text" name="bacteria"  placeholder=" Enter Bacteria" class="form-control " >
                    </div> 
                    <div class="col-sm-3 form-group">
                    <label>Examined by</label>
                    <input type="text" name="ur_examined_by"  placeholder=" Enter Examined by" class="form-control " >
                    </div>  
                    <div class="col-sm-3 form-group">
                    <label>Remarks</label>
                    <input type="text" name="ur_remarks"  placeholder=" Enter remarks" class="form-control " >
                    </div> 
                   
                </div>

                <!-- ....... -->
                <div class="row" id="fbrucella_animal_combine">
                    <div class="col-sm-3 form-group">
                    <label>Vac Against Brucellosis</label>
                    <input type="text" name="b_com_vac_against_brucellosis" placeholder="vac against brucellosis" class="form-control" >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Sample</label>
                    <input type="text" name="sample" placeholder="sample" class="form-control" >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Species</label>
                    <input type="text" name="species" placeholder="species" class="form-control" >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Technician</label>
                    <input type="text" name="b_com_technician" placeholder="technician" class="form-control" >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>remarks</label>
                    <input type="text" name="b_com_remarks" placeholder="remarks" class="form-control" >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Result</label>
                    <input type="text" name="b_com_result" placeholder="result" class="form-control" >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>History</label>
                    <textarea class="form-control" name="history" cols="4" rows="3" ></textarea>
                    </div>
                    
                </div>
                <!-- .... -->
                <div class="row" id="fBrucell_Animal_ind">
                    <div class="col-sm-3 form-group">
                    <label>Vac Against Brucellosis</label>
                    <input type="text" name="b_ani_vac_against_brucellosis" placeholder="vac against brucellosis" class="form-control" >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Sample</label>
                    <input type="text" name="sample" placeholder="sample" class="form-control" >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Parity</label>
                    <input type="text" name="parity" placeholder="parity" class="form-control" >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Technician</label>
                    <input type="text" name="b_ani_technician" placeholder="technician" class="form-control" >
                    </div>
                    
                    <div class="col-sm-3 form-group">
                    <label>Result</label>
                    <input type="text" name="b_ani_result" placeholder="result" class="form-control" >
                    </div>
                    <div class="col-sm-6 form-group">
                    <label>History</label>
                    <textarea class="form-control" name="b_ani_history" cols="4" rows="3" ></textarea>
                    </div>
                  </div>
                  <div class="row" id="fbrucella_human">
                   <div class="col-sm-3 form-group">
                    <label>brucella abortus 20</label>
                    <input type="text" name="brucella_abortus_20" placeholder="Enter brucella abortus 20" class="form-control" >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>brucella abortus 40</label>
                    <input type="text" name="brucella_abortus_40"  placeholder="Enter brucella abortus 40" class="form-control " >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>brucella abortus 80</label>
                    <input type="text" name="brucella_abortus_80"  placeholder="Enter brucella abortus 80" class="form-control " >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>brucella abortus 160</label>
                    <input type="text" name="brucella_abortus_160"  placeholder="Enter brucella abortus 160" class="form-control " >
                    </div>
                    
                    <div class="col-sm-3 form-group">
                    <label>brucella abortus 320</label>
                    <input type="text" name="brucella_abortus_320"  placeholder=" Enter brucella abortus 320" class="form-control " >
                    </div>
                    
                    <div class="col-sm-3 form-group">
                    <label>brucella meletensis 20</label>
                    <input type="text" name="brucella_meletensis_20"  placeholder=" Enter brucella_meletensis_20" class="form-control " >
                    </div> 
                    <div class="col-sm-3 form-group">
                    <label>brucella meletensis 40</label>
                    <input type="text" name="brucella_meletensis_40"  placeholder=" Enter brucella meletensis 40" class="form-control " >
                    </div> 
                    <div class="col-sm-3 form-group">
                    <label>brucella meletensis 80</label>
                    <input type="text" name="brucella_meletensis_80"  placeholder=" Enter brucella meletensis 80" class="form-control " >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>brucella meletensis 160</label>
                    <input type="text" name="brucella_meletensis_160"  placeholder=" Enter brucella meletensis 160" class="form-control " >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>brucella meletensis 320</label>
                    <input type="text" name="brucella_meletensis_320"  placeholder=" Enter brucella meletensis 320" class="form-control " >
                    </div>
                    <div class="col-sm-6 form-group">
                    <label>Result status</label>
                    <input type="text" name="result_status"  placeholder=" Enter result status" class="form-control " >
                    </div>
                </div>
                <div class="row" id="ftb_and_vph">
                   <div class="col-sm-3 form-group">
                    <label>Symptoms</label>
                    <input type="text" name="symptoms" placeholder="Enter symptoms" class="form-control" >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Specimen</label>
                    <input type="text" name="specimen"  placeholder="Enter Specimen" class="form-control " >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Lab Findings</label>
                    <input type="text" name="lab_findings"  placeholder="Enter Lab Findings" class="form-control " >
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Referred By</label>
                    <input type="text" name="referred_by"  placeholder="Enter Referred by" class="form-control " >
                    </div>
                    
                    <div class="col-sm-6 form-group">
                    <label>Examined By</label>
                    <input type="text" name="vp_hp_examined_by"  placeholder=" Enter Examined By" class="form-control " >
                    </div>
                    
                    <div class="col-sm-6 form-group">
                    <label>Remarks</label>
                    <input type="text" name="vp_hp_remarks"  placeholder=" Enter Remarks" class="form-control " >
                    </div>
                    </div>

               
                
                
            </div>
          </div>
                    
                
                    <div class="form-group">
                      <button onclick="return confirm('Are you sure to submit Record?');" type="submit" class="btn btn-primary pull-right" >Save</button><br><br>
                    </div>
                  </div>
                </div>
                </form>
          </div>
          <!-- </div> -->
        </div>
      </div>
      </div>
      <!-- /.row -->
    </section>
     
</div>


<!-- <script type="text/javascript">
  $("#mastitis").click(function(event) {
    /* Act on the event */
    event.preventDefault();
    $(".mastitis").append($("#mastitis").html());
    
  }); 

  $("#haematology").click(function(event) {
    /* Act on the event */
    event.preventDefault();
    $(".haematology").append($("#haematology").html());
    
  }); 
  

</script> -->



  
 
   
   



