<div class="content-wrapper">
    <section class="content-header">
      <h1>
       <!-- Cattle Information -->
        
      </h1>
     
    </section>


    <!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
  Open modal
</button> -->


<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Add Test Item</h4>
        <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form action="<?php echo base_url('Pagescontroller/AddTestItem') ?>" method="post">
        <div class="box-body">
                    <div class="col-sm-12 form-group">
                    <label>Name</label>
                    <input type="text" name="testHelp_name" placeholder="Enter Test item Name" class="form-control" required="" pattern="[a-zA-Z]+">
                    </div>
                    <div class="form-group">
                      <input type="submit" class="btn btn-primary" value="Save" id="rclass">
                    </div>
                </div>
                 </form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>


    <!-- Main content -->
<section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="card">
            <div class="card-header with-border">
              
             <b>Test Item Information</b><?php include'MessageAlert.php'; ?>
               <a class="btn btn-primary pull-right" data-backdrop="static" data-keyboard="false" data-toggle="modal" href='#myModal'>Add New</a>
            </div>
            <div class="card-body">
             <table class="table table-bordered" id="DataTable2">
              <thead>
                <tr class="bg-success">
                  <th>#</th>
                  <th>Test Item</th>
                  <th>Action</th>
        
                </tr>
                <tbody>
                  <?php 
                  $count=1;
                foreach ($testItems as $key => $Items) {
                  # code...
                  ?>
                  <tr>
                    <td class="bg-green"><?php echo $count++ ?></td>
                    <td><?php echo $Items->testHelp_name; ?></td>
                    <td><a data-backdrop="static" data-keyboard="false" data-toggle="modal" href='#items<?= $key; ?>'> <i class="fa fa-pencil-square-o  text-black secedit"></i></a></td>
<!-- The Modal -->
<div class="modal" id="items<?= $key; ?>">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Update Test Item</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form action="<?php echo base_url('Pagescontroller/testItemUpdate') ?>" method="post">
                    <input type="hidden" name="testHelp_id"  value="<?= $Items->testHelp_id; ?>">
        <div class="box-body">
                    <div class="col-sm-12 form-group">
                    <label>Name</label>
                    <input type="text" name="testHelp_name" placeholder="Enter Test Item Name" class="form-control" value="<?= $Items->testHelp_name; ?>">
                    </div>
                    <div class="form-group">
                     <button type="submit" class="btn btn-primary" > Update </button>
                    </div>
                </div>
                 </form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>                    
                    

                    
                    
                  </tr>
                  <?php  
                }

                   ?>
                </tbody>
              </thead>
            </table>
          </div>
          </div>
        </div>
      </div>
      </div>
      <!-- /.row -->
    </section>
    
