<div class="content-wrapper">
    <section class="content-header">
      <h1>
       <!-- Users Information -->
        
      </h1>
     
    </section>


    <!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
  Open modal
</button> -->

<!-- The Registeration Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog  modal-lg">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Add User</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form action="<?= base_url('User/Registration'); ?>" method="post"  enctype="multipart/form-data" >
        <div class="box-body">
          <div class="row"> 
            <div class="col-md-12">
               <div class="row">
                  <div class="col-sm-6 form-group">
                    <label>User Name</label>
                    <input type="text" name="user_name" placeholder="Enter User Name" class="form-control" required pattern="[a-zA-Z]+">
                    </div>
                    <div class="col-sm-6 form-group">
                    <label>User Email</label>
                    <input type="text" name="user_email" placeholder="Enter User Email" class="form-control" required>
                    </div>
                    <div class="col-sm-6 form-group">
                    <label>User Contact</label>
                    <input type="text" name="user_contact" placeholder="Enter Contact Number" class="form-control" required>
                    </div>
                    <div class="col-sm-6 form-group">
                    <label>User Password</label>
                    <input type="password" name="user_pass" placeholder="Enter User Password" class="form-control" required>
                    </div>
                    <div class="col-sm-6 form-group">
                    <label>User Designation</label>
                    <input type="text" name="user_desi" placeholder="Enter User Designation" class="form-control" required>
                    </div>
                     <div class="col-sm-6 form-group">
                    <label>User Gender</label>
                    <div class="form-check">
                      <input class="form-check-input" name="user_gender" type="radio" value="Male" checked>
                      <label class="form-check-label">Male</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      <input class="form-check-input" name="user_gender" type="radio" value="Female">
                      <label class="form-check-label">Female</label>
                    </div>
                    </div>
                    <div class="col-sm-6 form-group">
                  <label for="location">User Roles</label>
                  <select class="form-control" name="role_id" required>
                    <option value="">-Select-</option>
                    <?php 
                    
                    foreach ($roles as $role) {
                      # code...
                      ?>
                      <option value="<?php echo $role->role_id; ?>"><?php echo $role->role_name; ?></option>
                      <?php 
                    }

                     ?>
                  </select>
                </div>
                        <div class="col-sm-6 form-group">
                          <label> Directorates</label>
                          <select class="form-control directorate_id" onchange="GetStations(this.value)"  name="directorate_id"  style="width: 100%" required>
                          <option  value="">-select-</option>
                          <?php 
                          
                          foreach ($directorates as $directorate) {
                            # code...
                            ?>
                            <option    value="<?php echo $directorate->directorate_id; ?>"><?php echo $directorate->directorate_name; ?></option>
                            <?php 
                          }

                           ?>
                        </select>
                       </div>
                        <div class="col-sm-6 form-group">
                          <label> Center/Station</label>
                          <select class="form-control center_station_id" onchange="GetSections(this.value)"  name="center_station_id"  style="width: 100%" required>
                            <option  value="">-select-</option>
                           
                           </select>
                          </div>
                          <div class="col-sm-6 form-group">
                            <label for="location">Section</label>
                            <select class="form-control section_id" onchange="GetLabs(this.value)" name="section_id"  style="width: 100%" required>
                              <option  value="">-select-</option>
                             
                            </select>
                          </div>
                        <div class="col-sm-6 form-group">
                          <label> Labs</label>
                           <select class="form-control lab_id" style="width: 100% !important" name="lab_id" required>
                          <option  value="">-select-</option>
                        </select>
                          </div>
                <div class="col-sm-6  form-group">
                  <label>User Image</label>
                    <div class="input-group">
                      <div class="custom-file">
                        <input type="file"  >
                          <img class="img-rounded" id="blah" src="" >
                         <input type="file" name="file" id="user_img" class="custom-file-input">
                        <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                      </div>
                    </div>
                  </div>
                
          </div>
            </div>
            
          </div>
         
                    
                    <div class="form-group">
                      <button type="submit" class="btn btn-primary" > Save </button>
                    </div>
                </div>
                </form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>


    <!-- Main content -->
<section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="card">
             


            <div class="card-header with-border">
               <b>Users Information</b><?php include'MessageAlert.php'; ?>
               <a class="btn btn-primary pull-right" data-backdrop="static" data-keyboard="false" data-toggle="modal" href='#myModal'>Add User</a>
            </div>
            <div class="card-body">
             <table class="table  table-hover table-striped" id="DataTable2">
              <thead>
                <tr class="bg-success">
                  <th>#</th>
                  <th> Name</th>
                  <th>Email</th>
                  <th>Designation</th>
                  <th>Lab Assign</th>
                  <th>Role</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
                <tbody>
                  <?php 
                  $count=1;
                if(!empty($users))
                {
                foreach ($users as $key => $user) {
                  # code...
                  ?>
                  <tr>
                    <td class="bg-green"><?= $count++ ?></td>
                    <td><?= $user->user_name;   ?></td>
                    <td><?= $user->user_email;  ?></td>
                    <td><?= $user->designation; ?></td>
                    <td><?= $user->lab_name;    ?></td>
                    <td><?= $user->role_name;   ?></td>
                    <td>
                       <?php
                          $status   = '';
                          $color    = '';
                         if($user->is_block==0)
                         {
                           $status  = 'Active';
                           $color   = 'bg-success';
                         }else
                         {
                            $status = 'Blocked';
                            $color  = 'bg-danger';
                         }
                       ?>
                       <span class="badge <?= $color; ?>"><?= $status; ?></span>
                     </td>
                    <td>
                   <a href="<?= base_url('User/user_detail_info/'.$user->user_id); ?>"> <i class="fa  fas fa-eye text-primary"></i></a>
                   <a data-backdrop="static" data-keyboard="false" data-toggle="modal" href='#myModal<?=$key?>'> <i class="fa fa-pencil-square-o  text-black"></i></a>
                   <a  onclick="return confirm('Are you sure to delete?');" href='<?= base_url('User/deleteUser/'.$user->user_id); ?>'> <i class="fa fa-trash  text-danger"></i></a>
                    </td>
<!--  The Updation Modal -->
<div class="modal" id="myModal<?= $key ?>">
  <div class="modal-dialog  modal-lg">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Update User</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form action="<?= base_url('User/updateUserRecord'); ?>" method="post" enctype="multipart/form-data"> 
        <div class="box-body">
          <div class="row"> 
            <div class="col-md-12">
               <div class="row">
                  <div class="col-sm-6 form-group">
                    <label>User Name</label>
                    <input type="text" value="<?= $user->user_name;?>" name="user_name" placeholder="Enter User Name" class="form-control" required>
                    <input type="hidden" value="<?= $user->user_id;?>" name="user_id">
                    <input type="hidden" value="<?= $this->uri->segment(2); ?>" name="uri">
                  <input type="hidden" name="old_img" value="<?= $user->user_img; ?>">
                    </div>
                    <div class="col-sm-6 form-group">
                    <label>User Email</label>
                    <input type="text" value="<?= $user->user_email;?>" name="user_email" placeholder="Enter User Email" class="form-control" required>
                    </div>
                    <div class="col-sm-6 form-group">
                    <label>User Contact</label>
                    <input type="text" value="<?= $user->user_contact;?>" name="user_contact" placeholder="Enter Contact Number" class="form-control" required>
                    </div>
                    <div class="col-sm-6 form-group">
                    <label>User Designation</label>
                    <input type="text" value="<?= $user->designation;?>" name="user_desi" placeholder="Enter User Designation" class="form-control" required>
                    </div>
                     <div class="col-sm-6 form-group">
                    <label>User Gender</label>
                    <div class="form-check">
                      <input class="form-check-input" name="user_gender" type="radio" value="Male" <?php if($user->gender=='Male'){ echo "checked"; } ?> >
                      <label class="form-check-label">Male</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      <input class="form-check-input" name="user_gender" type="radio" value="Female" <?php if($user->gender=='Female'){ echo "checked"; } ?>>
                      <label class="form-check-label">Female</label>
                    </div>
                    </div>
                    
                  <div class="col-sm-6 form-group">
                  <label for="location">User Roles</label>
                  <select class="form-control" name="role_id" required>
                    <option value="">-Select-</option>
                    <?php 
                    
                    foreach ($roles as $role) {
                      # code...
                      ?>
                      <option <?php if($role->role_id==$user->user_role){ echo "selected"; } ?> value="<?php echo $role->role_id; ?>"><?php echo $role->role_name; ?></option>
                      <?php 
                    }

                     ?>
                  </select>
                </div>
                <div class="col-sm-6 form-group">
                    <label> Directorates</label>
                    <select class="form-control directorate_id" onchange="GetStations(this.value)"  name="directorate_id"  style="width: 100%" required>
                    <option  value="">-select-</option>
                    <?php 
                    
                    foreach ($directorates as $directorate) {
                      # code...
                      ?>
                      <option  <?php if($directorate->directorate_id==$user->directorate_id){ echo "selected";} ?>  value="<?php echo $directorate->directorate_id; ?>"><?php echo $directorate->directorate_name; ?></option>
                      <?php 
                    }

                     ?>
                  </select>
                    </div>
                  <div class="col-sm-6 form-group">
                    <label> Center/Station</label>
                    <select class="form-control center_station_id" onchange="GetSections(this.value)"  name="center_station_id"  style="width: 100%" required>
                      <?php 
                       $stations = $this->API_m->getRecordWhere('center_station',['directorate_id' => $user->directorate_id]);
                    foreach ($stations as $station) {
                      # code...
                      ?>
                      <option <?php if($station->center_station_id==$user->center_station_id){ echo "selected";} ?> value="<?php echo $station->center_station_id; ?>"><?php echo $station->center_station_name; ?></option>
                      <?php 
                    }

                     ?>
                     </select>
                    </div>
                    <div class="col-sm-6 form-group">
                  <label for="location">Section</label>
                  <select class="form-control section_id"  name="section_id" onchange="GetLabs(this.value)"  style="width: 100%" required>
                    <?php 
                    $sections = $this->API_m->GetSectionsItems($user->center_station_id);
                    foreach ($sections as $section) {
                      # code...
                      ?>
                      <option <?php if($section->section_id==$user->section_id){ echo "selected";} ?> value="<?php echo $section->section_id; ?>"><?php echo $section->sectionHelp_name; ?></option>
                      <?php 
                    }

                     ?>
                  </select>
                </div>
                  <div class="col-sm-6 form-group">
                    <label> Lab</label>
                     <select class="form-control lab_id" style="width: 100% !important" name="lab_id" required>
                    <option value="">-Select-</option>
                    <?php 
                    $labs = $this->API_m->getRecordWhere('labs',['section_id' => $user->section_id]);
                      foreach ($labs as $lab) {
                    ?>
                        <option <?php if($lab->lab_id==$user->lab_id){ echo "selected"; } ?> value="<?php echo $lab->lab_id; ?>"><?php echo $lab->lab_name; ?></option>
                    <?php 
                      }

                    ?>
                  </select>
                    </div>
                <?php
                    if(!empty($user->user_img))
                    {
                ?>
               <div class="col-sm-6 form-group">
                 <img class="img-rounded" style="width: 120px; height: 100px;" src="<?= base_url('img_uploads/user_images/'.$user->user_img); ?>" >
                 <div class="col-sm-4">
                 <a class="btn btn-danger btn-sm" style="width: 100%"  href="<?= base_url('User/DeleteImg/'.'index/'.'users/'.$user->user_id); ?>">Delete</a>
                 </div>
               </div>
                <?php
                    }else{
                ?>
               <div class="col-sm-6 form-group">
                  <label>User Image</label>
                  <input type="file"   name="file"   class="form-control">
               </div>
                <?php
                    }
                ?>
                
          </div>
            </div>
            
          </div>
                    <div class="form-group">
                     <button type="submit" class="btn btn-primary" > Update User </button>
                    </div>
                </div>
                </form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>

<!--  The Details Modal -->
<div class="modal" id="DetailModal<?= $key ?>">
  <div class="modal-dialog  modal-lg">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">User Detail Info</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <div class="box-body">
          <div class="row"> 
            <div class="col-md-3">
              <b>Full Name</b>
            </div>
             <div class="col-md-3">
              <?= $user->user_name; ?>
            </div>
            <div class="col-md-3">
              <b>Email</b>
            </div>
             <div class="col-md-3">
              <?= $user->user_email; ?>
            </div>
            <div class="col-md-3">
              <b>Designation</b>
            </div>
             <div class="col-md-3">
              <?= $user->designation; ?>
            </div>
            <div class="col-md-3">
              <b>Lab Assign</b>
            </div>
              <div class="col-md-3">
              <?= $user->lab_name; ?>
            </div>
            <div class="col-md-3">
               <b>Role</b> 
            </div>
               <div class="col-md-3">
              <?= $user->role_name; ?>
            </div>
          </div>
                </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
                    
                    
                  </tr>
                  <?php  
                } 
              }
                   ?>
                </tbody>
            </table> 
          </div>
          </div>
        </div>
      </div>
      </div>
      <!-- /.row -->
    </section>
    

<script type="text/javascript">

 function readURL(input) {

        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah').attr('src', e.target.result);
                $('#blah').css({'width':'150px'});
                $('#blah').css({'width':'150px'});
            };

            reader.readAsDataURL(input.files[0]);
        }
    }

    $("#user_img").change(function () {
        readURL(this);
    });
</script>

  
 
   
   



