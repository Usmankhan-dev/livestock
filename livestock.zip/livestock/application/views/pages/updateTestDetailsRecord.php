<?php
  // echo "<pre>";
  // print_r($samples);
  // exit();
date_default_timezone_set('Asia/Karachi');
  $col = '';
  if($rec['testDetails']->post_status==0 && $rec['testDetails']->is_cancel==0)
  {
    $col = '9';
  }else
  {
    $col = '12'; 
  }
?>

<div class="content-wrapper">
    <section class="content-header">
      <h1>
    <!-- Update Test Result --> 
        
      </h1>
     
    </section>

    <!-- Main content -->
<section class="content">
   <div class="row">
      <div class="col-3">
        <small class="float-left">Date: <?= date('M d Y'); ?></small>
      </div>
       <div class="col-6" style="text-align: center;">
         
      </div>
       <div class="col-3">
         <small class="float-right">Lab #: <?= $logLab->lab_id; ?></small>
      </div>
      <!-- /.col -->
    </div>
    <hr>
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="card">
             


            <div class="card-header with-border">
              <b>Update Test Result</b> <?php include'MessageAlert.php'; ?>
            </div>
            <div class="card-body">
                 <form action="<?= base_url('Tests/update_testDetails_Record'); ?>" method="post"  enctype="multipart/form-data" >
                  <input type="hidden" name="testDetails_id" value="<?= $rec['testDetails']->testDetails_id;?>"> 
                  <input type="hidden" name="client_id" value="<?= $rec['testDetails']->client_id;?>"> 

          <div class="row"> 
            <div class="col-md-<?= $col; ?>">
              <div class="row">
                <div class="col-sm-12 form-group">
                    <label>Source Type</label>
                     <select class="form-control" id="client_type" onchange="GetClientType(this.value)" style="width: 100% !important"  name="client_type" required>
                        <option value="">-Select-</option>
                        <option <?php if($rec['testDetails']->type=='farmer'){ echo "selected";} ?> value="farmer">Farmer</option>
                        <option <?php if($rec['testDetails']->type=='own_dept'){ echo "selected";} ?> value="own_dept">Own Departmentt</option>
                        <option <?php if($rec['testDetails']->type=='other_dept'){ echo "selected";} ?> value="other_dept">Other Department</option>
                      </select>
                    </div>
              </div>
                <b class="text-success" id="client_info">Source Info</b>
                <hr>
               <div class="row" id="client_row">
                  <div class="col-sm-3 form-group client_cnic">
                  <label>Source CNIC#</label>
                  <input type="text" name="client_cnic" id="client_cnic" value="<?= $rec['testDetails']->client_cnic; ?>"  placeholder="Enter  CNIC#" class="form-control" required>
                  </div>
                  <div class="col-sm-3 form-group">
                   <label id="label_name">Source Name</label>
                  <input type="text" name="client_name" id="client_name" value="<?= $rec['testDetails']->client_name; ?>" placeholder="Enter  Name" class="form-control" required>
                  </div>
                  <div class="col-sm-3 form-group">
                  <label id="label_contact">Contact#</label>
                  <input type="text" name="client_contact" id="client_contact" value="<?= $rec['testDetails']->client_contact ?>"  placeholder="Enter  Contact" class="form-control " required>
                  </div>
                  <div class="col-sm-3 form-group">
                  <label>Referred by</label>
                  <input type="text" name="referred_by"  value="<?= $rec['testDetails']->referred_by ?>" placeholder="Enter Referred by" class="form-control">
                  </div>
                  
                  <div class="col-sm-3 form-group">
                  <label id="client_address">Source Address</label>
                  <input type="text" name="client_address"  value="<?= $rec['testDetails']->client_address ?>"  placeholder="Enter Address" class="form-control " required>
                  </div>
                </div>
                <div class="row">
                       
                    <div class="col-sm-4 form-group">
                    <label>Test Name</label>
                     <select class="form-control  re_test_id" id="test_id" style="width: 100% !important" onchange="GetSample()" name="test_id" required>
                        <option value="">-Select-</option>
                        <?php 
                           if(!empty($tests))
                          {

                          foreach ($tests as $test) {
                        ?>
                            <option <?php if($rec['testDetails']->test_id==$test->test_id){ echo "selected"; }  ?> value="<?php echo $test->test_id; ?>"><?php echo $test->test_name; ?></option>
                        <?php 
                          }
                            }
                        ?>
                      </select>
                    </div>
                     <div class="col-sm-4 form-group">
                        <label>Sample</label>
                        <select class="form-control " id="test_sample_id" style="width: 100% !important" name="sample_id" required="required">
                           <?php 
                              foreach ($samples as $sample) {
                            ?>
                                <option <?php if($rec['testDetails']->sample_id==$sample->sample_id){ echo "selected"; } ?> value="<?php echo $sample->sample_id; ?>"><?php echo $sample->sample_name; ?></option>
                            <?php 
                              }

                            ?>
                        </select>
                    </div>
                     <div class="col-sm-4 form-group">
                          <label>Sample Desc/Details</label>
                        <textarea name="sample_desc" rows="2" cols="10" class="form-control"> <?= $rec['testDetails']->sample_desc; ?></textarea>
                    </div>
                    <div class="col-sm-4 form-group">
                    <label>Test Total Fee</label>
                    <input type="number" name="test_total_fee" value="<?= $rec['testDetails']->test_total_fee ?>"  onBlur="if (this.value < 1) { this.value = '0.00';}" value="0.00"  placeholder="Enter Test Fee" class="form-control testPrice" required>
                    </div>
                    <div class="col-sm-4 form-group">
                    <label>Received Date</label>
                    <input type="text" name="received_date" value="<?= date('d/m/Y',strtotime($rec['testDetails']->received_date)); ?>"    class="form-control datepicker" required>
                    </div>
                     <div class="col-sm-4 form-group">
                    <label>Result Date</label>
                    <input type="text" name="result_date" value="<?= date('d/m/Y',strtotime($rec['testDetails']->result_date)); ?>"   class="form-control datepicker" required>
                    </div>
                     <div class="col-sm-6 form-group">
                    <label>Additional Info</label>
                    <textarea name="additional_info" class="form-control"><?= $rec['testDetails']->additional_info ?></textarea>
                    </div>
                </div>
          
                <b class="text-success">Animal Info</b>
                <hr>
                <div class="row">
                    <div class="col-sm-4 form-group">
                      <label>Animal Name </label>
                      <select class="form-control cattle_id" onchange="GetBreeds(this.value);"  name="cattle_name"  style="width: 100%" required>
                          <option value="">-select-</option>
                        <?php 
                        foreach ($cattles as $cattle) {
                          # code...
                          ?>
                          <option <?php if($rec['testDetails']->cattle_name==$cattle->cattle_id){ echo "selected"; } ?>  value="<?php echo $cattle->cattle_id; ?>"><?php echo $cattle->cattle_name; ?></option>
                          <?php 
                        }

                         ?>
                      </select>
                    </div>   
                    <div class="col-sm-4 form-group">
                      <label>Breed</label>
                       <select class="form-control breed_id"  name="cattle_breed"  style="width: 100%" required>
                        <option value="">-select-</option>
                        <?php 
                         $breeds  = $this->API_m->getRecordWhere('breeds',['cattle_id'=>$rec['testDetails']->cattle_name,'is_trash'=>0]);
                        foreach ($breeds as $breed) {
                          ?>
                          <option <?php if($rec['testDetails']->cattle_breed==$breed->breed_id){ echo "selected"; } ?>  value="<?php echo $breed->breed_id; ?>"><?php echo $breed->breed_name; ?></option>
                          <?php 
                        }

                         ?>
                      </select>
                      </select>
                    </div> 
                    <div class="col-sm-4 form-group">
                      <label>Tag#</label>
                      <input type="text" name="cattle_tag_no"  placeholder="Enter Cattle Tag No" value="<?= $rec['testDetails']->cattle_tag_no ?>" class="form-control " required>
                    </div>   
                    <div class="col-sm-4 form-group">
                      <label>Sex</label>
                        <select class="form-control"  name="cattle_sex"  style="width: 100%" >
                          <option value="">-select-</option>
                          <option  <?php if($rec['testDetails']->cattle_sex=="Male"){ echo "selected"; } ?> value="Male">Male</option>
                          <option  <?php if($rec['testDetails']->cattle_sex=="Female"){ echo "selected"; } ?> value="Female">Female</option>
                      </select>
                    </div>   
                    <div class="col-sm-4 form-group">
                      <label>Age</label>
                      <input type="text" name="cattle_age"  placeholder="Enter Cattle Age" value="<?= $rec['testDetails']->cattle_age ?>" class="form-control " required>
                    </div>   
                     <div class="col-sm-4 form-group">
                      <label>Total #</label>
                      <input type="text" name="cattle_total_no" placeholder="Enter Cattle Total No" value="<?= $rec['testDetails']->cattle_total_no ?>" class="form-control " required>
                    </div>
                </div>
                 <b class="text-success">Test Info</b>
                <hr>
                 <?php 
                    if($rec['testDetails']->test_id==1)
                    {
                ?>
                <input type="hidden" name="impression_smear_id" value="<?= $rec['testType']->impression_smear_id;?>"> 
                 
                 <div class="row" id="impression_smear">
                    <div class="col-sm-4 form-group">
                      <label>Type of Specimen </label>
                      <input type="text" name="type_specimen" value="<?= $rec['testType']->type_specimen ?>"  placeholder="Enter Type of Specimen" class="form-control" required>
                    </div>   
                    <div class="col-sm-4 form-group">
                      <label>Animals Specimen</label>
                      <input type="text" name="animals_specimen" value="<?= $rec['testType']->animals_specimen ?>"  placeholder="Enter Animals Specimen" class="form-control " required>
                    </div>   
                    <div class="col-sm-4 form-group">
                      <label>Examined for</label>
                      <input type="text" name="examined_for" value="<?= $rec['testType']->examined_for ?>"  placeholder="Enter Examined for" class="form-control " required>
                    </div>   
                    <div class="col-sm-4 form-group">
                      <label>Result</label>
                      <input type="text" name="result" value="<?= $rec['testType']->result ?>"  placeholder="Enter Result" class="form-control " required>
                    </div>   
                     <div class="col-sm-4 form-group">
                      <label>Remarks</label>
                      <input type="text" name="remarks" value="<?= $rec['testType']->remarks ?>"  placeholder="Enter Remarks" class="form-control " required>
                    </div>
                     <div class="col-sm-4 form-group">
                      <label>Examined by</label>
                      <input type="text" name="examined_by" value="<?= $rec['testType']->examined_by ?>" placeholder="Enter Examined by" class="form-control " required>
                    </div>
                    
                    <div class="col-sm-6 form-group">
                    <label>Recommendation</label>
                    <textarea name="recommendations" class="form-control"><?= $rec['testDetails']->recommendations; ?></textarea>
                    </div>
                
          </div>
                <?php
                    }
                    else if($rec['testDetails']->test_id==2)
                    {
                ?>
<input type="hidden" name="haematology_id"          value="<?= $rec['testType']->haematology_id; ?>">
                 <div class="row" id="haematology" class="hnone">
                   <div class="col-sm-3 form-group">
                    <label>Haemoglobin</label>
                    <input type="text" name="haemoglobinz" value="<?= $rec['testType']->haemoglobinz; ?>"  placeholder="Enter Haemoglobin" class="form-control" required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>ESR</label>
                    <input type="text" name="ESR" value="<?= $rec['testType']->ESR; ?>"   placeholder="Enter ESR" class="form-control " required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>TRBC</label>
                    <input type="text" name="TRBC" value="<?= $rec['testType']->TRBC; ?>"   placeholder="Enter TRBC" class="form-control " required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>TLC</label>
                    <input type="text" name="TLC" value="<?= $rec['testType']->TLC; ?>"   placeholder="Enter TLC" class="form-control " required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>PCV</label>
                    <input type="text" name="PCV" value="<?= $rec['testType']->PCV; ?>"   placeholder=" Enter PCV" class="form-control " required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Neutrophils</label>
                    <input type="text" name="neutrophils" value="<?= $rec['testType']->neutrophils; ?>"   placeholder=" Enter neutrophils" class="form-control " required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>lymphocytes</label>
                    <input type="text" name="lymphocytes" value="<?= $rec['testType']->lymphocytes; ?>"   placeholder=" Enter lymphocytes" class="form-control " required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Eosinophils</label>
                    <input type="text" name="eosinophils" value="<?= $rec['testType']->eosinophils; ?>"   placeholder=" Enter eosinophils" class="form-control " required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Monocytes</label>
                    <input type="text" name="monocytes" value="<?= $rec['testType']->monocytes; ?>"   placeholder=" Enter monocytes" class="form-control " required>
                    </div> 
                    <div class="col-sm-3 form-group">
                    <label>basophils</label>
                    <input type="text" name="basophils" value="<?= $rec['testType']->basophils; ?>"   placeholder=" Enter basophils" class="form-control " required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>protozoa</label>
                    <input type="text" name="protozoa" value="<?= $rec['testType']->protozoa; ?>"   placeholder=" Enter protozoa" class="form-control " required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Iodine flocculation Test</label>
                    <input type="text" name="iodine_flocculation_test" value="<?= $rec['testType']->iodine_flocculation_test; ?>"   placeholder=" Enter Iodine Flocculation Test" class="form-control " required>
                    </div>
                </div>
                <?php
                    }
                    else if($rec['testDetails']->test_id==3)
                    {
                ?>
<input type="hidden" name="mastitis_id"             value="<?= $rec['testType']->mastitis_id; ?>">
                       <div class="row" id="mastitis" class="none">
                <hr>
                   <div class="col-sm-3 form-group">
                    <label>Daily Milk Production</label>
                    <input type="text" name="daily_milk_production" value="<?= $rec['testType']->daily_milk_production; ?>" placeholder="Daily Milk Production" class="form-control" required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Lactation No#</label>
                    <input type="text" name="lactation_no" value="<?= $rec['testType']->lactation_no; ?>"  placeholder="Enter Lactation No" class="form-control " required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Total Animals Farm</label>
                    <input type="text" name="total_animals_at_farm" value="<?= $rec['testType']->total_animals_at_farm; ?>"  placeholder="Enter Total Animals Farm" class="form-control " required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>In Milk</label>
                    <input type="text" name="in_milk" value="<?= $rec['testType']->in_milk; ?>"  placeholder="Enter In Milk" class="form-control " required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Dry Period Given</label>
                    <input type="text" name="dry_period_given" value="<?= $rec['testType']->dry_period_given; ?>"  placeholder=" Enter Dry Period Given" class="form-control " required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Calving Kidding Lambing date</label>
                    <input type="text" name="cal_kid_lambing_date"  value="<?= $rec['testType']->cal_kid_lambing_date; ?>"  placeholder="Enter Date" class="form-control datepicker" required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Record of Previous Animal</label>
                    <input type="text" name="prev_mastatis_rec_of_anim" value="<?= $rec['testType']->prev_mastatis_rec_of_anim; ?>"  placeholder=" Enter Record of Previous Animal" class="form-control " required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Record of Previous farm</label>
                    <input type="text" name="prev_mastatis_rec_of_farm" value="<?= $rec['testType']->prev_mastatis_rec_of_farm; ?>"  placeholder=" Enter Record of Previous farm" class="form-control " required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Previous Mastatis Test Farm</label>
                    <input type="text" name="prac_mastatis_test_at_farm" value="<?= $rec['testType']->prac_mastatis_test_at_farm; ?>"  placeholder=" Enter Previous Mastatis Test Farm" class="form-control " required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Sample Received</label>
                    <input type="text" name="sample_received" value="<?= $rec['testType']->sample_received; ?>"  placeholder=" Enter Sample Received" class="form-control " required>
                    </div> 
                    <div class="col-sm-3 form-group">
                    <label>Test Required</label>
                    <input type="text" name="test_required" value="<?= $rec['testType']->test_required; ?>"  placeholder=" Enter Test Required" class="form-control " required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Refer Bacteriology Section</label>
                    <input type="text" name="refer_to_bacteriology_sec_for" value="<?= $rec['testType']->refer_to_bacteriology_sec_for; ?>"  placeholder=" Enter Test Required" class="form-control " required>
                    </div>
                </div>
                <?php
                    }
                    else if($rec['testDetails']->test_id==4)
                    {
                ?>
<input type="hidden" name="culture_sensitivity_id"  value="<?= $rec['testType']->culture_sensitivity_id; ?>">
                   <div class="row" id="culture_sensitivity">
                      <div class="col-sm-3 form-group">
                        <label>Intibiotics</label>
                        <input type="text" name="intibiotics" value="<?= $rec['testType']->intibiotics; ?>" placeholder="Enter Intibiotics" class="form-control" required>
                        </div>
                       <div class="col-sm-3 form-group">
                        <label>Sensitivity</label>
                        <input type="text" name="sensitivity" value="<?= $rec['testType']->sensitivity; ?>" placeholder="Enter Sensitivity" class="form-control" required>
                        </div>
                        <div class="col-sm-3 form-group">
                        <label>Tested by</label>
                        <input type="text" name="tested_by"  value="<?= $rec['testType']->tested_by; ?>" placeholder="Enter Tested by" class="form-control " required>
                        </div>
                        
                        <div class="col-sm-3 form-group">
                        <label>Reports</label>
                        <input type="text" name="reports"  value="<?= $rec['testType']->reports; ?>" placeholder="Enter Reports" class="form-control " required>
                        </div>
                    </div>
                <?php
                    }else if($rec['testDetails']->test_id==5)
                    {
                ?>
<input type="hidden" name="urine_id"                value="<?= $rec['testType']->urine_id; ?>">
               <div class="row" id="urine_examination">
                   <div class="col-sm-3 form-group">
                    <label>Appearance</label>
                    <input type="text" name="appearance" value="<?= $rec['testType']->appearance; ?>" placeholder=" Enter Appearance" class="form-control" required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>colour</label>
                    <input type="text" name="colour" value="<?= $rec['testType']->colour; ?>" placeholder="Enter Colour" class="form-control " required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Reaction</label>
                    <input type="text" name="reaction" value="<?= $rec['testType']->reaction; ?>" placeholder="Enter Reaction" class="form-control " required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Specific Gravity</label>
                    <input type="text" name="specific_gravity" value="<?= $rec['testType']->specific_gravity; ?>" placeholder="Enter Specific Gravity" class="form-control " required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Glucose</label>
                    <input type="text" name="glucose" value="<?= $rec['testType']->glucose; ?>" placeholder=" Enter Glucose" class="form-control " required>
                    </div>
                    
                    <div class="col-sm-3 form-group">
                    <label>protein</label>
                    <input type="text" name="protein" value="<?= $rec['testType']->protein; ?>" placeholder=" Enter Protein" class="form-control " required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Bile Salts</label>
                    <input type="text" name="bile_salts" value="<?= $rec['testType']->bile_salts; ?>" placeholder=" Enter Bile Salts" class="form-control " required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Bile Pigments</label>
                    <input type="text" name="bile_pigments" value="<?= $rec['testType']->bile_pigments; ?>" placeholder=" Enter Bile Pigments" class="form-control " required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>ketone_bodies</label>
                    <input type="text" name="ketone_bodies" value="<?= $rec['testType']->ketone_bodies; ?>" placeholder=" Enter Ketone Bodies" class="form-control " required>
                    </div> 
                    <div class="col-sm-3 form-group">
                    <label>Haemoglobin</label>
                    <input type="text" name="haemoglobin" value="<?= $rec['testType']->haemoglobin; ?>" placeholder=" Enter Haemoglobin" class="form-control " required>
                    </div>  
                    <div class="col-sm-3 form-group">
                    <label>Pus Cell</label>
                    <input type="text" name="pus_cell" value="<?= $rec['testType']->pus_cell; ?>" placeholder=" Enter Pus Cell" class="form-control " required>
                    </div> 
                    <div class="col-sm-3 form-group">
                    <label>Epithelial Cell</label>
                    <input type="text" name="epithelial_cell" value="<?= $rec['testType']->epithelial_cell; ?>" placeholder=" Enter Epithelial Cell" class="form-control " required>
                    </div> 
                    <div class="col-sm-3 form-group">
                    <label>rb_cs</label>
                    <input type="text" name="rb_cs" value="<?= $rec['testType']->rb_cs; ?>" placeholder=" Enter rb_cs" class="form-control " required>
                    </div> 
                    <div class="col-sm-3 form-group">
                    <label>casts</label>
                    <input type="text" name="casts" value="<?= $rec['testType']->casts; ?>" placeholder=" Enter Casts" class="form-control " required>
                    </div> 
                    <div class="col-sm-3 form-group">
                    <label>Crystals</label>
                    <input type="text" name="crystals" value="<?= $rec['testType']->crystals; ?>" placeholder=" Enter Crystals" class="form-control " required>
                    </div> 
                    <div class="col-sm-3 form-group">
                    <label>Amorphous</label>
                    <input type="text" name="amorphous" value="<?= $rec['testType']->amorphous; ?>" placeholder=" Enter Amorphous" class="form-control " required>
                    </div>  
                    <div class="col-sm-3 form-group">
                    <label>Parasites</label>
                    <input type="text" name="parasites" value="<?= $rec['testType']->parasites; ?>" placeholder=" Enter Parasites" class="form-control " required>
                    </div> 
                    <div class="col-sm-3 form-group">
                    <label>Bacteria</label>
                    <input type="text" name="bacteria" value="<?= $rec['testType']->bacteria; ?>" placeholder=" Enter Bacteria" class="form-control " required>
                    </div> 
                    <div class="col-sm-3 form-group">
                    <label>Examined by</label>
                    <input type="text" name="ur_examined_by" value="<?= $rec['testType']->examined_by; ?>" placeholder=" Enter Examined by" class="form-control " required>
                    </div>  
                    <div class="col-sm-3 form-group">
                    <label>Remarks</label>
                    <input type="text" name="ur_remarks" value="<?= $rec['testType']->remarks; ?>" placeholder=" Enter remarks" class="form-control " required>
                    </div> 
                   
                </div>
                <?php
                  }else if($rec['testDetails']->test_id==6)
                  {
                ?>
                <input type="hidden" name="brucella_animal_com_id"  value="<?= $rec['testType']->brucella_animal_com_id; ?>">
                 <div class="row" id="brucella_animal_combine">
                    <div class="col-sm-3 form-group">
                    <label>Vac Against Brucellosis</label>
                    <input type="text" name="b_com_vac_against_brucellosis"  value="<?= $rec['testType']->vac_against_brucellosis ?>" placeholder="vac against brucellosis" class="form-control" required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Sample</label>
                    <input type="text" name="sample"  value="<?= $rec['testType']->sample ?>" placeholder="sample" class="form-control" required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Species</label>
                    <input type="text" name="species"  value="<?= $rec['testType']->species ?>" placeholder="species" class="form-control" required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Technician</label>
                    <input type="text" name="b_com_technician"  value="<?= $rec['testType']->b_com_technician ?>" placeholder="technician" class="form-control" required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>remarks</label>
                    <input type="text" name="b_com_remarks"  value="<?= $rec['testType']->b_com_remarks ?>" placeholder="remarks" class="form-control" required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Result</label>
                    <input type="text" name="b_com_result"  value="<?= $rec['testType']->b_com_result ?>" placeholder="result" class="form-control" required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>History</label>
                    <textarea class="form-control" name="history"  value="<?= $rec['testType']->history ?>" cols="4" rows="3" required></textarea>
                    </div>
                    
                </div>
               
                <?php
                  }else if($rec['testDetails']->test_id==7)
                  {
                ?>
<input type="hidden" name="brucella_animal_ind_id"  value="<?= $rec['testType']->brucella_animal_ind_id; ?>">

                 <!-- .... -->
                <div class="row" id="Brucell_Animal_ind">
                    <div class="col-sm-3 form-group">
                    <label>Vac Against Brucellosis</label>
                    <input type="text" name="b_ani_vac_against_brucellosis"  value="<?= $rec['testType']->b_ani_vac_against_brucellosis; ?>" placeholder="vac against brucellosis" class="form-control" required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Sample</label>
                    <input type="text" name="sample"  value="<?= $rec['testType']->sample; ?>" placeholder="sample" class="form-control" required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Parity</label>
                    <input type="text" name="parity"  value="<?= $rec['testType']->parity; ?>" placeholder="parity" class="form-control" required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Technician</label>
                    <input type="text" name="b_ani_technician"  value="<?= $rec['testType']->technician; ?>" placeholder="technician" class="form-control" required>
                    </div>
                    
                    <div class="col-sm-3 form-group">
                    <label>Result</label>
                    <input type="text" name="b_ani_result"  value="<?= $rec['testType']->result; ?>" placeholder="result" class="form-control" required>
                    </div>
                    <div class="col-sm-6 form-group">
                    <label>History</label>
                    <textarea class="form-control" name="b_ani_history"  value="<?= $rec['testType']->history; ?>" cols="4" rows="3" required></textarea>
                    </div>
                  </div>
                 
                <?php
                  }else if($rec['testDetails']->test_id==8)
                  {
                ?>
<input type="hidden" name="brucella_human_id"       value="<?= $rec['testType']->brucella_human_id; ?>">
                 <div class="row" id="brucella_human">
                   <div class="col-sm-3 form-group">
                    <label>brucella abortus 20</label>
                    <input type="text" name="brucella_abortus_20"  value="<?= $rec['testType']->brucella_abortus_20;  ?>" placeholder="Enter brucella abortus 20" class="form-control" required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>brucella abortus 40</label>
                    <input type="text" name="brucella_abortus_40"  value="<?= $rec['testType']->brucella_abortus_40;  ?>"  placeholder="Enter brucella abortus 40" class="form-control " required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>brucella abortus 80</label>
                    <input type="text" name="brucella_abortus_80"  value="<?= $rec['testType']->brucella_abortus_80;  ?>"  placeholder="Enter brucella abortus 80" class="form-control " required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>brucella abortus 160</label>
                    <input type="text" name="brucella_abortus_160"  value="<?= $rec['testType']->brucella_abortus_160;  ?>"  placeholder="Enter brucella abortus 160" class="form-control " required>
                    </div>
                    
                    <div class="col-sm-3 form-group">
                    <label>brucella abortus 320</label>
                    <input type="text" name="brucella_abortus_320"  value="<?= $rec['testType']->brucella_abortus_320;  ?>"  placeholder=" Enter brucella abortus 320" class="form-control " required>
                    </div>
                    
                    <div class="col-sm-3 form-group">
                    <label>brucella meletensis 20</label>
                    <input type="text" name="brucella_meletensis_20"  value="<?= $rec['testType']->brucella_meletensis_20;  ?>"  placeholder=" Enter brucella_meletensis_20" class="form-control " required>
                    </div> 
                    <div class="col-sm-3 form-group">
                    <label>brucella meletensis 40</label>
                    <input type="text" name="brucella_meletensis_40"  value="<?= $rec['testType']->brucella_meletensis_40;  ?>"  placeholder=" Enter brucella meletensis 40" class="form-control " required>
                    </div> 
                    <div class="col-sm-3 form-group">
                    <label>brucella meletensis 80</label>
                    <input type="text" name="brucella_meletensis_80"  value="<?= $rec['testType']->brucella_meletensis_80;  ?>"  placeholder=" Enter brucella meletensis 80" class="form-control " required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>brucella meletensis 160</label>
                    <input type="text" name="brucella_meletensis_160"  value="<?= $rec['testType']->brucella_meletensis_160;  ?>"  placeholder=" Enter brucella meletensis 160" class="form-control " required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>brucella meletensis 320</label>
                    <input type="text" name="brucella_meletensis_320"  value="<?= $rec['testType']->brucella_meletensis_320;  ?>"  placeholder=" Enter brucella meletensis 320" class="form-control " required>
                    </div>
                    <div class="col-sm-6 form-group">
                    <label>Result status</label>
                    <input type="text" name="result_status" value="<?= $rec['testType']->result_status;  ?>"  placeholder=" Enter result status" class="form-control " required>
                    </div>
                </div>
               
                <?php
                  }else if($rec['testDetails']->test_id==9)
                  {
                ?>
<input type="hidden" name="tb_and_vph_id"           value="<?= $rec['testType']->tb_and_vph_id; ?>">
                 <div class="row" id="tb_and_vph">
                   <div class="col-sm-3 form-group">
                    <label>Symptoms</label>
                    <input type="text" name="symptoms" value="<?= $rec['testType']->symptoms; ?>" placeholder="Enter symptoms" class="form-control" required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Specimen</label>
                    <input type="text" name="specimen" value="<?= $rec['testType']->specimen; ?>"  placeholder="Enter Specimen" class="form-control " required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Lab Findings</label>
                    <input type="text" name="lab_findings" value="<?= $rec['testType']->lab_findings; ?>"  placeholder="Enter Lab Findings" class="form-control " required>
                    </div>
                    <div class="col-sm-3 form-group">
                    <label>Referred By</label>
                    <input type="text" name="referred_by" value="<?= $rec['testDetails']->referred_by; ?>"  placeholder="Enter Referred by" class="form-control " required>
                    </div>
                    
                    <div class="col-sm-6 form-group">
                    <label>Examined By</label>
                    <input type="text" name="vp_hp_examined_by" value="<?= $rec['testType']->examined_by; ?>"  placeholder=" Enter Examined By" class="form-control " required>
                    </div>
                    
                    <div class="col-sm-6 form-group">
                    <label>Remarks</label>
                    <input type="text" name="vp_hp_remarks" value="<?= $rec['testType']->remarks; ?>"  placeholder=" Enter Remarks" class="form-control " required>
                    </div>
                    </div>
                <?php
                 }
                ?>
               
            </div>
            <?php
              if($rec['testDetails']->post_status==0 && $rec['testDetails']->is_cancel==0)
              {
            ?>
               <div class="col-md-3">
                <div class="form-group">
                    <div class="row">
                      <div class="col-md-12">
                        <button type="submit"  onclick="return confirm('Are you sure to update the Record?');"  class="btn btn-block btn-primary mr-5"> Update Info </button><br>
                      </div>
                      <div class="col-md-12">
                        <button type="button" onclick="SubmitPost();" class="btn btn-block btn-success mr-5"> Post Invoice </button><br>
                      </div>
                      <div class="col-md-12">
                        <button data-backdrop="static" data-keyboard="false" data-toggle="modal" href="#cancelModal" type="button" class="btn btn-block btn-danger mr-5"> Cancel  </button>
                      </div>
                    </div>
                  </div>
              </div>
            <?php  
              }
            ?>
           
          </div>
          <hr>
                    
                </div>
                </form>
          </div>
          </div>
        </div>
      </div>
      </div>
      <!-- /.row -->
    </section>
     
</div>

   




<div class="modal" id="cancelModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Cancel Reason</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form action="<?php echo base_url('Tests/TestRecordCancel') ?>" method="post">
          <input type="hidden" name="testDetails_id" value="<?= $rec['testDetails']->testDetails_id;?>"> 
           <input type="hidden" name="uri" value="<?= $this->uri->segment(2);?>">
         <div class="box-body">
            <div class="col-sm-12 form-group">
              <!-- <label></label> -->
              <textarea name="cancel_reason" placeholder="Write in short words" class="form-control" required="required"></textarea>
            </div>
            <div class="form-group">
              <button type="submit"  onclick="return confirm('Are you sure to Cancel Record?');"  class="btn btn-info pull-right">Submit</button>
            </div>
         </div>
        </form>
      </div>

      <!-- Modal footer -->
     <!--  <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div> -->

    </div>
  </div>
</div>
<form id="postForm" action="<?php echo base_url('Tests/TestRecordPost') ?>" method="post">
  <input type="hidden" name="testDetails_id" value="<?= $rec['testDetails']->testDetails_id;?>"> 
   <input type="hidden" name="uri" value="<?= $this->uri->segment(2);?>">
</form>

<script type="text/javascript">
  function SubmitPost()
  {
    if(confirm('Warning! Your will not be able to update it, Once you posted')==true)
    {
       $('#postForm').submit();
    }
  }
</script>