<div class="content-wrapper">
    <section class="content-header">
      <h1>
       <!-- Sample Information -->
        
      </h1>
     
    </section>


    <!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
  Open modal
</button> -->

<!-- The Registeration Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog  modal-lg">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Add Sample</h4>
        <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form action="<?= base_url('Pagescontroller/addSample'); ?>" method="post" >
        <div class="box-body">
          <div class="row"> 
            <div class="col-md-12">
               <div class="row">
                  <div class="col-sm-12 form-group">
                    <label>Sample Name</label>
                    <input type="text" name="sample_name" placeholder="Enter Sample Name" class="form-control" required pattern="[a-zA-Z]+">
                  </div>
               </div>
            </div>
          </div>
                    <div class="form-group">
                      <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </div>
                </form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>


    <!-- Main content -->
<section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="card">
            <div class="card-header with-border">
              <b>Sample Information</b> <?php include'MessageAlert.php'; ?>
              <a class="btn btn-primary pull-right" data-backdrop="static" data-keyboard="false" data-toggle="modal" href='#myModal'>Add Sample</a>
            </div>
            <div class="card-body">
             <table class="table  table-hover table-striped" id="DataTable2">
              <thead>
                <tr class="bg-success">
                  <th>#</th>
                  <th>Sample</th>
                  <th>Action</th>
                </tr>
              </thead>
                <tbody>
                  <?php 
                  $count=1;
                foreach ($samples as $key => $sample) {
                  # code...
                  ?>
                  <tr>
                    <td class="bg-green"><?= $count++ ?></td>
                    <td><?= $sample->sample_name; ?></td>
                    <td>
                   <a data-backdrop="static" data-keyboard="false" data-toggle="modal" href='#myModal<?=$key?>'> <i class="fa fa-pencil-square-o  text-black"></i></a>
                   <a  onclick="return confirm('Are you sure to delete?');" href='<?= base_url('Pagescontroller/deleteSample/'.$sample->sample_id); ?>'> <i class="fa fa-trash  text-danger"></i></a>
                    </td>
<!--  The Updation Modal -->
<div class="modal" id="myModal<?= $key ?>">
  <div class="modal-dialog  modal-lg">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Update sample</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form action="<?= base_url('Pagescontroller/updateSampleRecord'); ?>" method="post"> 
        <div class="box-body">
          <div class="row"> 
            <div class="col-md-12">
               <div class="row">
                  <div class="col-sm-12 form-group">
                    <label>Sample Name</label>
                    <input type="text" value="<?= $sample->sample_name;?>" name="sample_name" placeholder="Enter Sample" class="form-control" required>
                    <input type="hidden" value="<?= $sample->sample_id;?>" name="sample_id">
                    </div>
          </div>
            </div>
            
          </div>
                    <div class="form-group">
                     <button type="submit" class="btn btn-primary" > Update Sample </button>
                    </div>
                </div>
                </form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
                    
                  </tr>
                  <?php  
                }

                   ?>
                </tbody>
            </table> 
          </div>
          </div>
        </div>
      </div>
      </div>
      <!-- /.row -->
    </section>
