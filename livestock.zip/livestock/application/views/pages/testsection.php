<div class="content-wrapper">
    <section class="content-header">
      <h1>
       <!-- Test Section Information -->
        
      </h1>
     
    </section>


    <!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
  Open modal
</button> -->


<div class="modal" id="myModal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Add Test Section</h4>
        <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form action="<?php echo base_url('Pagescontroller/Addtest_section') ?>" method="post">
        <div class="box-body">
          <div class="row">
                    <div class="col-sm-12 form-group">
                    <label> Directorate</label>
                    <select class="form-control directorate_id" onchange="GetStations(this.value)"  name="directorate_id"  style="width: 100%" required>
                    <option  value="">-select-</option>
                    <?php 
                    
                    foreach ($directorates as $directorate) {
                      # code...
                      ?>
                      <option  value="<?php echo $directorate->directorate_id; ?>"><?php echo $directorate->directorate_name; ?></option>
                      <?php 
                    }

                     ?>
                  </select>
                    </div>
                    <div class="col-sm-12 form-group">
                    <label> Center/Station</label>
                    <select class="form-control center_station_id"   name="center_station_id"  style="width: 100%" required>
                    <option  value="">-select-</option>
                     </select>
                    </div>
                    <div class="col-sm-12 form-group">
                    <label>Section Name</label>
                   <select class="form-control" name="sectionHelp_id"  style="width: 100%" required>
                    <option  value="">-select-</option>
                    <?php 
                    
                    foreach ($sectionhelp as $items) {
                      # code...
                      ?>
                      <option  value="<?php echo $items->sectionHelp_id; ?>"><?php echo $items->sectionHelp_name; ?></option>
                      <?php 
                    }

                     ?>
                  </select>
                    </div>
                  </div>
                    <div class="form-group">
                      <input type="submit" class="btn btn-primary" value="Save" id="rclass">
                    </div>
                </div>
                 </form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>


    <!-- Main content -->
<section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="card">
            <div class="card-header with-border">
              
              <b>Test Section Information</b><?php include'MessageAlert.php'; ?>
               <a class="btn btn-primary pull-right" data-backdrop="static" data-keyboard="false" data-toggle="modal" href='#myModal'>Add Test Section</a>
            </div>
            <div class="card-body">
             <table class="table table-bordered" id="DataTable2">
              <thead>
                <tr class="bg-success">
                  <th>#</th>
                  <th>Section</th>
                  <th>Center/Station</th>
                  <th>Directorate</th>
                  <th>Action</th>
                </tr>
                <tbody>
                  <?php 
                  $count=1;
                foreach ($testsection as $key => $testsection) {
                  # code...
                  ?>
                  <tr>
                    <td class="bg-green"><?php echo $count++ ?></td>
                    <td><?php echo $testsection->sectionHelp_name; ?></td>
                    <td><?php echo $testsection->center_station_name; ?></td>
                    <td><?php echo $testsection->directorate_name; ?></td>
                    <td><a data-backdrop="static" data-keyboard="false" data-toggle="modal" href='#testsection<?= $key; ?>'> <i class="fa fa-pencil-square-o  text-black "></i></a><a onclick="return confirm('Are you sure to delete?');"  href="<?= base_url('Pagescontroller/delete/'.$testsection->section_id);?>"><i class="fa fa-trash"></i></a></td>
<!-- The Modal -->
<div class="modal" id="testsection<?= $key; ?>">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Update Test Section</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form action="<?php echo base_url('Pagescontroller/testSectionUpdate') ?>" method="post">
        <div class="box-body">
                    <input type="hidden" name="section_id"  value="<?= $testsection->section_id; ?>">
                    <div class="col-sm-12 form-group">
                    <label> Directorate</label>
                    <select class="form-control  Updatedirectorate_id" onchange="GetStations(this.value)"   name="directorate_id"  style="width: 100%" required>
                    <option  value="">-select-</option>
                    <?php 
                    foreach ($directorates as $directorate) {
                      # code...
                      ?>
                      <option <?php if($directorate->directorate_id==$testsection->directorate_id){ echo "selected"; } ?>  value="<?php echo $directorate->directorate_id; ?>"><?php echo $directorate->directorate_name; ?></option>
                      <?php 
                    }

                     ?>
                  </select>
                    </div>
                    <div class="col-sm-12 form-group">
                    <label> Center/Station</label>
                    <select class="form-control center_station_id"   name="center_station_id"  style="width: 100%" required>
                     <?php 
                       $stations = $this->API_m->getRecordWhere('center_station',['directorate_id' => $testsection->directorate_id]);
                    foreach ($stations as $station) {
                      ?>
                      <option <?php if($station->center_station_id==$testsection->center_station_id){ echo "selected"; } ?>  value="<?php echo $station->center_station_id; ?>"><?php echo $station->center_station_name; ?></option>
                      <?php 
                    }
                    ?>
                     </select>
                    </div>
                    <div class="col-sm-12 form-group">
                    <label>Section Name</label>
                     <select class="form-control" name="sectionHelp_id"  style="width: 100%" required>
                    <option  value="">-select-</option>
                    <?php 
                    
                    foreach ($sectionhelp as $items) {
                      # code...
                      ?>
                      <option <?php if($items->sectionHelp_id==$testsection->sectionHelp_id){ echo "selected"; } ?>   value="<?php echo $items->sectionHelp_id; ?>"><?php echo $items->sectionHelp_name; ?></option>
                      <?php 
                    }

                     ?>
                  </select>
                    </div>
                   
                    <div class="form-group">
                     <button type="submit" class="btn btn-primary" > Update Test Section </button>
                    </div>
                </div>
                 </form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>                    
                    

                    
                    
                  </tr>
                  <?php  
                }

                   ?>
                </tbody>
              </thead>
            </table>
          </div>
          </div>
        </div>
      </div>
      </div>
      <!-- /.row -->
    </section>
    
