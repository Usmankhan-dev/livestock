<div class="content-wrapper">
    <section class="content-header">
      <h1>
      <!--  Center/Station Information -->
        
      </h1>
     
    </section>


    <!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
  Open modal
</button> -->


<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Add  Center/Station</h4>
        <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form action="<?php echo base_url('Pagescontroller/AddStation') ?>" method="post">
        <div class="box-body">
                    <div class="col-sm-12 form-group">
                    <label> Center/Station Name</label>
                    <input type="text" name="center_station_name" placeholder="Enter  Center/Station Name" class="form-control" required pattern="[a-zA-Z]+">
                    </div>
                    <div class="col-sm-12 form-group">
                    <label> Directorate</label>
                    <select class="form-control"  name="directorate_id"  style="width: 100%" required>
                      <option  value="">-select-</option>
                    <?php 
                    
                    foreach ($directorates as $direct) {
                      # code...
                      ?>
                      <option  value="<?php echo $direct->directorate_id; ?>"><?php echo $direct->directorate_name; ?></option>
                      <?php 
                    }

                     ?>
                  </select>
                    </div>
                    <div class="col-sm-12 form-group">
                    <label>District</label>
                     <select class="form-control"  name="district_id"  style="width: 100%" required>
                      <option  value="">-select-</option>
                    <?php 
                    
                    foreach ($districts as $district) {
                      # code...
                      ?>
                      <option value="<?php echo $district->district_id; ?>"><?php echo $district->district_name; ?></option>
                      <?php 
                    }

                     ?>
                  </select>
                    </div>
                     <div class="col-sm-12 form-group">
                        <label>Center/Station Address</label>
                        <textarea class="form-control" name="center_station_address" cols="4" rows="3" ></textarea>
                      </div>
                    <div class="form-group">
                      <input type="submit" class="btn btn-primary" value="Save" id="rclass">
                    </div>
                </div>
                 </form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>


    <!-- Main content -->
<section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="card">
            <div class="card-header with-border">
              <b> Center/Station Information</b><?php include'MessageAlert.php'; ?>
               <a class="btn btn-primary pull-right" data-backdrop="static" data-keyboard="false" data-toggle="modal" href='#myModal'>Add Center/Station</a>
            </div>
            <div class="card-body">
             <table class="table table-bordered" id="DataTable2">
              <thead>
                <tr class="bg-success">
                  <th>#</th>
                  <th>Center/Station</th>
                  <th>Directorate</th>
                  <th>District</th>
                  <th>Address</th>
                  <th>Action</th>
                </tr>
                <tbody>
                  <?php 
                  $count=1;
                foreach ($stations as $key => $station) {
                  # code...
                  ?>
                  <tr>
                    <td class="bg-green"><?php echo $count++ ?></td>
                    <td><?php echo $station->center_station_name; ?></td>
                    <td><?php echo $station->directorate_name; ?></td>
                    <td><?php echo $station->district_name; ?></td>
                    <td><?php echo $station->center_station_address; ?></td>
                    <td><a data-backdrop="static" data-keyboard="false" data-toggle="modal" href='#station<?= $key; ?>'> <i class="fa fa-pencil-square-o  text-black secedit"></i></a><a onclick="return confirm('Are you sure to delete?');" href="<?=  base_url('Pagescontroller/StationDelete/'.$station->center_station_id) ?>"> <i class="fa fa-trash  text-black secedit"></i></a></td>
<!-- The Modal -->
<div class="modal" id="station<?= $key; ?>">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Update Center/Station</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form action="<?php echo base_url('Pagescontroller/StationUpdate') ?>" method="post">
        <div class="box-body">
                    <input type="hidden" name="center_station_id"  value="<?=  $station->center_station_id; ?>">
                    <div class="col-sm-12 form-group">
                   <label> Center/Station Name</label>
                    <input type="text" name="center_station_name" value="<?php echo $station->center_station_name; ?>" placeholder="Enter  Center/Station Name" class="form-control">
                    </div>
                    <div class="col-sm-12 form-group">
                    <label> Directorate</label>
                    <select class="form-control"  name="directorate_id"  style="width: 100%" required>
                    <?php 
                    
                    foreach ($directorates as $direct) {
                      # code...
                      ?>
                      <option <?php if($direct->directorate_id==$station->directorate_id){ echo "selected";} ?> value="<?php echo $direct->directorate_id; ?>"><?php echo $direct->directorate_name; ?></option>
                      <?php 
                    }

                     ?>
                  </select>
                    </div>
                    <div class="col-sm-12 form-group">
                    <label>District</label>
                     <select class="form-control"  name="district_id"  style="width: 100%" required>
                    <?php 
                    
                    foreach ($districts as $district) {
                      # code...
                      ?>
                      <option <?php if($district->district_id==$station->district_id){ echo "selected";} ?> value="<?php echo $district->district_id; ?>"><?php echo $district->district_name; ?></option>
                      <?php 
                    }

                     ?>
                  </select>
                    </div>
                     <div class="col-sm-12 form-group">
                        <label>Center/Station Address</label>
                        <textarea class="form-control" name="center_station_address" cols="4" rows="3"> <?= $station->center_station_address; ?> </textarea>
                      </div>
                    <div class="form-group">
                     <button type="submit" class="btn btn-primary" > Update Center/Station </button>
                    </div>
                </div>
                 </form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>                    
                    

                    
                    
                  </tr>
                  <?php  
                }

                   ?>
                </tbody>
              </thead>
            </table>
          </div>
          </div>
        </div>
      </div>
      </div>
      <!-- /.row -->
    </section>
    
