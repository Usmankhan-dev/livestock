<div class="content-wrapper">
    <section class="content-header">
      <h1>
<!--        Antibiotics Information -->
        
      </h1>
     
    </section>

<!-- The Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Add Antibiotics</h4>
        <!-- <button  type="button" class="close" data-dismiss="modal">&times;</button> -->
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form action="<?php echo base_url('Pagescontroller/AddAntibiotics') ?>" method="post">
        <div class="box-body">
                    <div class="col-sm-12 form-group">
                    <label>Antibiotics Name</label>
                    <input type="text" name="antibiotic_name" placeholder="Enter Antibiotics Name" class="form-control" required="" pattern="[a-zA-Z]+">
                    </div>
                    <div class="form-group">
                      <input type="submit" class="btn btn-primary" value="Save" id="rclass">
                    </div>
                </div>
                 </form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>


    <!-- Main content -->
<section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="card">
             
            <div class="card-header with-border">
              <b>Antibiotics Information</b>
<?php include 'MessageAlert.php'; ?>               
              <a data-backdrop="static" data-keyboard="false" class="btn btn-primary pull-right" data-toggle="modal" href='#myModal'>Add Antibiotics</a>
            </div>
            <div class="card-body">
             <table class="table table-hover table-bordered" id="DataTable2">
              <thead>
                <tr class="bg-success">
                  <th>#</th>
                  <th>Antibiotic Name</th>
                  <th>Action</th>
                </tr>
                <tbody>
                  <?php 
                  $count=1;
                foreach ($antibiotics as $key => $antibiotic) {
                  # code...
                  ?>
                  <tr>
                    <td class="bg-green"><?php echo $count++ ?></td>
                    <td><?php echo $antibiotic->antibiotics_name; ?></td>
                    <td>
                   <a data-backdrop="static" data-keyboard="false" data-toggle="modal" href='#upd<?=$key?>'> <i class="fa fa-pencil-square-o  text-black"></i></a>
                   <a  onclick="return confirm('Are you sure to delete?');" href='<?= base_url('Pagescontroller/DeleteAntibiotic/'.$antibiotic->antibiotics_id); ?>'> <i class="fa fa-trash  text-danger"></i></a>
                    </td>
                    
    <!--  The Updation Modal -->
<div class="modal" id="upd<?= $key ?>">
  <div class="modal-dialog  modal-lg">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Update Antibiotic</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form action="<?= base_url('Pagescontroller/updateAntibioticRecord'); ?>" method="post"> 
        <div class="box-body">
          <div class="row"> 
            <div class="col-md-12">
               <div class="row">
                  <div class="col-sm-12 form-group">
                    <label>Antibiotic Name</label>
                    <input type="text" value="<?= $antibiotic->antibiotics_name;?>" name="antibiotic_name" placeholder="Enter Antibiotic" class="form-control" required>
                    <input type="hidden" value="<?= $antibiotic->antibiotics_id;?>" name="antibiotic_id">
                    </div>
          </div>
            </div>
            
          </div>
                    <div class="form-group">
                     <button type="submit" class="btn btn-primary" > Update Antibiotic </button>
                    </div>
                </div>
                </form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>                

                    
                    
                  </tr>
                  <?php  
                }

                   ?>
                </tbody>
              </thead>
            </table>
          </div>
          </div>
        </div>
      </div>
      </div>
      <!-- /.row -->
    </section>
    
