<div class="content-wrapper">
    <section class="content-header">
      <h1>
       <!-- Directorates Information -->
        
      </h1>
     
    </section>


    <!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
  Open modal
</button> -->


<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Add Directorate</h4>
        <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form action="<?php echo base_url('Pagescontroller/AddDirectorate') ?>" method="post">
        <div class="box-body">
                    <div class="col-sm-12 form-group">
                    <label>Directorate Name</label>
                    <input type="text" name="directorate_name" placeholder="Enter directorate Name" class="form-control" required pattern="[a-zA-Z]+">
                    </div>
                     <div class="col-sm-12 form-group">
                    <label>Head of Directorate </label>
                    <input type="text" name="directorate_head" placeholder="Enter directorate head Name" class="form-control" required pattern="[a-zA-Z]+">
                    </div>
                    <div class="form-group">
                      <input type="submit" class="btn btn-primary" value="Save" id="rclass">
                    </div>
                </div>
                 </form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>


    <!-- Main content -->
<section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="card">
            <div class="card-header with-border">
               <b> Directorates Information</b> <?php include'MessageAlert.php'; ?>
               <a class="btn btn-primary pull-right" data-backdrop="static" data-keyboard="false" data-toggle="modal" href='#myModal'>Add Directorate</a>
            </div>
            <div class="card-body">
             <table class="table table-striped table-hover" id="DataTable2">
              <thead>
                <tr class="bg-success">
                  <th>#</th>
                  <th>Directorate</th>
                  <th>HoD</th>
                  <th>Action</th>
        
                </tr>
                <tbody>
                  <?php 
                  $count=1;
                foreach ($directorates as $key => $direct) {
                  # code...
                  ?>
                  <tr>
                    <td class="bg-green"><?php echo $count++ ?></td>
                    <td><?php echo $direct->directorate_name; ?></td>
                    <td><?php echo $direct->directorate_head; ?></td>
                    <td><a data-backdrop="static" data-keyboard="false" data-toggle="modal" href='#direct<?= $key; ?>'> <i class="fa fa-pencil-square-o  text-black secedit"></i></a><a onclick="return confirm('Are you sure to delete?');" href="<?=  base_url('Pagescontroller/directorateDelete/'.$direct->directorate_id) ?>"> <i class="fa fa-trash  text-black secedit"></i></a></td>
<!-- The Modal -->
<div class="modal" id="direct<?= $key; ?>">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Update Directorate</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form action="<?php echo base_url('Pagescontroller/directoreatesUpdate') ?>" method="post">
                    <input type="hidden" name="directorate_id"  value="<?= $direct->directorate_id; ?>">
        <div class="box-body">
                    <div class="col-sm-12 form-group">
                    <label>Directorate Name</label>
                    <input type="text" name="directorate_name" placeholder="Enter Directorate Name" class="form-control" value="<?= $direct->directorate_name; ?>">
                    </div>
                     <div class="col-sm-12 form-group">
                    <label>Directorate Head</label>
                    <input type="text" name="directorate_head" placeholder="Enter Name of Head of Directorate " class="form-control" value="<?= $direct->directorate_head; ?>">
                    </div>
                    <div class="form-group">
                     <button type="submit" class="btn btn-primary" > Update Directorate </button>
                    </div>
                </div>
                 </form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>                    
                    

                    
                    
                  </tr>
                  <?php  
                }

                   ?>
                </tbody>
              </thead>
            </table>
          </div>
          </div>
        </div>
      </div>
      </div>
      <!-- /.row -->
    </section>
    