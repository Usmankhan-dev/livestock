<div class="content-wrapper">
    <section class="content-header">
      <h1>
        <!-- Lab Information -->
        
      </h1>
     
    </section>


 
<div class="modal" id="myModal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Add Lab</h4>
        <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form action="<?php echo base_url('Districtlabscontroller/districtlab'); ?>" method="post">
        <div class="box-body">
          <div class="row">
                    
                  <div class="col-sm-12 form-group">
                    <label> Directorates</label>
                    <select class="form-control directorate_id" onchange="GetStations(this.value)"  name="directorate_id"  style="width: 100%" required>
                    <option  value="">-select-</option>
                    <?php 
                    
                    foreach ($directorates as $directorate) {
                      # code...
                      ?>
                      <option  value="<?php echo $directorate->directorate_id; ?>"><?php echo $directorate->directorate_name; ?></option>
                      <?php 
                    }

                     ?>
                  </select>
                    </div>
                  <div class="col-sm-12 form-group">
                    <label> Center/Station</label>
                    <select class="form-control center_station_id" onchange="GetSections(this.value)"  name="center_station_id"  style="width: 100%" required>
                      <option  value="">-select-</option>
                    
                     </select>
                    </div>
                    <div class="col-sm-12 form-group">
                  <label for="location">Section</label>
                  <select class="form-control section_id"  name="section_id"  style="width: 100%" required>
                  <option  value="">-select-</option>
                  </select>
                </div>
                    <div class="col-sm-12 form-group">
                      <span><?php echo validation_errors('lab_name'); ?> </span>
                    <label>Lab Name</label> 
                    <input type="text" name="lab_name" placeholder="Enter Lab Name" class="form-control" required required pattern="[a-zA-Z]+">
                    </div>
                <div class="col-sm-6 form-group">
                   <span><?php echo validation_errors('lab_description'); ?> </span>
                  <label>Lab Description</label>
                  <textarea class="form-control" name="lab_description" cols="4" rows="3" required=""></textarea>
                </div>
            </div>
                    <div class="form-group">
                      <input type="submit" class="btn btn-primary" value="Save" id="rclass">
                    </div>
                </div>
                 </form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>


    <!-- Main content -->
<section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="card">
            <div class="card-header with-border">
            <b>Lab Information</b>  <?php include'MessageAlert.php'; ?>
               <a data-backdrop="static" data-keyboard="false" class="btn btn-primary pull-right" data-toggle="modal" href='#myModal'>Add Lab</a>
            </div>
            <div class="card">
             <table class="table table-striped table-hover" id="DataTable2">
              <thead>
                <tr class="bg-success">
                  <th>#</th>
                  <th>Lab</th>
                  <th>Section</th>
                  <th>Center/Station</th>
                  <th>Description</th>
                  <th>Action</th>
        
                </tr>
                <tbody>
                  <?php 
                  $count=1;
                foreach ($districtlab as $key => $districtlabs) {
                  # code...
                  ?>
                  <tr>
                    <td class="bg-green"><?php echo $count++ ?></td>
                    <td><?php echo $districtlabs->lab_name; ?></td>
                    <td><?php echo $districtlabs->sectionHelp_name; ?></td>
                    <td><?php echo $districtlabs->center_station_name; ?></td>
                    <td><?php echo $districtlabs->lab_description; ?></td>
                    <td><a data-backdrop="static" data-keyboard="false" data-toggle="modal" href='#districtlab<?= $key; ?>'> <i class="fa fa-pencil-square-o  text-black dislabedit"></i></a>
                      <a  onclick="return confirm('Are you sure to delete?');" href='<?= base_url('Districtlabscontroller/delete/'.$districtlabs->lab_id); ?>'> <i class="fa fa-trash  text-danger"></i></a>
                    </td>
                    
<div class="modal" id="districtlab<?= $key; ?>">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Update Lab</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form action="<?php echo base_url('Districtlabscontroller/UpdateLab/') ?>" method="post">
          <input type="hidden" value="<?= $districtlabs->lab_id; ?>"  name="lab_id">
        <div class="box-body">
                <div class="row">
                    <div class="col-sm-12 form-group">
                    <label> Directorates</label>
                    <select class="form-control directorate_id" onchange="GetStations(this.value)"  name="directorate_id"  style="width: 100%" required>
                    <option  value="">-select-</option>
                    <?php 
                    
                    foreach ($directorates as $directorate) {
                      # code...
                      ?>
                      <option  <?php if($directorate->directorate_id==$districtlabs->directorate_id){ echo "selected";} ?>  value="<?php echo $directorate->directorate_id; ?>"><?php echo $directorate->directorate_name; ?></option>
                      <?php 
                    }

                     ?>
                  </select>
                    </div>
                  <div class="col-sm-12 form-group">
                    <label> Center/Station</label>
                    <select class="form-control center_station_id" onchange="GetSections(this.value)"  name="center_station_id"  style="width: 100%" required>
                      <?php 
                       $stations = $this->API_m->getRecordWhere('center_station',['directorate_id' => $districtlabs->directorate_id]);
                    foreach ($stations as $station) {
                      # code...
                      ?>
                      <option <?php if($station->center_station_id==$districtlabs->center_station_id){ echo "selected";} ?> value="<?php echo $station->center_station_id; ?>"><?php echo $station->center_station_name; ?></option>
                      <?php 
                    }

                     ?>
                     </select>
                    </div>
                    <div class="col-sm-6 form-group">
                  <label for="location">Section</label>
                  <select class="form-control section_id"  name="section_id"  style="width: 100%" required>
                    <option  value="">-select-</option>
                    <?php 
                    $sections = $this->API_m->GetSectionsItems($districtlabs->center_station_id);
                    foreach ($sections as $section) {
                      # code...
                      ?>
                      <option <?php if($section->section_id==$districtlabs->section_id){ echo "selected";} ?> value="<?php echo $section->section_id; ?>"><?php echo $section->sectionHelp_name; ?></option>
                      <?php 
                    }

                     ?>
                  </select>
                </div>
                <div class="col-sm-6 form-group">
                    <label>Lab Name</label>
                    <input type="text" name="labname" placeholder="Enter Lab Name" class="form-control" required value="<?= $districtlabs->lab_name; ?>">
                    </div>
                <div class="col-sm-6 form-group">
                  <label>Lab Description</label>
                  <textarea class="form-control" id="" name="lab_description" cols="4" rows="3"><?= $districtlabs->lab_description; ?></textarea>
                </div>
              </div>
                    <div class="form-group">
                     <button type="submit" class="btn btn-primary" > Update Lab</button>
                    </div>
                </div>
                 </form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
<!-- The Modal -->
                    
                    
                  </tr>
                  <?php  
                }

                   ?>
                </tbody>
              </thead>
            </table>
          </div>
          </div>
        </div>
      </div>
      </div>
      <!-- /.row -->
    </section>
