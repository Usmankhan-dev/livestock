<?php 
	
	
	defined('BASEPATH') OR exit('No direct script access allowed');
	
	class Dashboard extends CI_Controller {


		function __construct()
		{
			parent::__construct();
            date_default_timezone_set('Asia/Karachi');
            if(empty($this->session->userdata('user')))
            {
                redirect('Login/logout');
            }
$role_id               = $this->session->userdata('user')['role'];
$permissions           = $this->User_m->getRecordWhere('role_permissions',['role_id' => $role_id]); 
if($permissions[0]->module_id == 1 && $permissions[0]->show_none==1)
{
     redirect('Login/logout');
}        
			
		}
	
		public function index()
		{	
$user_id               = $this->session->userdata('user')['user_id'];
$role_id               = $this->session->userdata('user')['role'];
$lab_id                = $this->session->userdata('user')['lab_id'];
$permissions           = $this->User_m->getRecordWhere('role_permissions',['role_id' => $role_id]); 
$data['registered']                = '';
$data['pending']                   = '';
$data['labs']                      = '';
$data['tests']                     = '';
$data['mastitis']                  = '';
$data['haematology']               = '';
$data['impression_smear']          = '';
$data['urine_examination']         = '';
$data['brucella_human']            = '';
$data['brucella_animal_combine']   = '';
$data['brucella_animal_ind']       = '';
$data['tb_and_vph']                = '';
if($permissions[0]->module_id == 1 && $permissions[0]->show_all==1)
{
$data['registered']              = $this->API_m->countAllRows('testdetails');
$data['pending']                 = $this->API_m->countWhereAllRows('testdetails',['post_status' => 0,'is_cancel' => 0]);
$data['labs']                    = $this->API_m->countWhereAllRows('labs',['is_trash' => 0]);
$data['tests']                   = $this->API_m->countAllRows('tests');
$data['mastitis']                = $this->API_m->countAllRows('mastitis');
$data['haematology']             = $this->API_m->countAllRows('haematology');
$data['impression_smear']        = $this->API_m->countAllRows('impression_smear');
$data['urine_examination']       = $this->API_m->countAllRows('urine_examination');
$data['brucella_human']          = $this->API_m->countAllRows('brucella_human');
$data['brucella_animal_combine'] = $this->API_m->countAllRows('brucella_animal_combine');
$data['brucella_animal_ind']     = $this->API_m->countAllRows('brucella_animal_ind');
$data['tb_and_vph']              = $this->API_m->countAllRows('tb_and_vph');

}else if($permissions[0]->module_id == 1 && $permissions[0]->show_lab_by==1)
{
$data['registered']              = $this->API_m->countByLabTestdetails($lab_id);
$data['pending']                 = $this->API_m->countByLabTestdetailsPending($lab_id);
$data['labs']                    = $this->API_m->countWhereAllRows('labs',['lab_id'=>$lab_id,'is_trash' => 0]);
$data['tests']                   = $this->API_m->countAllRows('tests',['lab_id'=>$lab_id]);
$data['mastitis']                = $this->API_m->countByLabTestType($lab_id,3);
$data['haematology']             = $this->API_m->countByLabTestType($lab_id,2);
$data['impression_smear']        = $this->API_m->countByLabTestType($lab_id,1);
$data['urine_examination']       = $this->API_m->countByLabTestType($lab_id,5);
$data['brucella_human']          = $this->API_m->countByLabTestType($lab_id,8);
$data['brucella_animal_combine'] = $this->API_m->countByLabTestType($lab_id,6);
$data['brucella_animal_ind']     = $this->API_m->countByLabTestType($lab_id,7);
$data['tb_and_vph']              = $this->API_m->countByLabTestType($lab_id,9);
}else if($permissions[0]->module_id == 1 && $permissions[0]->show_none==1)
{
$data['registered']                = '';
$data['pending']                   = '';
$data['labs']                      = '';
$data['tests']                     = '';
$data['mastitis']                  = '';
$data['haematology']               = '';
$data['impression_smear']          = '';
$data['urine_examination']         = '';
$data['brucella_human']            = '';
$data['brucella_animal_combine']   = '';
$data['brucella_animal_ind']       = '';
$data['tb_and_vph']                = '';
}
			$data['logUser']   = $this->User_m->getLogUserInfo();
			$data['logLab']    = $this->User_m->getLogUserLabInfo();
            $this->load->view('template_parts/header',$data);
            $this->load->view('template_parts/menu');
            $this->load->view('template_parts/asidemenu');
			$this->load->view('pages/index',$data);
			$this->load->view('template_parts/footer');
			
		}
}