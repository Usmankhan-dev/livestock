<?php 

	
	defined('BASEPATH') OR exit('No direct script access allowed');
	
	class Tests extends CI_Controller {
		function __construct()
		{
			parent::__construct();
            date_default_timezone_set('Asia/Karachi');
            if(empty($this->session->userdata('user')))
            {
                redirect('Login/logout');
            }
$role_id               = $this->session->userdata('user')['role'];
$permissions           = $this->User_m->getRecordWhere('role_permissions',['role_id' => $role_id]); 
if($permissions[2]->module_id == 3 && $permissions[2]->show_none==1)
{
   redirect('Login/logout');
}   
		}

/****************************************************
*													*
*		Tests, Samples, Tests Types VIEWS			*
*													*
****************************************************/
		
        public function test_records()
        {

            $data['records']    = $this->API_m->get_testdetail();
            $data['logUser']    = $this->User_m->getLogUserInfo();
            $data['logLab']     = $this->User_m->getLogUserLabInfo();
            $this->load->view('template_parts/header',$data);
            $this->load->view('template_parts/menu');
            $this->load->view('template_parts/asidemenu');
            $this->load->view('pages/test_records',$data);
            $this->load->view('template_parts/footer');
        }
        public function pending_records()
        {

            $data['records']    = $this->API_m->get_Pendingtestdetail();
            $data['logUser']    = $this->User_m->getLogUserInfo();
            $data['logLab']     = $this->User_m->getLogUserLabInfo();
            $this->load->view('template_parts/header',$data);
            $this->load->view('template_parts/menu');
            $this->load->view('template_parts/asidemenu');
            $this->load->view('pages/pending_records',$data);
            $this->load->view('template_parts/footer');
        }
        public function posted_records()
        {

            $data['records']    = $this->API_m->get_Postedtestdetail();
            $data['logUser']    = $this->User_m->getLogUserInfo();
            $data['logLab']     = $this->User_m->getLogUserLabInfo();
            $this->load->view('template_parts/header',$data);
            $this->load->view('template_parts/menu');
            $this->load->view('template_parts/asidemenu');
            $this->load->view('pages/posted_records',$data);
            $this->load->view('template_parts/footer');
        }
        public function cancelled_records()
        {

            $data['records']    = $this->API_m->get_Cancelledtestdetail();
            $data['logUser']    = $this->User_m->getLogUserInfo();
            $data['logLab']     = $this->User_m->getLogUserLabInfo();
            $this->load->view('template_parts/header',$data);
            $this->load->view('template_parts/menu');
            $this->load->view('template_parts/asidemenu');
            $this->load->view('pages/cancelled_records',$data);
            $this->load->view('template_parts/footer');
        }
        public function addNew_test()
        {
            // $data['testdetail'] = $this->API_m->get_testdetail();
$user_id               = $this->session->userdata('user')['user_id'];
$role_id               = $this->session->userdata('user')['role'];
$lab_id                = $this->session->userdata('user')['lab_id'];
$permissions           = $this->User_m->getRecordWhere('role_permissions',['role_id' => $role_id]); 
 $data['tests']        = '';
if($permissions[2]->module_id == 3 && $permissions[2]->show_all==1)
{
$data['tests']      = $this->API_m->getAllTestTypes();
}else if($permissions[2]->module_id == 3 && $permissions[2]->show_lab_by==1)
{
 $data['tests']      = $this->API_m->getAllTestTypes_byLab($lab_id);
}else if($permissions[2]->module_id == 3 && $permissions[2]->show_created_by==1)
{
// $data['tests']      = $this->API_m->getRecordWhere('tests',['created_by'=>$user_id,'is_trash'=>0]);
 $data['tests']      = $this->API_m->getAllTestTypes_byLab($lab_id);
}else if($permissions[2]->module_id == 3 && $permissions[2]->show_none==1)
{
$data['tests']         = '';
}

            $data['cattles']    = $this->API_m->getRecordWhere('cattles',['is_trash'=>0]);
            $data['logUser']    = $this->User_m->getLogUserInfo();
            $data['logLab']     = $this->User_m->getLogUserLabInfo();
            $this->load->view('template_parts/header',$data);
            $this->load->view('template_parts/menu');
            $this->load->view('template_parts/asidemenu');
            $this->load->view('pages/addNew_test',$data);
            $this->load->view('template_parts/footer');
        }
        public function updateTestDetailsRecord($id)
        {
$user_id               = $this->session->userdata('user')['user_id'];
$role_id               = $this->session->userdata('user')['role'];
$lab_id                = $this->session->userdata('user')['lab_id'];
$permissions           = $this->User_m->getRecordWhere('role_permissions',['role_id' => $role_id]); 
 $data['tests']        = '';
if($permissions[2]->module_id == 3 && $permissions[2]->show_all==1)
{
$data['tests']      = $this->API_m->getAllTestTypes();
}else if($permissions[2]->module_id == 3 && $permissions[2]->show_lab_by==1)
{
 $data['tests']      = $this->API_m->getAllTestTypes_byLab($lab_id);
}else if($permissions[2]->module_id == 3 && $permissions[2]->show_created_by==1)
{
// $data['tests']      = $this->API_m->getRecordWhere('tests',['created_by'=>$user_id,'is_trash'=>0]);
 $data['tests']      = $this->API_m->getAllTestTypes_byLab($lab_id);
}else if($permissions[2]->module_id == 3 && $permissions[2]->show_none==1)
{
$data['tests']         = '';
}
            $data['cattles']    = $this->API_m->getRecordWhere('cattles',['is_trash'=>0]);
            $data['rec']        = $this->API_m->SingleTestRecord($id);
            $data['samples']    = $this->API_m->getAllTestSamples($data['rec']['testDetails']->test_id);
            $data['logUser']    = $this->User_m->getLogUserInfo();
            $data['logLab']     = $this->User_m->getLogUserLabInfo();
            $this->load->view('template_parts/header',$data);
            $this->load->view('template_parts/menu');
            $this->load->view('template_parts/asidemenu');
            $this->load->view('pages/updateTestDetailsRecord',$data);
            $this->load->view('template_parts/footer');
        }
         public function singleTestDetailRecord($id)
         {
            $data['rec']        = $this->API_m->SingleTestdetailsRecord($id);
            $data['logUser']    = $this->User_m->getLogUserInfo();
            $data['logLab']     = $this->User_m->getLogUserLabInfo();
            $this->load->view('template_parts/header',$data);
            $this->load->view('template_parts/menu');
            $this->load->view('template_parts/asidemenu');
            $this->load->view('pages/test_details_info',$data);
            $this->load->view('template_parts/footer');
        }

/****************************************************
*													*
*	OPERATION OF Tests, Samples, Tests Types     	*
*													*
****************************************************/

	

// MAIN TEST PORTION 

    public function getTestSamples()
    {
        $test_id = $this->input->post('test_id');
        $samples = $this->API_m->getAllTestSamples($test_id);
        // echo "<pre>";
       echo json_encode($samples);
  
    }

    public function AddNewTestRec()
    {
        echo "<pre>";
        print_r($_POST);
        exit();
            $type        = $this->input->post('client_type');
            $test_id     = $this->input->post('test_id');
            $tests       = $this->API_m->singleRecord('tests', ['test_id' => $test_id]);

            $clientInfo  = [
                'client_name'      => $this->input->post('client_name'),
                'client_contact'   => $this->input->post('client_contact'),
                'type'             => $this->input->post('client_type'),
                'client_cnic'      => $this->input->post('client_cnic'),
                'referred_by'      => $this->input->post('referred_by'),
                'client_address'   => $this->input->post('client_address'),
                'created_by'       => $this->session->userdata('user')['user_id'],
            ];
        $client_id = $this->API_m->create('client_info',$clientInfo);
            $TestInfo = [
                'test_id'          => $test_id,
                'sample_id'        => $this->input->post('sample_id'),
                'sample_desc'      => $this->input->post('sample_desc'),
                'client_id'        => $client_id,
                'cattle_name'      => $this->input->post('cattle_name'),
                'cattle_tag_no'    => $this->input->post('cattle_tag_no'),
                'cattle_sex'       => $this->input->post('cattle_sex'),
                'cattle_age'       => $this->input->post('cattle_age'),
                'cattle_breed'     => $this->input->post('cattle_breed'),
                'cattle_total_no'  => $this->input->post('cattle_total_no'),
                'test_total_fee'   => $this->input->post('test_total_fee'),
                'additional_info'  => $this->input->post('additional_info'),
                'received_date'    => date('Y-m-d',strtotime($this->input->post('received_date'))),
                'created_by'       => $this->session->userdata('user')['user_id'],
            ];
        $TestInfo_id = $this->API_m->create('testdetails',$TestInfo);
        if($tests->testHelp_id==1)
        {
            $ImpressionSmear = [
                'testDetails_id'   =>  $TestInfo_id,
                'type_specimen'    =>  $this->input->post('type_specimen'),
                'animals_specimen' =>  $this->input->post('animals_specimen'),
                'examined_for'     =>  $this->input->post('examined_for'),
                'result'           =>  $this->input->post('result'),
                'remarks'          =>  $this->input->post('remarks'),
                'examined_by'      =>  $this->input->post('examined_by'),
                'created_by'       =>  $this->session->userdata('user')['user_id'],
            ];
         $this->API_m->create('impression_smear',$ImpressionSmear);
            
        }else if($tests->testHelp_id==2)
        {
            $haematology = [
                'testDetails_id'            =>  $TestInfo_id,
                'haemoglobin'               => $this->input->post('haemoglobin'),
                'ESR'                       => $this->input->post('ESR'),
                'TRBC'                      => $this->input->post('TRBC'),
                'TLC'                       => $this->input->post('TLC'),
                'PCV'                       => $this->input->post('PCV'),
                'neutrophils'               => $this->input->post('neutrophils'),
                'lymphocytes'               => $this->input->post('lymphocytes'),
                'eosinophils'               => $this->input->post('eosinophils'),
                'monocytes'                 => $this->input->post('monocytes'),
                'basophils'                 => $this->input->post('basophils'),
                'protozoa'                  => $this->input->post('protozoa'),
                'iodine_flocculation_test'  => $this->input->post('iodine_flocculation_test'),
                'created_by'                => $this->session->userdata('user')['user_id'],
            ];
         $this->API_m->create('haematology',$haematology);
        }else if($tests->testHelp_id==3)
        {
            $Mastitis = [
                'testDetails_id'                 => $TestInfo_id,
                'daily_milk_production'          => $this->input->post('daily_milk_production'),
                'lactation_no'                   => $this->input->post('lactation_no'),
                'total_animals_at_farm'          => $this->input->post('total_animals_at_farm'),
                'in_milk'                        => $this->input->post('in_milk'),
                'dry_period_given'               => $this->input->post('dry_period_given'),
                'cal_kid_lambing_date'           => $this->input->post('cal_kid_lambing_date'),
                'prev_mastatis_rec_of_anim'      => $this->input->post('prev_mastatis_rec_of_anim'),
                'prev_mastatis_rec_of_farm'      => $this->input->post('prev_mastatis_rec_of_farm'),
                'prac_mastatis_test_at_farm'     => $this->input->post('prac_mastatis_test_at_farm'),
                'sample_received'                => $this->input->post('sample_received'),
                'test_required'                  => $this->input->post('test_required'),
                'refer_to_bacteriology_sec_for'  => $this->input->post('refer_to_bacteriology_sec_for'),
                'created_by'                     => $this->session->userdata('user')['user_id'],
            ];
         $this->API_m->create('mastitis',$Mastitis);
        }else if($tests->testHelp_id==4)
        {
            $culture_sensitivity = [
                'testDetails_id'   => $TestInfo_id,
                'antibiotics_id'   => $this->input->post('intibiotics'),
                'sensitivity'      => $this->input->post('sensitivity'),
                'tested_by'        => $this->input->post('tested_by'),
                'reports'          => $this->input->post('reports'),
                'created_by'       => $this->session->userdata('user')['user_id'],
            ];
         $this->API_m->create('culture_sensitivity',$culture_sensitivity);
        }else if($tests->testHelp_id==5)
        {
            $urine_examination = [
                'testDetails_id'   =>  $TestInfo_id,
                'colour'           =>  $this->input->post('colour'),
                'appearance'       =>  $this->input->post('appearance'),
                'reaction'         =>  $this->input->post('reaction'),
                'specific_gravity' =>  $this->input->post('specific_gravity'),
                'glucose'          =>  $this->input->post('glucose'),
                'protein'          =>  $this->input->post('protein'),
                'bile_salts'       =>  $this->input->post('bile_salts'),
                'bile_pigments'    =>  $this->input->post('bile_pigments'),
                'ketone_bodies'    =>  $this->input->post('ketone_bodies'),
                'haemoglobin'      =>  $this->input->post('haemoglobin'),
                'pus_cell'         =>  $this->input->post('pus_cell'),
                'epithelial_cell'  =>  $this->input->post('epithelial_cell'),
                'rb_cs'            =>  $this->input->post('rb_cs'),
                'casts'            =>  $this->input->post('casts'),
                'crystals'         =>  $this->input->post('crystals'),
                'amorphous'        =>  $this->input->post('amorphous'),
                'parasites'        =>  $this->input->post('parasites'),
                'bacteria'         =>  $this->input->post('bacteria'),
                'remarks'          =>  $this->input->post('ur_remarks'),
                'examined_by'      =>  $this->input->post('ur_examined_by'),
                'created_by'       =>  $this->session->userdata('user')['user_id'],
            ];
         $this->API_m->create('urine_examination',$urine_examination);
        }else if($tests->testHelp_id==6)
        {
            $brucella_ani_com = [
                'testDetails_id'           =>  $TestInfo_id,
                'tag_no'                   =>  $this->input->post('cattle_tag_no'),
                'vac_against_brucellosis'  =>  $this->input->post('b_com_vac_against_brucellosis'),
                'sample'                   =>  $this->input->post('sample'),
                'species'                  =>  $this->input->post('species'),
                'technician'               =>  $this->input->post('b_com_technician'),
                'remarks'                  =>  $this->input->post('b_com_remarks'),
                'result'                   =>  $this->input->post('b_com_result'),
                'history'                  =>  $this->input->post('history'),
                'created_by'               =>  $this->session->userdata('user')['user_id'],
            ];
         $this->API_m->create('brucella_animal_combine',$brucella_ani_com);
        }
        else if($tests->testHelp_id==7)
        {
             $brucella_animal_ind = [
                'testDetails_id'           =>  $TestInfo_id,
                'tag_no'                   =>  $this->input->post('cattle_tag_no'),
                'vac_against_brucellosis'  =>  $this->input->post('b_ani_vac_against_brucellosis'),
                'sample'                   =>  $this->input->post('sample'),
                'parity'                   =>  $this->input->post('parity'),
                'technician'               =>  $this->input->post('b_ani_technician'),
                'result'                   =>  $this->input->post('b_ani_result'),
                'history'                  =>  $this->input->post('b_ani_history'),
                'created_by'               =>  $this->session->userdata('user')['user_id'],
            ];
         $this->API_m->create('brucella_animal_ind',$brucella_animal_ind);
        }
        else if($tests->testHelp_id==8)
        {
             $brucella_human = [
                'testDetails_id'           =>  $TestInfo_id,
                'brucella_abortus_20'      =>  $this->input->post('brucella_abortus_20'),
                'brucella_abortus_40'      =>  $this->input->post('brucella_abortus_40'),
                'brucella_abortus_80'      =>  $this->input->post('brucella_abortus_80'),
                'brucella_abortus_160'     =>  $this->input->post('brucella_abortus_160'),
                'brucella_abortus_320'     =>  $this->input->post('brucella_abortus_320'),
                'brucella_meletensis_20'   =>  $this->input->post('brucella_meletensis_20'),
                'brucella_meletensis_40'   =>  $this->input->post('brucella_meletensis_40'),
                'brucella_meletensis_80'   =>  $this->input->post('brucella_meletensis_80'),
                'brucella_meletensis_160'  =>  $this->input->post('brucella_meletensis_160'),
                'brucella_meletensis_320'  =>  $this->input->post('brucella_meletensis_320'),
                'result_status'            =>  $this->input->post('result_status'),
                'created_by'               =>  $this->session->userdata('user')['user_id'],
            ];
         $this->API_m->create('brucella_human',$brucella_human);
        }
        else if($tests->testHelp_id==9)
        {
             $tb_and_vph = [
                'testDetails_id'  =>  $TestInfo_id,
                'symptoms'        =>  $this->input->post('symptoms'),
                'specimen'        =>  $this->input->post('specimen'),
                'lab_findings'    =>  $this->input->post('lab_findings'),
                'referred_by'     =>  $this->input->post('referred_by'),
                'examined_by'     =>  $this->input->post('vp_hp_examined_by'),
                'remarks'         =>  $this->input->post('vp_hp_remarks'),
                'created_by'      =>  $this->session->userdata('user')['user_id'],
            ];
         $this->API_m->create('tb_and_vph',$tb_and_vph);
        }

          $this->session->set_flashdata('Msg', ' Record Added Successfull');
          redirect('Tests/updateTestDetailsRecord/'.$TestInfo_id);

    }


    public function update_testDetails_Record()
    {
         // echo "<pre>";
         // print_r($_POST);
         // exit();
         $testDetails_id        = $this->input->post('testDetails_id');
         $client_id             = $this->input->post('client_id');
         $test_id               = $this->input->post('test_id');
            $clientInfo = [
                'client_name'      => $this->input->post('client_name'),
                'client_contact'   => $this->input->post('client_contact'),
                'type'             => $this->input->post('client_type'),
                'client_cnic'      => $this->input->post('client_cnic'),
                'referred_by'      => $this->input->post('referred_by'),
                'client_address'   => $this->input->post('client_address'),
                'created_by'       => $this->session->userdata('user')['user_id'],
            ];
             $this->API_m->updateRecord('client_info',['client_id' => $client_id],$clientInfo);
            $TestInfo = [
                'test_id'          => $test_id,
                'client_id'        => $client_id,
                'sample_id'        => $this->input->post('sample_id'),
                'sample_desc'      => $this->input->post('sample_desc'),
                'cattle_name'      => $this->input->post('cattle_name'),
                'cattle_tag_no'    => $this->input->post('cattle_tag_no'),
                'cattle_sex'       => $this->input->post('cattle_sex'),
                'cattle_age'       => $this->input->post('cattle_age'),
                'cattle_breed'     => $this->input->post('cattle_breed'),
                'cattle_total_no'  => $this->input->post('cattle_total_no'),
                'test_total_fee'   => $this->input->post('test_total_fee'),
                'additional_info'  => $this->input->post('additional_info'),
                'recommendations'  => $this->input->post('recommendations'),
                'received_date'    => date('Y-m-d',strtotime($this->input->post('received_date'))),
                'result_date'      => date('Y-m-d',strtotime($this->input->post('result_date'))),
                'modified_date'    => date('Y-m-d H:i:s'),
                'created_by'       => $this->session->userdata('user')['user_id'],
            ];
         $this->API_m->updateRecord('testdetails',['testDetails_id' => $testDetails_id],$TestInfo);
        if($test_id==1)
        {
            $impression_smear_id   = $this->input->post('impression_smear_id');
            $ImpressionSmear = [
                'testDetails_id'   =>  $testDetails_id,
                'type_specimen'    =>  $this->input->post('type_specimen'),
                'animals_specimen' =>  $this->input->post('animals_specimen'),
                'examined_for'     =>  $this->input->post('examined_for'),
                'result'           =>  $this->input->post('result'),
                'remarks'          =>  $this->input->post('remarks'),
                'examined_by'      =>  $this->input->post('examined_by'),
                'created_by'       =>  $this->session->userdata('user')['user_id'],
            ];
         $this->API_m->updateRecord('impression_smear',['impression_smear_id' => $impression_smear_id],$ImpressionSmear);
            
        }else if($test_id==2)
        {
            $haematology_id   = $this->input->post('haematology_id');
            $haematology = [
                'testDetails_id'            =>  $testDetails_id,
                'haemoglobin'               => $this->input->post('haemoglobin'),
                'ESR'                       => $this->input->post('ESR'),
                'TRBC'                      => $this->input->post('TRBC'),
                'TLC'                       => $this->input->post('TLC'),
                'PCV'                       => $this->input->post('PCV'),
                'neutrophils'               => $this->input->post('neutrophils'),
                'lymphocytes'               => $this->input->post('lymphocytes'),
                'eosinophils'               => $this->input->post('eosinophils'),
                'monocytes'                 => $this->input->post('monocytes'),
                'basophils'                 => $this->input->post('basophils'),
                'protozoa'                  => $this->input->post('protozoa'),
                'iodine_flocculation_test'  => $this->input->post('iodine_flocculation_test'),
                'created_by'                => $this->session->userdata('user')['user_id'],
            ];
         $this->API_m->updateRecord('haematology',['haematology_id' => $haematology_id],$haematology);
        }else if($test_id==3)
        {
            $mastitis_id   = $this->input->post('mastitis_id');
            $Mastitis = [
                'testDetails_id'                 => $testDetails_id,
                'daily_milk_production'          => $this->input->post('daily_milk_production'),
                'lactation_no'                   => $this->input->post('lactation_no'),
                'total_animals_at_farm'          => $this->input->post('total_animals_at_farm'),
                'in_milk'                        => $this->input->post('in_milk'),
                'dry_period_given'               => $this->input->post('dry_period_given'),
                'cal_kid_lambing_date'           => $this->input->post('cal_kid_lambing_date'),
                'prev_mastatis_rec_of_anim'      => $this->input->post('prev_mastatis_rec_of_anim'),
                'prev_mastatis_rec_of_farm'      => $this->input->post('prev_mastatis_rec_of_farm'),
                'prac_mastatis_test_at_farm'     => $this->input->post('prac_mastatis_test_at_farm'),
                'sample_received'                => $this->input->post('sample_received'),
                'test_required'                  => $this->input->post('test_required'),
                'refer_to_bacteriology_sec_for'  => $this->input->post('refer_to_bacteriology_sec_for'),
                'created_by'                     => $this->session->userdata('user')['user_id'],
            ];
         $this->API_m->updateRecord('mastitis',['mastitis_id' => $mastitis_id],$Mastitis);
        }else if($test_id==4)
        {
            $culture_sensitivity_id   = $this->input->post('culture_sensitivity_id');
            $culture_sensitivity = [
                'testDetails_id'   => $testDetails_id,
                'antibiotics_id'   => $this->input->post('intibiotics'),
                'sensitivity'      => $this->input->post('sensitivity'),
                'tested_by'        => $this->input->post('tested_by'),
                'reports'          => $this->input->post('reports'),
                'created_by'       => $this->session->userdata('user')['user_id'],
            ];
         $this->API_m->updateRecord('culture_sensitivity',['culture_sensitivity_id' => $culture_sensitivity_id],$culture_sensitivity);
        }else if($test_id==5)
        {
            $urine_id   = $this->input->post('urine_id');
            $urine_examination = [
                'testDetails_id'   =>  $testDetails_id,
                'colour'           =>  $this->input->post('colour'),
                'appearance'       =>  $this->input->post('appearance'),
                'reaction'         =>  $this->input->post('reaction'),
                'specific_gravity' =>  $this->input->post('specific_gravity'),
                'glucose'          =>  $this->input->post('glucose'),
                'protein'          =>  $this->input->post('protein'),
                'bile_salts'       =>  $this->input->post('bile_salts'),
                'bile_pigments'    =>  $this->input->post('bile_pigments'),
                'ketone_bodies'    =>  $this->input->post('ketone_bodies'),
                'haemoglobin'      =>  $this->input->post('haemoglobin'),
                'pus_cell'         =>  $this->input->post('pus_cell'),
                'epithelial_cell'  =>  $this->input->post('epithelial_cell'),
                'rb_cs'            =>  $this->input->post('rb_cs'),
                'casts'            =>  $this->input->post('casts'),
                'crystals'         =>  $this->input->post('crystals'),
                'amorphous'        =>  $this->input->post('amorphous'),
                'parasites'        =>  $this->input->post('parasites'),
                'bacteria'         =>  $this->input->post('bacteria'),
                 'remarks'         =>  $this->input->post('ur_remarks'),
                'examined_by'      =>  $this->input->post('ur_examined_by'),
                'created_by'       =>  $this->session->userdata('user')['user_id'],
            ];
         $this->API_m->updateRecord('urine_examination',['urine_id' => $urine_id],$urine_examination);
        }else if($test_id==6)
        {
            $brucella_animal_com_id   = $this->input->post('brucella_animal_com_id');
            $brucella_ani_com = [
                'testDetails_id'           =>  $testDetails_id,
                'tag_no'                   =>  $this->input->post('cattle_tag_no'),
                'vac_against_brucellosis'  =>  $this->input->post('b_com_vac_against_brucellosis'),
                'sample'                   =>  $this->input->post('sample'),
                'species'                  =>  $this->input->post('species'),
                'technician'               =>  $this->input->post('b_com_technician'),
                'remarks'                  =>  $this->input->post('b_com_remarks'),
                'result'                   =>  $this->input->post('b_com_result'),
                'history'                  =>  $this->input->post('history'),
                'created_by'               =>  $this->session->userdata('user')['user_id'],
            ];
          $this->API_m->updateRecord('brucella_animal_combine',['brucella_animal_com_id' => $brucella_animal_com_id],$brucella_ani_com);
        }
        else if($test_id==7)
        {
            $brucella_animal_ind_id   = $this->input->post('brucella_animal_ind_id');
             $brucella_animal_ind = [
                'testDetails_id'           =>  $testDetails_id,
                'tag_no'                   =>  $this->input->post('cattle_tag_no'),
                'vac_against_brucellosis'  =>  $this->input->post('b_ani_vac_against_brucellosis'),
                'sample'                   =>  $this->input->post('sample'),
                'parity'                   =>  $this->input->post('parity'),
                'technician'               =>  $this->input->post('b_ani_technician'),
                'result'                   =>  $this->input->post('b_ani_result'),
                'history'                  =>  $this->input->post('b_ani_history'),
                'created_by'               =>  $this->session->userdata('user')['user_id'],
            ];
         $this->API_m->updateRecord('brucella_animal_ind',['brucella_animal_ind_id' => $brucella_animal_ind_id],$brucella_animal_ind);
        }
        else if($test_id==8)
        {
            $brucella_human_id   = $this->input->post('brucella_human_id');
             $brucella_human = [
                'testDetails_id'           =>  $testDetails_id,
                'brucella_abortus_20'      =>  $this->input->post('brucella_abortus_20'),
                'brucella_abortus_40'      =>  $this->input->post('brucella_abortus_40'),
                'brucella_abortus_80'      =>  $this->input->post('brucella_abortus_80'),
                'brucella_abortus_160'     =>  $this->input->post('brucella_abortus_160'),
                'brucella_abortus_320'     =>  $this->input->post('brucella_abortus_320'),
                'brucella_meletensis_20'   =>  $this->input->post('brucella_meletensis_20'),
                'brucella_meletensis_40'   =>  $this->input->post('brucella_meletensis_40'),
                'brucella_meletensis_80'   =>  $this->input->post('brucella_meletensis_80'),
                'brucella_meletensis_160'  =>  $this->input->post('brucella_meletensis_160'),
                'brucella_meletensis_320'  =>  $this->input->post('brucella_meletensis_320'),
                'result_status'            =>  $this->input->post('result_status'),
                'created_by'               =>  $this->session->userdata('user')['user_id'],
            ];
         $this->API_m->updateRecord('brucella_human',['brucella_human_id' => $brucella_human_id],$brucella_human);
        }
        else if($test_id==9)
        {
            $tb_and_vph_id   = $this->input->post('tb_and_vph_id');
             $tb_and_vph = [
                'testDetails_id'  =>  $testDetails_id,
                'symptoms'        =>  $this->input->post('symptoms'),
                'specimen'        =>  $this->input->post('specimen'),
                'lab_findings'    =>  $this->input->post('lab_findings'),
                'referred_by'     =>  $this->input->post('referred_by'),
                'examined_by'     =>  $this->input->post('vp_hp_examined_by'),
                'remarks'         =>  $this->input->post('vp_hp_remarks'),
                'created_by'      =>  $this->session->userdata('user')['user_id'],
            ];
         $this->API_m->updateRecord('tb_and_vph',['tb_and_vph_id' => $tb_and_vph_id],$tb_and_vph);
        }

          $this->session->set_flashdata('Msg', ' Record Updated Successfully');
          redirect('Tests/updateTestDetailsRecord/'.$testDetails_id);
    }


    public function TestRecordCancel()
    {
         // echo "<pre>";
         // print_r($_POST);
         // exit();
         $testDetails_id        = $this->input->post('testDetails_id');
         $uri                   = $this->input->post('uri');
         $data = [
                'is_cancel'          =>  1,
                'cancel_reason'      =>  $this->input->post('cancel_reason'),
                'cancel_by'          =>  $this->session->userdata('user')['user_id'],
            ];
        $this->API_m->updateRecord('testdetails',['testDetails_id' => $testDetails_id],$data);
        $this->session->set_flashdata('Msg', ' Record Cancelled Successfully');
         redirect('Tests/singleTestDetailRecord/'.$testDetails_id);   
    }
    public function TestRecordPost()
    {
         // echo "<pre>";
         // print_r($_POST);
         // exit();
         $testDetails_id        = $this->input->post('testDetails_id');
         $uri                   = $this->input->post('uri');
         $data = [
                'post_status'   =>  1,
                'posted_date'   =>  date('Y-m-d'),
            ];
        $this->API_m->updateRecord('testdetails',['testDetails_id' => $testDetails_id],$data);
        $this->session->set_flashdata('Msg', ' Record Posted Successfully');
         redirect('Tests/singleTestDetailRecord/'.$testDetails_id);   
    }


}

 ?>