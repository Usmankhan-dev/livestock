<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
class Login extends CI_Controller
{
		function __construct()
		{
			parent::__construct();
			date_default_timezone_set('Asia/Karachi');
           
		}

	 public function index()
	 {
	 	// $data['comInfo']     = $this->Login_m->singleRow('settings');
	 	$this->load->view('login');
	 }


	

// verifying user credientials
	public function AdminVerify() {
		// echo "<pre>";
		// print_r($_POST);
		// exit();
        $email        = $this->input->post('admin_email');
        $password     = $this->input->post('admin_pass');

        $condition = [
            'user_email' => $email,
            
        ];
      
        $returnedData = $this->Login_m->singleRecordArray('users', $condition);
        // echo "<pre>";
        // print_r($returnedData);
        // exit();
        $size = sizeof($returnedData);
        if ($size == 1) {
            foreach ($returnedData as $user) {
            	// ($this->password->verify_hash
                if ($this->password->verify_hash($password,$user->user_password)) {
                    if($user->is_block==1)
                    {
                        $this->session->set_flashdata('Msg', 'Your account has been blocked by Admin');
                        redirect('Login/index');
                    }
                        $sessionData = [
                            'user_id'     => $user->user_id,
                            'username'    => $user->user_name,
                            'lab_id'      => $user->lab_id,
                            'email'       => $user->user_email,
                            'role'        => $user->user_role
                        ];

                  
                    $this->session->set_userdata('user', $sessionData);
                    $this->session->set_flashdata('Msg', 'Login Successfull!');
$role_id      = $this->session->userdata('user')['role'];
$permissions  = $this->User_m->getRecordWhere('role_permissions',['role_id' => $role_id]); 
if($permissions[0]->module_id == 1 && $permissions[0]->show_none==0)
{
    redirect('Dashboard/index');
}
elseif($permissions[2]->module_id == 3 && $permissions[2]->show_none==0)
{
    redirect('Tests/test_records');
}elseif($permissions[1]->module_id == 2 && $permissions[1]->show_none==0)
{
    redirect('Pagescontroller/directorates');
}elseif($permissions[3]->module_id == 4 && $permissions[3]->show_none==0)
{
    redirect('User/index');
}else
{
unset($_SESSION['user']);
$this->session->set_flashdata('Msg', ' Your Account is restricted to all modules!');
redirect('Login/index');
}
                   
                } else {
                    $this->session->set_flashdata('Msg', 'Wrong Credentials!');
                    redirect('Login/index');
                }
            }
        } else {
            $this->session->set_flashdata('Msg', 'Wrong Credentials!');
            redirect('Login');
        }
    }

    public function user_profile()
     {
        $data['logUser']   = $this->User_m->getLogUserInfo();
        $data['logLab']    = $this->User_m->getLogUserLabInfo();
        $this->load->view('template_parts/header',$data);
        $this->load->view('template_parts/menu');
        $this->load->view('template_parts/asidemenu');
        $this->load->view('pages/user_profile');
        $this->load->view('template_parts/footer');
     }
    public function changeProfileImg()
    {
        $img_name = $this->API_m->upload('user_images');
        $user_id  = $this->session->userdata('user')['user_id'];
        $data = [
        'user_img'  => $img_name
        ];
            
        $this->User_m->updateRecord('users',['user_id'=>$user_id],$data);
        $this->session->set_flashdata('Msg', ' Images Changed Successfull');
        redirect('Login/user_profile/');
    }

    public function DeleteProfileImg($user_id)
      {
        $data = [
        'user_img'  => ''
        ];
            
        $this->User_m->updateRecord('users',['user_id'=>$user_id],$data);
        $this->session->set_flashdata('Msg', ' Images Deleted Successfull');
        redirect('Login/user_profile/');
    }
    public function UpdatePassword()
    {
        // echo "<pre>";
        // print_r($_POST);
        // exit();
        $user_id = $this->session->userdata('user')['user_id'];
        $newPass = $this->input->post('New_Password');

        $pass = $this->password->hash($newPass);
        
        $passData = array (
            'user_password' => $pass
        );
         $this->User_m->updateRecord('users',['user_id'=>$user_id],$passData);
         $this->session->set_flashdata('Msg', ' Password Changed Successfully!');
        redirect('Login/user_profile');
    }
    public function logout(){
// $role_id               = $this->session->userdata('user')['role'];
// $permissions           = $this->User_m->getRecordWhere('role_permissions',['role_id' => $role_id]); 
// echo "<pre>";
// print_r($permissions);
// exit();
        unset($_SESSION['user']);
        $this->session->set_flashdata('Msg', ' Logout Successfull!');
        redirect('Login/index');
    }

// QUERIES FOR JS CODE IN FOOTER
    public function getStations()
    {
        $id       = $this->input->post('directorate_id');
        $stations = $this->API_m->getRecordWhere('center_station',['directorate_id' => $id,'is_trash' => 0]);
        // echo "<pre>";
        // print_r($stations);
        // exit();
        echo json_encode($stations);
    }
    public function GetSections()
    {
        $id       = $this->input->post('center_station_id');
        $section  = $this->API_m->GetSectionsItems($id);
        // echo "<pre>";
        echo json_encode($section);
    }
    public function GetLabs()
    {
        $id       = $this->input->post('section_id');
        $labs     = $this->API_m->getRecordWhere('labs',['section_id' => $id,'is_trash' => 0]);
        // echo "<pre>";
        echo json_encode($labs);
    }
    public function GetBreeds()
    {
        $id      = $this->input->post('cattle_id');
        $breeds  = $this->API_m->getRecordWhere('breeds',['cattle_id' => $id,'is_trash' => 0]);
        // echo "<pre>";
        echo json_encode($breeds);
    }
    public function getTestSamples()
    {
        $test_id = $this->input->post('test_id');
        $samples = $this->API_m->getAllTestSamples($test_id);
        // echo "<pre>";
       echo json_encode($samples);
  
    }
    public function GetClient_cnic()
    {
        $cnic    = $this->input->post('cnic');
        $client  = $this->API_m->singleRecord('client_info',['client_cnic' => $cnic]);
        // echo "<pre>";
       echo json_encode($client);
  
    }
   
// checking email availability
    // public function check_email()
    // {
    	
    // 	$email = $_POST['email'];

    // 	$res = $this->User_m->check_email($email);

    	
    // }
    //this function is used to verified user old password

    // public function verifiedOldPassword() {
    //     echo json_encode($this->User_m->verifiedOldPassword($this->input->post('oldPassword')));
    // }

    // public function UpdateAdminPassword()
    // {
    	
    // 	$user_id = $this->session->userdata('user')['user_id'];
    // 	$newPass = $this->input->post('New_Password');

    // 	$pass = $this->password->hash($newPass);
    	
    // 	$passData = array (
    // 		'user_password' => $pass
    // 	);
    	
    // 	 $this->Login_m->updateRecord('users',['user_id'=>$user_id],$passData);
    //      $this->session->set_flashdata('Msg', ' Password Changed Successfull!');
    // 	redirect('Login/adminChangePassword');
    // }

	
}
?>